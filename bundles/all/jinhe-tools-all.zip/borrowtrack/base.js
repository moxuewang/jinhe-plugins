(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.FlowBase=api;}(typeof window==='object'?window:this,function(){'use strict';
var MAX=8388608,OWN=Object.prototype.hasOwnProperty;
function fail(s){throw new Error(s);}
function bytes(s,max){if(typeof s!=='string')fail('内容不是完整文本。');var n=0,i,c,t;for(i=0;i<s.length;i++){c=s.charCodeAt(i);if(c<128)n++;else if(c<2048)n+=2;else if(c>=55296&&c<=56319){t=s.charCodeAt(++i);if(!(t>=56320&&t<=57343))fail('文本含无效 Unicode。');n+=4;}else if(c>=56320&&c<=57343)fail('文本含无效 Unicode。');else n+=3;if(n>(max===undefined?MAX:max))fail('内容超过容量，未截断，原数据仍保留。');}return n;}
function text(s,max,required){if(typeof s!=='string'||s.length>max||(required&&!s.trim())||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(s))fail('文本为空、过长或含控制字符。');bytes(s);return s;}
function int(n,min,max){if(typeof n!=='number'||!isFinite(n)||Math.floor(n)!==n||n<min||n>max)fail('数量或序号须为范围内的整数。');return n;}
function id(s){return text(s,100,true);}
function object(x){if(!x||typeof x!=='object'||Array.isArray(x))fail('记录格式无效。');return x;}
function keys(x,allowed){object(x);Object.keys(x).forEach(function(k){if(allowed.indexOf(k)<0)fail('含未识别字段：'+k+'，没有丢弃任何字段。');});return x;}
function array(x,max){if(!Array.isArray(x)||x.length>max)fail('记录列表无效或超出数量上限。');return x;}
function unique(rows,key){var map=Object.create(null);rows.forEach(function(x){var k=id(x[key]);if(OWN.call(map,k))fail('记录 ID 重复。');map[k]=x;});return map;}
function date(s,optional){if(optional&&s==='')return s;if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))fail('日期请用 YYYY-MM-DD。');var a=s.split('-').map(Number),d=new Date(a[0],a[1]-1,a[2]);if(a[0]<1900||a[0]>9999||d.getFullYear()!==a[0]||d.getMonth()!==a[1]-1||d.getDate()!==a[2])fail('日期不存在或不在 1900—9999 年。');return s;}
function clone(x){return JSON.parse(JSON.stringify(x));}
function uid(prefix){return prefix+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);}
function escape(s){return String(s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function csvCell(v){var s=String(v);if(/^[\s\uFEFF]*[=+@-]/.test(s)||s.charAt(0)==="'")s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
function csv(rows){var n=3,encoded=[];rows.forEach(function(row,idx){var cells=[];row.forEach(function(c,i){var s=csvCell(c);n+=bytes(s)+(i?1:0);if(n>MAX)fail('CSV 超过 8 MiB，未生成，原数据仍保留。');cells.push(s);});if(idx)n+=2;if(n>MAX)fail('CSV 超过 8 MiB，未生成。');encoded.push(cells.join(','));});return '\uFEFF'+encoded.join('\r\n');}
function parseCSV(s){bytes(s);if(s.charCodeAt(0)===65279)s=s.slice(1);if(!s)return [];var rows=[],row=[],cell='',quoted=false,after=false,start=true,i,c;function field(){row.push(cell);if(row.length>20)fail('CSV 列数超过 20。');cell='';after=false;start=true;}function record(){field();rows.push(row);if(rows.length>10001)fail('CSV 超过 10000 条事件。');row=[];}for(i=0;i<s.length;i++){c=s.charAt(i);if(quoted){if(c==='"'){if(s.charAt(i+1)==='"'){cell+='"';i++;}else{quoted=false;after=true;}}else cell+=c;continue;}if(after&&c!==','&&c!=='\r'&&c!=='\n')fail('CSV 引号后有多余内容。');if(c==='"'){if(!start)fail('CSV 引号须位于字段开头。');quoted=true;start=false;}else if(c===',')field();else if(c==='\r'||c==='\n'){if(c==='\r'&&s.charAt(i+1)==='\n')i++;record();}else{cell+=c;start=false;}}if(quoted)fail('CSV 引号未闭合。');if(cell||row.length||after||s.charAt(s.length-1)===',')record();var width=rows[0]&&rows[0].length;rows.forEach(function(r){if(r.length!==width)fail('CSV 列数不齐，整份未导入。');});return rows;}
function encode(x){var s=JSON.stringify(x);bytes(s);return s;}
function parse(s){bytes(s);try{return JSON.parse(s.charCodeAt(0)===65279?s.slice(1):s);}catch(e){fail('不是完整 JSON，原数据未改动。');}}
function page(rows,index){index=Math.max(0,Math.min(index,Math.max(0,Math.ceil(rows.length/20)-1)));return{rows:rows.slice(index*20,index*20+20),index:index,pages:Math.max(1,Math.ceil(rows.length/20))};}
return{MAX:MAX,fail:fail,bytes:bytes,text:text,int:int,id:id,keys:keys,array:array,unique:unique,date:date,clone:clone,uid:uid,escape:escape,csv:csv,parseCSV:parseCSV,encode:encode,parse:parse,page:page};
}));
