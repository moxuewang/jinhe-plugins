(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.FlowDataRoot=api;}(typeof window==='object'?window:this,function(){'use strict';
function unsupported(){var e=Error('当前锦盒不支持完整独立数据区，请升级后再使用；原数据未改。');e.code='unsupported';throw e;}
function requireData(jh){return Promise.resolve().then(function(){
 if(!jh||!jh.dataFile||typeof jh.dataFile.capabilities!=='function')unsupported();
 ['info','readChunk','writeChunk','delete','savePath','grab'].forEach(function(k){if(typeof jh.dataFile[k]!=='function')unsupported();});
 return jh.dataFile.capabilities();
}).then(function(c){if(!c||c.version!==1||c.area!=='data'||c.workbenchData!==true||typeof c.maxFileBytes!=='number'||!isFinite(c.maxFileBytes)||c.maxFileBytes<8388608||typeof c.maxImportBytes!=='number'||!isFinite(c.maxImportBytes)||c.maxImportBytes<8388608||typeof c.maxTotalBytes!=='number'||!isFinite(c.maxTotalBytes)||c.maxTotalBytes<8388608)unsupported();return c;});}
return{require:requireData};
}));
