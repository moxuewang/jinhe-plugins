(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.FileNaming = api;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var MAX_SEQUENCE = 999999999;
  var CONTROL = /[\u0000-\u001f\u007f-\u009f]/;

  function fold(name) { return name.toLowerCase(); }

  function extensionParts(name) {
    var dot = name.lastIndexOf('.');
    if (dot <= 0) return { stem: name, extension: '' };
    return { stem: name.slice(0, dot), extension: name.slice(dot) };
  }

  function utf8Length(text) {
    var bytes = 0;
    for (var i = 0; i < text.length; i++) {
      var code = text.charCodeAt(i);
      if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length) {
        var next = text.charCodeAt(i + 1);
        if (next >= 0xdc00 && next <= 0xdfff) {
          bytes += 4;
          i++;
          continue;
        }
      }
      if (code <= 0x7f) bytes += 1;
      else if (code <= 0x7ff) bytes += 2;
      else bytes += 3;
    }
    return bytes;
  }

  function ruleError(rule) {
    if (rule == null) return '';
    if (typeof rule !== 'object' || Array.isArray(rule)) return '改名参数无效';
    if (typeof rule.mode !== 'string') return '请选择改名方式';
    if (rule.keepExtension !== undefined && typeof rule.keepExtension !== 'boolean') return '扩展名设置无效';
    if (rule.mode === 'replace') {
      if (typeof rule.oldText !== 'string' || rule.oldText.length === 0) return '请输入要替换的文字';
      if (rule.newText !== undefined && typeof rule.newText !== 'string') return '替换内容无效';
      if (rule.replaceAll !== undefined && typeof rule.replaceAll !== 'boolean') return '替换范围无效';
      return '';
    }
    if (rule.mode === 'prefix') {
      if (rule.prefix !== undefined && typeof rule.prefix !== 'string') return '前后缀无效';
      if (rule.suffix !== undefined && typeof rule.suffix !== 'string') return '前后缀无效';
      return '';
    }
    if (rule.mode === 'sequence') {
      if (rule.prefix !== undefined && typeof rule.prefix !== 'string') return '序号前缀无效';
      if (rule.suffix !== undefined && typeof rule.suffix !== 'string') return '序号后缀无效';
      var start = rule.start === undefined ? 1 : rule.start;
      var digits = rule.digits === undefined ? 3 : rule.digits;
      if (!Number.isFinite(start) || !Number.isInteger(start) || start < 0 || start > MAX_SEQUENCE) return '起始序号应为0到999999999的整数';
      if (!Number.isFinite(digits) || !Number.isInteger(digits) || digits < 1 || digits > 9) return '位数应为1到9的整数';
      return '';
    }
    return '不支持这种改名方式';
  }

  function transform(name, rule, index) {
    if (rule == null) return name;
    var keepExtension = rule.keepExtension !== false;
    var parts = keepExtension ? extensionParts(name) : { stem: name, extension: '' };
    if (rule.mode === 'replace') {
      var replacement = rule.newText === undefined ? '' : rule.newText;
      var at = parts.stem.indexOf(rule.oldText);
      if (at < 0) return name;
      if (rule.replaceAll !== false) {
        parts.stem = parts.stem.split(rule.oldText).join(replacement);
      } else {
        parts.stem = parts.stem.slice(0, at) + replacement + parts.stem.slice(at + rule.oldText.length);
      }
      return parts.stem + parts.extension;
    }
    if (rule.mode === 'prefix') {
      return (rule.prefix || '') + parts.stem + (rule.suffix || '') + parts.extension;
    }
    var start = rule.start === undefined ? 1 : rule.start;
    var digits = rule.digits === undefined ? 3 : rule.digits;
    var number = start + index;
    if (number > MAX_SEQUENCE) return null;
    var sequence = String(number).padStart(digits, '0');
    return (rule.prefix === undefined ? '文件' : rule.prefix) + sequence + (rule.suffix || '') + parts.extension;
  }

  function nameError(name, changed) {
    if (name.length === 0) return '文件名不能为空';
    if (name === '.' || name === '..') return '文件名不能是 . 或 ..';
    if (/[\\/]/.test(name)) return '文件名不能包含斜线';
    if (CONTROL.test(name)) return '文件名含有不支持的字符';
    if (utf8Length(name) > 255) return '文件名超过255字节';
    if (changed && name !== name.trim()) return '文件名首尾不能有空白';
    return '';
  }

  function buildPreview(files, rule, occupiedNames) {
    files = Array.isArray(files) ? files : [];
    occupiedNames = Array.isArray(occupiedNames) ? occupiedNames.filter(function (x) { return typeof x === 'string'; }) : [];
    var invalidRule = ruleError(rule);
    var results = files.map(function (file, index) {
      file = file && typeof file === 'object' ? file : {};
      var before = typeof file.name === 'string' ? file.name : '';
      var after = before;
      var error = invalidRule;
      if (!error) {
        after = transform(before, rule, index);
        if (after === null) {
          after = before;
          error = '序号超出范围';
        }
      }
      var changed = after !== before;
      if (!error) error = nameError(after, changed);
      if (!error && changed && file.canRename === false) error = '该文件不支持改名';
      return { id: file.id, before: before, after: after, changed: changed, error: error };
    });

    var changedTargets = new Map();
    results.forEach(function (item, index) {
      if (!item.changed || item.error) return;
      var key = fold(item.after);
      var group = changedTargets.get(key) || [];
      group.push(index);
      changedTargets.set(key, group);
    });
    changedTargets.forEach(function (group) {
      if (group.length > 1) group.forEach(function (index) { results[index].error = '目标名称重复'; });
    });

    var reserved = new Set(occupiedNames.map(fold));
    results.forEach(function (item, index) {
      if (!item.changed || item.error) return;
      var target = fold(item.after);
      if (reserved.has(target)) {
        item.error = '目标名称已被占用';
        return;
      }
      for (var other = 0; other < results.length; other++) {
        if (other === index || fold(results[other].before) !== target) continue;
        var occupant = results[other];
        if (occupant.changed && !occupant.error) continue;
        item.error = '目标名称已被占用';
        return;
      }
    });
    return results;
  }

  return { buildPreview: buildPreview };
}));
