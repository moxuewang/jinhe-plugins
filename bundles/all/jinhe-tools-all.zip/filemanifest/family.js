(function(){'use strict';
  var $=function(id){return document.getElementById(id);},job=null,timer=0,cancelled=false;
  function error(e){return e&&(e.error||e.message)||'暂时完成不了，请重试。';}
  function message(words,bad){$('message').textContent=words;$('message').classList.toggle('error',!!bad);}
  function lock(on){document.querySelectorAll('button,input,select').forEach(function(e){if(e.closest('#progressCard')||e.closest('#sheet'))return;if(on){if(!e._familyLocked){e._familyDisabled=e.disabled;e._familyLocked=true;}e.disabled=true;}else if(e._familyLocked){e.disabled=e._familyDisabled;delete e._familyDisabled;delete e._familyLocked;}});}
  function close(){var d=$('sheet');if(d.open)d.close();}
  function sheet(title){close();$('sheetTitle').textContent=title;$('sheetBody').replaceChildren();$('sheet').showModal();return $('sheetBody');}
  function button(label,fn){var b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=fn;return b;}
  async function choose(accept,multiple){
    var body=sheet('从工作台选择');body.textContent='正在读取…';
    try{var items=await JH.workbench.list();if(!$('sheet').open)return null;body.replaceChildren();return await new Promise(function(resolve){
      var settled=false;function finish(x){if(settled)return;settled=true;close();resolve(x);} $('sheet').addEventListener('close',function(){if(!settled){settled=true;resolve(null);}},{once:true});
      var eligible=items.filter(function(i){return !accept||accept.indexOf(i.type)>=0;});if(!eligible.length){var p=document.createElement('p');p.className='detail';p.textContent='工作台没有可用材料。先在文件管家把文件送过来。';body.appendChild(p);}
      var selected=new Map(),page=0,list=document.createElement('div'),nav=document.createElement('div'),confirm;
      if(multiple){confirm=button('使用所选材料',function(){finish(Array.from(selected.values()));});confirm.className='primary wide';confirm.disabled=true;body.appendChild(confirm);}body.append(list,nav);nav.className='actions';
      function paint(){list.replaceChildren();nav.replaceChildren();eligible.slice(page*40,(page+1)*40).forEach(function(i){var b=button(i.name||i.preview||'未命名材料',function(){if(!multiple){finish(i);return;}if(selected.has(i.id))selected.delete(i.id);else selected.set(i.id,i);b.setAttribute('aria-pressed',String(selected.has(i.id)));confirm.disabled=selected.size===0;confirm.textContent='使用所选 '+selected.size+' 份材料';});b.className='material wide';if(multiple)b.setAttribute('aria-pressed',String(selected.has(i.id)));list.appendChild(b);});if(page>0)nav.appendChild(button('上一页',function(){page--;paint();}));if((page+1)*40<eligible.length)nav.appendChild(button('下一页',function(){page++;paint();}));}paint();
    });}catch(e){close();message(error(e),true);return null;}
  }
  async function task(request,title){
    lock(true);cancelled=false;$('progressCard').hidden=false;$('progressTitle').textContent=title;$('progressText').textContent='准备中…';$('stop').disabled=false;$('retry').hidden=true;$('taskProgress').removeAttribute('value');
    try{var r=await request();if(!r||!r.jobId)throw new Error('任务没有启动，请重试。');job=r.jobId;return await new Promise(function(resolve,reject){
      var running=false;
      async function poll(){if(running||!job)return;running=true;try{var s=await JH.folder.status(job);$('retry').hidden=true;if(s.state==='running'){
        var total=s.total||0,done=s.done||0;$('progressText').textContent=total?done+' / '+total:'正在处理…';if(total){$('taskProgress').max=total;$('taskProgress').value=done;}timer=setTimeout(poll,350);
      }else{job=null;clearTimeout(timer);$('progressCard').hidden=true;lock(false);if(s.state==='done')resolve(s);else if(s.state==='cancelled'){cancelled=true;reject(new Error(s.error||'已停止；没有生成新结果。'));}else reject(new Error(s.error||'任务未完成，请重试。'));}}
      catch(e){$('progressText').textContent=error(e)+' 正在重查原任务。';$('retry').hidden=false;timer=setTimeout(poll,1800);}finally{running=false;}}
      $('retry').onclick=function(){clearTimeout(timer);poll();};poll();
    });}catch(e){if(!job){$('progressCard').hidden=true;lock(false);}throw e;}
  }
  async function readItem(item){
    if(item.type==='text'){var text=item.text;if(text==null){var t=await JH.workbench.take(item.id);text=t.text;}if(typeof text!=='string')throw new Error('这份材料没有文本。');if(new TextEncoder().encode(text).length>8388608)throw new Error('清单超过 8 MB，请分成较小的清单。');return text;}
    var f=await JH.workbench.take(item.id),info=await JH.file.info(f.path);if(!Number.isSafeInteger(info.size)||info.size<0||info.size>8388608)throw new Error('只读取 8 MB 以内的 JSON 清单；原文件保留在工作台。');
    var decoder=new TextDecoder('utf-8',{fatal:true}),parts=[];for(var offset=0;offset<info.size;offset+=262144){var length=Math.min(262144,info.size-offset),got=await JH.file.readChunk(f.path,offset,length),raw=atob(got.base64||''),u=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)u[i]=raw.charCodeAt(i);if(u.length!==length)throw new Error('清单没有读完整，请重试。');parts.push(decoder.decode(u,{stream:true}));}parts.push(decoder.decode());return parts.join('');
  }
  async function put(name,data){var path='reports/'+name,encoded=new TextEncoder().encode(data);for(var offset=0;offset<encoded.length;offset+=65536)await JH.file.writeChunk(path,offset,encoded.subarray(offset,offset+65536));return JH.workbench.put({type:'file',path:path,name:name});}
  $('sheetClose').onclick=close;$('stop').onclick=async function(){if(!job)return;$('stop').disabled=true;try{await JH.folder.cancel(job);$('progressText').textContent='正在停止…';}catch(e){message(error(e),true);$('stop').disabled=false;}};
  if(window.JH&&JH.onBack)JH.onBack(function(){if($('sheet').open){close();return true;}if(job){message('正在处理，可点“停止”或等待完成。');return true;}return false;});
  document.addEventListener('visibilitychange',function(){if(!document.hidden&&job&&!timer)$('retry').click();});
  window.FamilyUI={$:$,message:message,error:error,choose:choose,sheet:sheet,close:close,button:button,task:task,readItem:readItem,put:put,lock:lock};
}());
