(function(root,factory){'use strict';if(typeof module==='object'&&module.exports)module.exports=factory();else root.FileManifest=factory();}(typeof self!=='undefined'?self:this,function(){
  'use strict';
  var FORMAT='jinhe.filemanifest',LIMIT=10000;
  function fail(words){throw new Error(words);}
  function csvCell(value){var s=String(value==null?'':value);if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
  function csv(rows){return '\uFEFF'+rows.map(function(r){return r.map(csvCell).join(',');}).join('\r\n');}
  function validate(input){
    var m=input;if(typeof input==='string'){try{m=JSON.parse(input.replace(/^\uFEFF/,''));}catch(e){fail('JSON 清单格式不完整，请重新导出。');}}
    if(!m||m.format!==FORMAT||m.version!==1||!Array.isArray(m.entries))fail('这不是锦盒文件清单，请先在“文件清单”生成 JSON。');
    if(!/^(current-folder|selection)$/.test(m.scope))fail('清单范围无效。');
    if(m.entries.length>LIMIT)fail('清单超过 10000 个文件，请分成较小的清单。');
    var seen=new Set();
    var entries=m.entries.map(function(e){
      if(!e||typeof e.path!=='string'||!e.path||e.path==='.'||e.path==='..'||/[\\/\u0000-\u001f]/.test(e.path))fail('清单含有无效文件名。');
      if(seen.has(e.path))fail('清单含有重复文件名：'+e.path);seen.add(e.path);
      if(e.state!=='done'&&e.state!=='failed')fail('清单中的文件状态无效。');
      if(typeof e.sizeKnown!=='boolean'||(e.sizeKnown&&(!Number.isSafeInteger(e.size)||e.size<0))||(!e.sizeKnown&&e.size!==null))fail('清单中的文件大小无效。');
      if(e.modified!==null&&(!Number.isSafeInteger(e.modified)||e.modified<0))fail('清单中的修改时间无效。');
      if(e.sha256!=null&&!/^[a-fA-F0-9]{64}$/.test(e.sha256))fail('清单中的 SHA-256 无效。');
      return {path:e.path,name:e.path,mime:typeof e.mime==='string'?e.mime:'',size:e.size,sizeKnown:e.sizeKnown,modified:e.modified,sha256:e.sha256?e.sha256.toLowerCase():undefined,state:e.state,error:e.state==='failed'?String(e.error||'读取失败'):undefined};
    });
    return {format:FORMAT,version:1,scope:m.scope,rootName:String(m.rootName||'文件'),generatedAt:String(m.generatedAt||''),hashRequested:!!m.hashRequested,entries:entries};
  }
  function create(rows,options){
    options=options||{};
    return validate({format:FORMAT,version:1,scope:options.scope||'selection',rootName:options.rootName||'所选文件',generatedAt:new Date().toISOString(),hashRequested:!!options.hash,entries:rows.map(function(r){return {path:r.name,name:r.name,mime:r.mime||'',size:r.sizeKnown===true?r.size:null,sizeKnown:r.sizeKnown===true,modified:Number.isSafeInteger(r.modified)&&r.modified>=0?r.modified:null,sha256:r.sha256,state:r.state,error:r.error};})});
  }
  function compare(before,after){
    before=validate(before);after=validate(after);var a=new Map(),b=new Map(),paths=new Set();before.entries.forEach(function(e){a.set(e.path,e);paths.add(e.path);});after.entries.forEach(function(e){b.set(e.path,e);paths.add(e.path);});
    var counts={added:0,removed:0,changed:0,same:0,unverified:0,error:0};
    var rows=Array.from(paths).sort().map(function(path){
      var x=a.get(path),y=b.get(path),state,detail;
      if((x&&x.state==='failed')||(y&&y.state==='failed')){state='error';detail=[x&&x.error,y&&y.error].filter(Boolean).join('；');}
      else if(!x){state='added';detail='新清单增加';}
      else if(!y){state='removed';detail='新清单缺少';}
      else if(x.sha256&&y.sha256){state=x.sha256===y.sha256?'same':'changed';detail=state==='same'?'SHA-256 一致':'SHA-256 不同';}
      else if(x.sizeKnown&&y.sizeKnown&&x.size!==y.size){state='changed';detail='文件大小不同';}
      else{state='unverified';detail=x.sizeKnown&&y.sizeKnown?'大小相同，内容未核':'大小未知，内容未核';}
      counts[state]++;return {path:path,state:state,detail:detail,before:x||null,after:y||null};
    });
    return {format:'jinhe.manifestdiff',version:1,generatedAt:new Date().toISOString(),before:before.rootName,after:after.rootName,scopeWarning:before.scope!==after.scope?'两份清单范围不同，请核对来源。':'',counts:counts,rows:rows};
  }
  function manifestCsv(m){m=validate(m);return csv([['文件名','字节数','修改时间','类型','SHA-256','状态','原因']].concat(m.entries.map(function(e){return [e.path,e.sizeKnown?e.size:'未知',e.modified==null?'未知':e.modified,e.mime,e.sha256||'未核',e.state==='done'?'已读取':'失败',e.error||''];})));}
  function diffCsv(report){return csv([['文件名','结论','说明','原大小','新大小']].concat(report.rows.map(function(r){return [r.path,{added:'新增',removed:'缺少',changed:'变化',same:'内容一致',unverified:'未核内容',error:'读取失败'}[r.state],r.detail,r.before&&r.before.sizeKnown?r.before.size:'未知',r.after&&r.after.sizeKnown?r.after.size:'未知'];})));}
  return {validate:validate,create:create,compare:compare,manifestCsv:manifestCsv,diffCsv:diffCsv};
}));
