(function () {
  'use strict';
  var M = Scoreboard, J = window.JH, $ = function (id) { return document.getElementById(id); };
  var store = ScoreboardStore({get: function (k) { if (!J || !J.storage) return Promise.reject(new Error('请在锦盒中打开桌游记分。')); return J.storage.get(k); }, set: function (k, v) { return J.storage.set(k, v); }}, M);
  var data = M.empty(), selected = 'current', page = 0, editIndex = -1, incoming = null, localBusy = false, successAction = null, confirmAction = null, launchRead = false, ended = false, reportGame = null;
  function el(tag, text, cls) { var n = document.createElement(tag); if (text != null) n.textContent = text; if (cls) n.className = cls; return n; }
  function message(e) { return e && e.message || '操作没有完成，请重试。'; }
  function say(s, bad) { $('status').textContent = s; $('status').className = bad ? 'error' : ''; }
  function locked() { var s = store.status(); return !s.ready || s.busy || s.pending || s.conflict || localBusy || ended; }
  function game() { return selected === 'current' ? data.current : data.archived.filter(function (g) { return 'old:' + g.id === selected; })[0] || null; }
  function controls() {
    var s = store.status(), allLocked = locked(), g = game();
    document.querySelectorAll('button,input,select,textarea').forEach(function (n) { n.disabled = allLocked; });
    document.querySelectorAll('[data-close]').forEach(function (n) { n.disabled = s.busy || localBusy; });
    $('recovery').hidden = s.ready && !s.pending && !s.conflict;
    $('recoveryTitle').textContent = !s.ready ? '记录尚未读取' : s.conflict ? '记录在其他窗口有变化' : '这次操作尚未保存';
    $('recoveryText').textContent = !s.ready ? '为保留原有数据，写入已暂停。请重试读取。' : s.conflict ? '当前画面仍在。可先另存，再重新读取已保存的记录。' : '原记录仍在。重试保存；重新读取会放弃本次改动。';
    $('retryWrite').hidden = !s.ready || !s.pending || s.conflict;
    $('retryWrite').disabled = s.busy || localBusy;
    $('reload').textContent = s.ready ? '重新读取' : '重试读取';
    $('reload').disabled = s.busy || localBusy;
    $('recoveryBackup').disabled = s.busy || localBusy || !s.ready;
    $('pendingBackup').hidden = !s.pending;
    $('pendingBackup').disabled = s.busy || localBusy;
    $('rawBackup').hidden = s.ready || store.raw() == null;
    $('rawBackup').disabled = s.busy || localBusy;
    $('newGame').textContent = data.current ? '另开一局' : '开一局';
    $('addRound').hidden = selected !== 'current';
    $('addRound').disabled = allLocked || !g || g.rounds.length >= M.limits.rounds;
    $('undo').hidden = selected !== 'current';
    $('undo').disabled = allLocked || !g || !g.rounds.length;
    ['reportPreview', 'csvSave'].forEach(function (id) { $(id).disabled = allLocked || !g; });
    $('removeOld').hidden = selected === 'current' || !g;
    $('prev').disabled = allLocked || page === 0;
    $('next').disabled = allLocked || !g || (page + 1) * 8 >= g.rounds.length;
    $('applyImport').disabled = allLocked || !incoming;
  }
  function render() {
    var g = game();
    $('gameSelect').textContent = ''; var current = el('option', data.current ? '当前 · ' + data.current.title : '当前 · 尚未开局'); current.value = 'current'; $('gameSelect').appendChild(current);
    data.archived.forEach(function (old) { var o = el('option', '旧局 · ' + old.title + ' · ' + old.rounds.length + ' 轮'); o.value = 'old:' + old.id; $('gameSelect').appendChild(o); });
    $('gameSelect').value = selected;
    $('empty').hidden = !!g; $('matchCard').hidden = !g; $('historyCard').hidden = !g;
    if (g) {
      $('viewLabel').textContent = selected === 'current' ? '当前对局' : '已保存的旧局'; $('matchTitle').textContent = g.title;
      $('matchMeta').textContent = g.players.length + ' 人 · ' + g.rounds.length + ' 轮 · ' + (g.win === 'high' ? '高分胜' : '低分胜');
      $('ranking').textContent = '';
      M.standings(g).forEach(function (r) { var row = el('li', '', 'rankRow'); row.appendChild(el('span', g.rounds.length ? String(r.rank) : '·', 'rankNumber')); row.appendChild(el('span', r.name, 'playerName')); row.appendChild(el('strong', String(r.total), 'total')); row.setAttribute('aria-label', r.name + (g.rounds.length ? '，第 ' + r.rank + ' 名，' : '，尚未记分，') + r.total + ' 分'); $('ranking').appendChild(row); });
      page = Math.min(page, Math.max(0, Math.ceil(g.rounds.length / 8) - 1)); $('history').textContent = '';
      if (!g.rounds.length) $('history').appendChild(el('p', '还没有轮次，记下第一轮吧。', 'detail'));
      g.rounds.slice(page * 8, page * 8 + 8).forEach(function (r, i) {
        var index = page * 8 + i, row = el('article', '', 'round'); row.appendChild(el('h3', '第 ' + (index + 1) + ' 轮'));
        var list = el('div', '', 'roundScores'); g.players.forEach(function (p, j) { var v = el('div', p.name + '  '); v.appendChild(el('strong', (r.scores[j] > 0 ? '+' : '') + r.scores[j])); list.appendChild(v); }); row.appendChild(list);
        if (selected === 'current') { var actions = el('div', '', 'actions'), edit = el('button', '编辑本轮'), remove = el('button', '撤销本轮'); edit.setAttribute('aria-label', '编辑第 ' + (index + 1) + ' 轮'); remove.setAttribute('aria-label', '撤销第 ' + (index + 1) + ' 轮'); edit.onclick = function () { openRound(index); }; remove.onclick = function () { askRemoveRound(index); }; actions.appendChild(edit); actions.appendChild(remove); row.appendChild(actions); }
        $('history').appendChild(row);
      });
      $('pager').hidden = g.rounds.length <= 8; $('pageInfo').textContent = (page + 1) + ' / ' + Math.max(1, Math.ceil(g.rounds.length / 8));
    }
    controls();
  }
  function closeDialogs() { document.querySelectorAll('dialog[open]').forEach(function (d) { d.close(); }); }
  function afterCommit(promise) {
    controls(); return promise.then(function () { if (ended) return; data = store.snapshot(); if (successAction) successAction(); successAction = null; closeDialogs(); render(); say('已保存。'); }).catch(function (e) { if (ended) return; closeDialogs(); controls(); say('操作尚未完成。' + message(e), true); });
  }
  function commit(next, done) {
    if (locked()) return;
    try { successAction = done || null; afterCommit(store.commit(next)); } catch (e) { successAction = null; say(message(e), true); }
  }
  function load() {
    if (store.status().busy || localBusy || ended) return;
    var promise = store.load(); controls(); say('正在读取记录…');
    promise.then(function () { if (ended) return; data = store.snapshot(); selected = 'current'; page = 0; incoming = null; successAction = null; closeDialogs(); render(); say(''); if (!launchRead) { launchRead = true; readLaunch(); } }).catch(function (e) { if (!ended) { controls(); say('记录未能读取。' + message(e), true); } });
  }
  function ask(title, text, fn) { if (store.status().busy || localBusy) return; confirmAction = fn; $('confirmTitle').textContent = title; $('confirmText').textContent = text; $('confirmDialog').showModal(); $('confirmApply').disabled = false; }
  function openRound(index) {
    if (locked() || !data.current || selected !== 'current') return;
    editIndex = index; var g = data.current, r = g.rounds[index]; $('roundTitle').textContent = r ? '编辑第 ' + (index + 1) + ' 轮' : '记第 ' + (g.rounds.length + 1) + ' 轮'; $('scoreInputs').textContent = ''; $('roundError').textContent = '';
    g.players.forEach(function (p, j) { var row = el('div', '', 'scoreRow'), label = el('label', p.name), input = el('input'); input.id = 'score-' + j; input.type = 'text'; input.inputMode = 'text'; input.autocomplete = 'off'; input.spellcheck = false; input.maxLength = 9; input.required = true; input.value = r ? String(r.scores[j]) : ''; input.placeholder = '0'; label.htmlFor = input.id; row.appendChild(label); row.appendChild(input); $('scoreInputs').appendChild(row); }); $('roundDialog').showModal();
  }
  function askRemoveRound(index) { if (locked()) return; ask('撤销第 ' + (index + 1) + ' 轮？', '这一轮的分数会移除，后续轮次依次前移，名次重新计算。', function () { commit(M.removeRound(data, index)); }); }
  function deliver(name, mime, text, workbench, statusId) {
    if (store.status().busy || localBusy || ended) return;
    localBusy = true; controls(); var target = statusId ? $(statusId) : $('status'); target.textContent = workbench ? '正在送到工作台…' : '正在打开保存位置…';
    Promise.resolve().then(function () { if (!J) throw new Error('请在锦盒中导出。'); return workbench ? J.workbench.put({type: 'text', name: name, text: text}).then(function (r) { if (!r || !r.id) throw new Error('工作台没有返回材料，请重试。'); return true; }) : J.saveFile(name, mime, M.bytes(text)); }).then(function (ok) { if (!ended) target.textContent = ok ? workbench ? '已送到工作台。' : '文件已保存。' : ''; }).catch(function (e) { if (!ended) target.textContent = '导出未完成。' + message(e); }).then(function () { localBusy = false; if (!ended) controls(); });
  }
  function backup() { deliver('桌游记分全部-' + Date.now() + '.json', 'application/json', M.encode(data), false); }
  function openImport(raw) {
    if (locked()) return;
    incoming = null; $('importText').value = raw || ''; $('importStatus').textContent = ''; $('importPreview').hidden = true; $('applyImport').hidden = true; $('importDialog').showModal(); if (raw) checkImport();
  }
  function checkImport() {
    if (locked()) return; incoming = null; $('applyImport').hidden = true; $('importPreview').hidden = true;
    try {
      var candidate = M.parse($('importText').value), box = $('importPreview'); box.textContent = '';
      box.appendChild(el('p', '将替换当前局和全部旧局。当前有 ' + (data.current ? '1 局进行中、' : '') + data.archived.length + ' 局旧局。'));
      box.appendChild(el('p', '导入：' + (candidate.current ? '1 局进行中，' : '无进行中对局，') + candidate.archived.length + ' 局旧局。'));
      (candidate.current ? [candidate.current] : []).concat(candidate.archived).forEach(function (g) {
        box.appendChild(el('p', g.title + ' · ' + g.players.length + ' 人 · ' + g.rounds.length + ' 轮 · ' + (g.win === 'high' ? '高分胜' : '低分胜')));
        box.appendChild(el('p', M.standings(g).map(function (r) { return r.name + ' ' + r.total + ' 分'; }).join(' / '), 'detail'));
      });
      incoming = candidate; $('importStatus').textContent = '检查通过。确认前不会改动记录，建议先备份原有记录。'; box.hidden = false; $('applyImport').hidden = false; controls();
    } catch (e) { $('importStatus').textContent = message(e); }
  }
  function pick() {
    if (locked()) return; localBusy = true; controls();
    Promise.resolve().then(function () { return J.pickText('application/json'); }).then(function (r) { localBusy = false; if (ended) return; controls(); if (r) openImport(r.text); }).catch(function (e) { localBusy = false; if (!ended) { controls(); say('文件未能打开。' + message(e), true); } });
  }
  function readLaunch() {
    if (!J || !J.launchParams) return;
    localBusy = true; controls();
    J.launchParams().then(function (p) {
      if (ended) return null;
      var ids = p.workbenchIds || (p.workbenchId ? [p.workbenchId] : []);
      if (ids.length > 1) throw new Error('请一次送入一份桌游记分 JSON 备份。');
      if (ids.length) return J.workbench.take(ids[0]).then(function (v) { if (!v || v.type !== 'text') throw new Error('只接收 JSON 文本备份。'); return v.text; });
      if (typeof p.text === 'string') return p.text;
      if (p.uri) throw new Error('请用“打开 JSON”重新选择这份备份。'); return null;
    }).then(function (text) { localBusy = false; if (!ended) { controls(); if (text != null) openImport(text); } }).catch(function (e) { localBusy = false; if (!ended) { controls(); say('接入未完成。' + message(e), true); } });
  }
  $('newGame').onclick = function () { if (locked()) return; $('archiveNotice').hidden = !data.current; $('setupApply').textContent = data.current ? '保存旧局并开局' : '开始这局'; $('gameName').value = data.current ? data.current.title : '今晚这一局'; $('playerNames').value = data.current ? data.current.players.map(function (p) { return p.name; }).join('\n') : ''; $('win').value = data.current ? data.current.win : 'high'; $('setupError').textContent = ''; $('setupDialog').showModal(); };
  $('setupForm').onsubmit = function (e) { e.preventDefault(); if (locked()) return; try { var names = $('playerNames').value.split(/\r?\n/); if (names.some(function (n) { return !n.trim(); })) throw new Error('每行填写一位玩家，请去掉空行。'); var next = M.restart(data, M.create($('gameName').value, names, $('win').value)); commit(next, function () { selected = 'current'; page = 0; }); } catch (x) { $('setupError').textContent = message(x); } };
  $('addRound').onclick = function () { openRound(-1); };
  $('roundForm').onsubmit = function (e) { e.preventDefault(); if (locked()) return; try { var scores = data.current.players.map(function (p, i) { return M.score($('score-' + i).value); }); commit(M.setRound(data, editIndex, scores), function () { if (editIndex < 0) page = Math.floor((data.current.rounds.length - 1) / 8); }); } catch (x) { $('roundError').textContent = message(x); } };
  $('undo').onclick = function () { if (!locked() && data.current && data.current.rounds.length) askRemoveRound(data.current.rounds.length - 1); };
  $('confirmApply').onclick = function () { if (store.status().busy || localBusy || !confirmAction) return; var action = confirmAction; confirmAction = null; try { action(); } catch (e) { say(message(e), true); } };
  $('retryWrite').onclick = function () { if (!store.status().busy && !localBusy) afterCommit(store.retry()); };
  $('reload').onclick = function () { if (!store.status().ready && !store.status().pending) load(); else ask('重新读取记录？', '这次尚未保存的操作会放弃，以已保存的记录为准。需要保留当前画面时，请先另存。', load); };
  $('recoveryBackup').onclick = backup; $('backup').onclick = backup;
  $('pendingBackup').onclick = function () { var candidate = store.candidate(); if (candidate) deliver('桌游记分未保存内容-' + Date.now() + '.json', 'application/json', M.encode(candidate), false); };
  $('rawBackup').onclick = function () { if (store.raw() != null) deliver('桌游记分未读取原文.txt', 'text/plain', store.raw(), false); };
  $('gameSelect').onchange = function () { if (locked()) return; selected = $('gameSelect').value; page = 0; render(); };
  $('prev').onclick = function () { if (!locked() && page > 0) { page--; render(); } };
  $('next').onclick = function () { if (!locked() && game() && (page + 1) * 8 < game().rounds.length) { page++; render(); } };
  $('removeOld').onclick = function () { if (locked() || selected === 'current') return; var index = data.archived.map(function (g) { return 'old:' + g.id; }).indexOf(selected); if (index < 0) return; ask('移除这局旧局？', data.archived[index].title + '的全部轮次将从本机记录移除。需要保留时，请先备份全部 JSON。', function () { commit(M.removeArchived(data, index), function () { selected = 'current'; page = 0; }); }); };
  $('pasteJson').onclick = function () { openImport(''); }; $('pickJson').onclick = pick; $('checkImport').onclick = checkImport;
  $('importText').oninput = function () { incoming = null; $('applyImport').hidden = true; $('importPreview').hidden = true; $('importStatus').textContent = '内容已更改，请重新检查。'; };
  $('applyImport').onclick = function () { if (!locked() && incoming) commit(incoming, function () { selected = 'current'; page = 0; incoming = null; }); };
  $('reportPreview').onclick = function () { if (locked() || !game()) return; reportGame = M.game(game()); $('reportText').textContent = M.report(reportGame); $('reportStatus').textContent = ''; $('reportDialog').showModal(); };
  $('csvSave').onclick = function () { if (!locked() && game()) deliver('桌游记分-' + Date.now() + '.csv', 'text/csv', M.csv(game()), false); };
  $('textSave').onclick = function () { if (reportGame) deliver('桌游战报-' + Date.now() + '.txt', 'text/plain', M.report(reportGame), false, 'reportStatus'); };
  $('textWorkbench').onclick = function () { if (reportGame) deliver('桌游战报.txt', 'text/plain', M.report(reportGame), true, 'reportStatus'); };
  $('csvWorkbench').onclick = function () { if (reportGame) deliver('桌游记分.csv', 'text/plain', M.csv(reportGame), true, 'reportStatus'); };
  document.querySelectorAll('[data-close]').forEach(function (b) { b.onclick = function () { if (!store.status().busy && !localBusy) { var id = b.getAttribute('data-close'); if (id === 'importDialog') incoming = null; $(id).close(); } }; });
  document.querySelectorAll('dialog').forEach(function (d) { d.addEventListener('cancel', function (e) { if (store.status().busy || localBusy) e.preventDefault(); else if (d.id === 'importDialog') incoming = null; }); });
  if (J && J.onBack) J.onBack(function () { var dialogs = document.querySelectorAll('dialog[open]'); if (dialogs.length) { if (!store.status().busy && !localBusy) { var last = dialogs[dialogs.length - 1]; if (last.id === 'importDialog') incoming = null; last.close(); } return true; } return store.status().busy || localBusy; });
  window.addEventListener('pagehide', function () { ended = true; store.cancel(); });
  render(); load();
}());
