/* Pure, bounded match model. No storage, DOM, network or external dependencies. */
(function (root) {
  'use strict';
  var LIMIT = {bytes: 800000, games: 30, players: 12, rounds: 200, score: 1000000};
  function fail(message) { throw new Error(message); }
  function object(x, keys) {
    if (!x || Object.prototype.toString.call(x) !== '[object Object]') fail('记录结构不完整。');
    var actual = Object.keys(x).sort(), expected = keys.slice().sort();
    if (actual.join('|') !== expected.join('|')) fail('记录字段不完整或包含不支持的字段。');
  }
  function utf8(s) {
    var n = 0, i, c;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c >= 55296 && c <= 56319) {
        if (++i >= s.length || s.charCodeAt(i) < 56320 || s.charCodeAt(i) > 57343) fail('文字含不完整字符。');
        n += 4;
      } else { if (c >= 56320 && c <= 57343) fail('文字含不完整字符。'); n += c < 128 ? 1 : c < 2048 ? 2 : 3; }
    }
    return n;
  }
  function bytes(s) {
    utf8(s); var out = [], i, n;
    for (i = 0; i < s.length; i++) {
      n = s.charCodeAt(i);
      if (n >= 55296 && n <= 56319) n = (n - 55296) * 1024 + s.charCodeAt(++i) - 56320 + 65536;
      if (n < 128) out.push(n);
      else if (n < 2048) out.push(192 | (n >> 6), 128 | (n & 63));
      else if (n < 65536) out.push(224 | (n >> 12), 128 | ((n >> 6) & 63), 128 | (n & 63));
      else out.push(240 | (n >> 18), 128 | ((n >> 12) & 63), 128 | ((n >> 6) & 63), 128 | (n & 63));
    }
    return new Uint8Array(out);
  }
  function text(s, max) {
    if (typeof s !== 'string' || !s.trim() || s.length > max || /[\x00-\x1f\x7f]/.test(s)) fail('名称须为 1–' + max + ' 字的单行文字。');
    utf8(s); return s;
  }
  function id(s) { if (typeof s !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(s)) fail('记录编号无效。'); return s; }
  function integer(n, min, max) { if (typeof n !== 'number' || !isFinite(n) || Math.floor(n) !== n || n < min || n > max) fail('分数或时间超出范围。'); return n; }
  function score(s) {
    if (typeof s !== 'string' || !/^[+-]?(0|[1-9]\d*)$/.test(s.trim())) fail('每位玩家都要填写整数，可用负号。');
    return integer(Number(s.trim()), -LIMIT.score, LIMIT.score);
  }
  function game(x) {
    object(x, ['id', 'title', 'createdAt', 'win', 'players', 'rounds']);
    if (x.win !== 'high' && x.win !== 'low') fail('胜负规则无效。');
    if (!Array.isArray(x.players) || x.players.length < 2 || x.players.length > LIMIT.players) fail('每局需要 2–12 位玩家。');
    var seen = Object.create(null), names = Object.create(null);
    var players = x.players.map(function (p) {
      object(p, ['id', 'name']); var key = id(p.id), name = text(p.name, 24);
      if (seen[key] || names[name.trim()]) fail('玩家编号或名称重复。');
      seen[key] = true; names[name.trim()] = true; return {id: key, name: name};
    });
    if (!Array.isArray(x.rounds) || x.rounds.length > LIMIT.rounds) fail('一局最多 200 轮，请保存后另开一局。');
    var roundIds = Object.create(null);
    var rounds = x.rounds.map(function (r) {
      object(r, ['id', 'at', 'scores']); var key = id(r.id);
      if (roundIds[key]) fail('轮次编号重复。'); roundIds[key] = true;
      if (!Array.isArray(r.scores) || r.scores.length !== players.length) fail('轮次分数与玩家人数不符。');
      return {id: key, at: integer(r.at, 0, 8640000000000000), scores: r.scores.map(function (n) { return integer(n, -LIMIT.score, LIMIT.score); })};
    });
    return {id: id(x.id), title: text(x.title, 48), createdAt: integer(x.createdAt, 0, 8640000000000000), win: x.win, players: players, rounds: rounds};
  }
  function validate(x) {
    object(x, ['format', 'version', 'current', 'archived']);
    if (x.format !== 'jinhe-scoreboard' || x.version !== 1) fail('只支持桌游记分第 1 版 JSON 备份。');
    if (!Array.isArray(x.archived) || x.archived.length > LIMIT.games) fail('最多保存 30 局旧局。');
    var current = x.current === null ? null : game(x.current), seen = Object.create(null);
    if (current) seen[current.id] = true;
    var archived = x.archived.map(function (g) { var out = game(g); if (seen[out.id]) fail('对局编号重复。'); seen[out.id] = true; return out; });
    var out = {format: 'jinhe-scoreboard', version: 1, current: current, archived: archived};
    if (utf8(JSON.stringify(out)) > LIMIT.bytes) fail('备份超过 800,000 字节，请先另存并整理旧局。');
    return out;
  }
  function empty() { return {format: 'jinhe-scoreboard', version: 1, current: null, archived: []}; }
  function parse(raw) {
    if (typeof raw !== 'string' || raw.length > LIMIT.bytes || utf8(raw) > LIMIT.bytes) fail('JSON 须不超过 800,000 字节。');
    var x; try { x = JSON.parse(raw.replace(/^\uFEFF/, '')); } catch (e) { fail('JSON 无法读取，原有记录未改动。'); }
    return validate(x);
  }
  function encode(x) { return JSON.stringify(validate(x)); }
  function uid() { return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10); }
  function create(title, names, win) { return game({id: uid(), title: title.trim(), createdAt: Date.now(), win: win, players: names.map(function (s) { return {id: uid(), name: s.trim()}; }), rounds: []}); }
  function restart(state, next) {
    var x = validate(state); if (x.current) { if (x.archived.length >= LIMIT.games) fail('旧局已达 30 局，请先保存完整备份，再移除一局。'); x.archived.unshift(x.current); }
    x.current = game(next); return validate(x);
  }
  function setRound(state, index, scores) {
    var x = validate(state); if (!x.current) fail('请先开一局。');
    integer(index, -1, x.current.rounds.length - 1);
    var r = index < 0 ? {id: uid(), at: Date.now(), scores: scores} : {id: x.current.rounds[index].id, at: x.current.rounds[index].at, scores: scores};
    if (index < 0) x.current.rounds.push(r); else x.current.rounds[index] = r;
    return validate(x);
  }
  function removeRound(state, index) { var x = validate(state); if (!x.current) fail('请先开一局。'); integer(index, 0, x.current.rounds.length - 1); x.current.rounds.splice(index, 1); return validate(x); }
  function removeArchived(state, index) { var x = validate(state); integer(index, 0, x.archived.length - 1); x.archived.splice(index, 1); return validate(x); }
  function standings(g) {
    g = game(g); var rows = g.players.map(function (p, i) { return {id: p.id, name: p.name, total: g.rounds.reduce(function (sum, r) { return sum + r.scores[i]; }, 0), seat: i}; });
    rows.sort(function (a, b) { return (g.win === 'high' ? b.total - a.total : a.total - b.total) || a.seat - b.seat; });
    rows.forEach(function (r, i) { r.rank = i && r.total === rows[i - 1].total ? rows[i - 1].rank : i + 1; }); return rows;
  }
  function report(g) {
    g = game(g); var rules = g.win === 'high' ? '高分胜' : '低分胜';
    return g.title + '\n' + g.players.length + ' 人 · ' + g.rounds.length + ' 轮 · ' + rules + (g.rounds.length ? '' : '\n尚未记分') + '\n\n' + standings(g).map(function (r) { return '第 ' + r.rank + ' 名  ' + r.name + '  ' + r.total + ' 分'; }).join('\n') + '\n\n' + g.rounds.map(function (r, i) { return '第 ' + (i + 1) + ' 轮：' + g.players.map(function (p, j) { return p.name + ' ' + (r.scores[j] > 0 ? '+' : '') + r.scores[j]; }).join(' / '); }).join('\n');
  }
  function cell(s) { s = String(s); if (/^[\s]*[=+\-@]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; }
  function csv(g) {
    g = game(g); var rows = [['对局', g.title], ['胜负', g.win === 'high' ? '高分胜' : '低分胜'], ['轮次'].concat(g.players.map(function (p) { return p.name; }))];
    g.rounds.forEach(function (r, i) { rows.push(['第' + (i + 1) + '轮'].concat(r.scores)); });
    rows.push(['合计'].concat(g.players.map(function (p, j) { return g.rounds.reduce(function (s, r) { return s + r.scores[j]; }, 0); })));
    return '\uFEFF' + rows.map(function (row) { return row.map(function (v) { return typeof v === 'number' ? String(v) : cell(v); }).join(','); }).join('\r\n');
  }
  var api = {limits: LIMIT, utf8: utf8, bytes: bytes, score: score, game: game, validate: validate, empty: empty, parse: parse, encode: encode, create: create, restart: restart, setRound: setRound, removeRound: removeRound, removeArchived: removeArchived, standings: standings, report: report, csv: csv};
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Scoreboard = api;
}(typeof window !== 'undefined' ? window : this));
