/* ============================================================
   乐器盒 · 声音引擎(纯 Web Audio,不引任何外部资源)
   ============================================================
   一句话说明这一份为什么这么写:
   手机上装不下 35 样乐器的采样(每样哪怕只录一个八度,也是几百 MB),
   所以**全部靠合成** —— 而合成要好听,靠的不是"一个正弦波",是这三件事:
     ① 弹拨用 Karplus-Strong(噪声激励 + 带阻尼的延迟线),它天生就是弦;
     ② 拉弦/吹管用自定义泛音列(PeriodicWave)+ 慢起音 + 揉弦 LFO;
     ③ 打击用非谐泛音(钟、木鱼那种"不是整数倍"的泛音才是金属/木头的味道)。
   最后统一过一层生成出来的混响,干/湿可调。

   对外只有 noteOn / release / stopAll / setVolume / setWet 这几个动作,
   UI 那一份(app.js)不许自己碰 AudioContext。

   定弦一律照真乐器写,并注了出处(见下面每样乐器的 desc 与注释):
     古筝 21 弦 D 调五声 = D2(73.42Hz) … D6,四个八度;
     古琴正调七弦散音 = C2 D2 F2 G2 A2 C3 D3;
     中阮 G d a e¹、三弦(书弦)G d g、琵琶 A d e a、马头琴内弦 d¹ 外弦 a。
   —— 民乐的"大字组/小字组"换算成 MIDI 很容易差一个八度,
      差了就整件乐器听着都不对,所以这一块是逐个核对过的。
   ============================================================ */
(function (root) {
  'use strict';

  var ctx = null, master = null, comp = null, dryBus = null, wetBus = null, conv = null;
  var noiseBuf = null;
  var waves = {};
  var live = [];                 /* 在响的声音,超了就先放掉最老的那个 */
  var MAX_LIVE = 40;
  var vol = 0.9, wet = 0.18;
  /* 三个只读的自检口子:还响着几个、最后发出的那个音的实际频率、打拍打了几下。
     它们不是给页面用的(页面有 voice.alive()/vib()),是给"自检要断言模型状态"用的 ——
     不然"泛音真的高了一个八度吗""松手之后弦还在响吗"只能靠耳朵,而耳朵不能进回归清单。 */
  var lastHz = 0, lastKind = '', lastVel = 0, tickCount = 0;

  /* ---------------- 基础设施 ---------------- */

  function ensure() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    /* interactive = 让系统给最小的缓冲,手机上按下去到出声的延迟差得很多 */
    try { ctx = new AC({ latencyHint: 'interactive' }); }
    catch (e) { ctx = new AC(); }
    master = ctx.createGain(); master.gain.value = vol;
    comp = ctx.createDynamicsCompressor();
    /* knee 别开太大:26dB 那种等于从很轻就开始压,整首曲子动态被压平。
       10dB 只在真的过响时才介入,弱奏的呼吸感还在。 */
    comp.threshold.value = -18; comp.knee.value = 10; comp.ratio.value = 3;
    comp.attack.value = 0.005; comp.release.value = 0.25;
    dryBus = ctx.createGain(); dryBus.gain.value = 1 - wet * 0.35;
    wetBus = ctx.createGain(); wetBus.gain.value = wet;
    conv = ctx.createConvolver(); conv.buffer = makeIR(1.9, 2.6);
    master.connect(dryBus); dryBus.connect(comp);
    master.connect(conv); conv.connect(wetBus); wetBus.connect(comp);
    /* Compressor is not a peak limiter: dense chords can still exceed 1.
       Keep ordinary levels unchanged; only soften peaks above 0.72, with
       4x input headroom so WaveShaper's own input bounds cannot hard-clip. */
    var headroom = ctx.createGain(); headroom.gain.value = 0.25;
    var ceiling = ctx.createWaveShaper(), curve = new Float32Array(65537);
    for (var ci = 0; ci < curve.length; ci++) {
      var x = (ci / (curve.length - 1) * 2 - 1) * 4, ax = Math.abs(x);
      curve[ci] = (x < 0 ? -1 : 1) * (ax <= 0.72 ? ax : 0.72 + 0.24 * (1 - Math.exp(-(ax - 0.72) / 0.24)));
    }
    ceiling.curve = curve;
    comp.connect(headroom); headroom.connect(ceiling); ceiling.connect(ctx.destination);
    return ctx;
  }

  /** 手机上 AudioContext 必须由一次真实手势唤醒,否则一直是 suspended */
  function unlock() {
    ensure();
    if (ctx && ctx.state === 'suspended' && !ctx.startRendering) {
      try { var resumed = ctx.resume(); if (resumed && resumed.catch) resumed.catch(function () { }); } catch (e) { }
    }
    return ctx;
  }

  /**
   * 混响用的脉冲响应。
   * 纯白噪声的尾巴听着像"嘶——",缺两样东西:
   *   ① 早期反射 —— 开头那几下离散回声才是"这屋子多大"的信息;
   *   ② 高频吸收 —— 空气与墙先把高音吃掉,所以尾巴要越来越闷。
   * 两声道的时间点错开一点,才有宽度(不然是一个点,不是一片空间)。
   */
  function makeIR(sec, decay) {
    var sr = ctx.sampleRate, n = Math.max(1, Math.floor(sr * sec));
    var b = ctx.createBuffer(2, n, sr);
    var ER = [0.0049, 0.0083, 0.0121, 0.0173, 0.0231, 0.0297, 0.0371];
    for (var ch = 0; ch < 2; ch++) {
      var d = b.getChannelData(ch);
      var lp = 0;
      for (var i = 0; i < n; i++) {
        var t = i / n;
        var env = Math.pow(1 - t, decay) * (1 - t * 0.18);
        lp += ((Math.random() * 2 - 1) - lp) * (0.34 - 0.29 * t);  /* 越往后越闷 */
        d[i] = lp * env;
      }
      for (var k = 0; k < ER.length; k++) {
        var idx = Math.floor((ER[k] + (ch ? 0.0013 : 0)) * sr);
        if (idx < n) d[idx] += (k % 2 ? -0.62 : 0.7) * (1 - k * 0.11) * (ch ? 0.88 : 1);
      }
    }
    return b;
  }

  function noise() {
    if (noiseBuf) return noiseBuf;
    var sr = ctx.sampleRate, n = Math.floor(sr * 2);
    noiseBuf = ctx.createBuffer(1, n, sr);
    var d = noiseBuf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return noiseBuf;
  }

  function freq(midi) { return 440 * Math.pow(2, (midi - 69) / 12); }
  function hzOf(v) { return v && v.hz ? v.hz : 0; }

  /**
   * 音高补偿 —— 这套合成**天生低音比高音响一个数量级**。
   * 实测(2026-10-12,古筝逐根弦单独发、vel 0.9):最低四颗的 RMS 均值 0.102,
   * 最高四颗 0.010 —— **差 10.2 倍,也就是 20 dB**。原因不神秘:低音弦的延迟线长、
   * 阻尼放得慢,激励又是按峰值归一化的,于是它一路维持在 ±0.85 附近不下来;
   * 高音弦几毫秒就衰减掉了。
   *
   * 为什么非要治:手机的小喇叭驮不动 70~150Hz 那么大的振幅 —— 一碰到低音就机械过载,
   * 听感是"破音、噼里啪啦"。用户的原话:"低音的时候会破音,类似音噼里啪啦"。
   *
   * 这条曲线**只压不抬**:57(A3)以上原样不动 —— 不能抬高音。高音的峰值已经在 0.4~0.6,
   * 再抬就轮到它们顶头了(实测算过:抬 2 倍会有几颗越过 1.0)。
   * 往下每低一个八度收 4 dB,最低收到 0.4 为止(-8 dB)。
   * 收完之后整条音域大约平到 3 dB/八度以内,而那正是真实乐器本来的倾斜。
   */
  function pitchGain(m) {
    if (m == null || m >= 57) return 1;
    var g = Math.pow(10, (m - 57) / 12 * 4 / 20);
    return g < 0.4 ? 0.4 : g;
  }

  var NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  var FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
  function midiName(m) { return NAMES[((m % 12) + 12) % 12] + (Math.floor(m / 12) - 1); }
  function midiNameFlat(m) { return FLAT[((m % 12) + 12) % 12] + (Math.floor(m / 12) - 1); }

  /* ---------------- 泛音列 → 波形 ---------------- */

  function waveOf(inst, band) {
    var key = inst.id + '#' + band;
    if (waves[key]) return waves[key];
    var h = inst.synth.harm || [1];
    var n = Math.min(24, h.length);
    var re = new Float32Array(n + 1), im = new Float32Array(n + 1);
    for (var i = 0; i < n; i++) {
      /* 弱奏(band 0)把高次泛音压掉,强奏(band 2)抬起来 ——
         真实乐器就是这样:弹得重不只是"更响",是"更亮"。 */
      var k = i === 0 ? 1 : (band === 0 ? Math.pow(0.62, i) : (band === 2 ? Math.min(1.5, Math.pow(1.06, i)) : 1));
      im[i + 1] = h[i] * k;
    }
    var w = ctx.createPeriodicWave(re, im);
    waves[key] = w;
    return w;
  }

  /* ---------------- Karplus-Strong(弹拨) ----------------
     延迟线长度用**小数**插值,不然高音区会被整数采样长度拉跑调
     (2000Hz 那一档能差出好几音分,耳朵很挑)。                       */

  /* ---- 缓存:按**字节**封顶,不再按条数 ----
     从前写的是"最多 32 条"。一条 3 秒的缓冲是 3×44100×4 = 529 KB,32 条看着不吓人;
     可一首曲子要用到的 (乐器·音高·时值档·力度档) 组合轻松超过 32 种 —— 一超,
     先算的那批就被挤出去,**演奏到一半每一颗音都要重新算一遍**。
     现场重新算缓冲 = 主线程被堵住 = 手机上音频欠载,听感就是"沙拉沙拉"。
     现在:总量封顶 48 MB(手机装得下),条数只留一个**下限** 32(指头乱刮时别把它抖空)。 */
  var ksCache = {}, ksOrder = [], ksBytes = 0, ksHit = 0, ksMiss = 0;
  var KS_MIN_ENTRIES = 32, KS_MAX_BYTES = 48 * 1024 * 1024;
  function ksTrim() {
    while (ksOrder.length > KS_MIN_ENTRIES && ksBytes > KS_MAX_BYTES) {
      var k = ksOrder.shift(), b = ksCache[k];
      if (b) ksBytes -= b.length * 4;
      delete ksCache[k];
    }
  }
  /** 这一颗音要用多长的缓冲 —— **唯一出处**:ksVoice 与 warm() 都读它,两边不许各算各的 */
  function wantLen(inst, midi, dur, kind) {
    var S = inst.synth, f = freq(midi);
    var want = Math.max(0.7, ksLen(S, f));
    if (kind === 'harm') want = Math.min(want, 1.15);
    if (kind === 'mute') want = 0.22;
    if (dur) want = Math.max(want, Math.min(S.len || 3, dur + 1.1));
    return want;
  }
  function ksKey(inst, midi, dur, vel, kind) {
    var band = vel < 0.45 ? 0 : (vel < 0.75 ? 1 : 2);
    return inst.id + '|' + midi + '|' + Math.round(dur * 8) + '|' + band + '|' + (kind || '');
  }
  function ksBuffer(inst, midi, dur, vel, kind) {
    var S = inst.synth;
    var band = vel < 0.45 ? 0 : (vel < 0.75 ? 1 : 2);
    var key = ksKey(inst, midi, dur, vel, kind);
    var hit = ksCache[key];
    if (hit) { ksHit++; return hit; }
    ksMiss++;
    var b = genKS(S, freq(midi), dur, band);
    ksCache[key] = b; ksOrder.push(key); ksBytes += b.length * 4;
    ksTrim();
    return b;
  }

  /**
   * **预算缓冲**:开演之前把这一首要用的拨弦缓冲先算出来。
   * 算的时候现场那一侧就没有人在生成缓冲了 —— 慢手机上的"一串爆音/沙拉沙拉"、
   * 以及"开头一句句不响",根子是同一个:主线程在**该出声的时候**被计算堵住。
   * 返回 1 = 这一条真的新算了;0 = 本来就在缓存里 / 这件乐器不需要(只有弹拨类要)。
   */
  function warm(inst, midi, dur, vel, kind) {
    if (!unlock()) return 0;
    if (!inst || !inst.synth || inst.synth.kind !== 'ks') return 0;
    if (midi == null || midi < 21 || midi > 108) return 0;
    /* **必须与 ksVoice 用同一把钥匙**:那边传进 ksBuffer 的是 want(= wantLen 的结果),
       不是原始 dur。这里若拿原始 dur 去算键,预热的每一条都落在别的格子里 ——
       白算一遍,现场照样现算(这一条 2026-10-11 真踩过,量出来"合计耗时"纹丝不动)。 */
    var m2 = kind === 'harm' ? midi + 12 : midi;
    var want = wantLen(inst, m2, dur, kind);
    if (ksCache[ksKey(inst, m2, want, vel, kind)]) return 0;
    ksBuffer(inst, m2, want, vel, kind);
    return 1;
  }

  /** 弦越长、越粗,余韵越长;高音区本来掉得快,缓冲区就别浪费内存去算 */
  function ksLen(S, f) {
    return Math.max(0.85, Math.min(S.len || 3, 3.6 * Math.pow(f / 220, -0.34)));
  }

  function genKS(S, f, dur, band) {
    var sr = ctx.sampleRate;
    var n = Math.max(1, Math.floor(sr * dur));
    var N = Math.max(2, Math.floor(sr / f));      /* 整数部分 */
    var frac = sr / f - N;                         /* 小数部分 */
    var M = N + 3;
    var line = new Float32Array(M);
    var prev = 0, i;

    /* 激励:一段噪声过一级低通 —— bright 越小越"闷"(古琴),越大越"亮"(琵琶)。
       拨得重的时候激励更亮、衰减略快(弦被拉得振幅大,高频先耗掉)。 */
    var br = S.bright == null ? 0.6 : S.bright;
    br = Math.max(0.12, Math.min(0.95, br * (band === 0 ? 0.68 : band === 2 ? 1.22 : 1)));
    for (i = 0; i < M; i++) {
      prev = prev + ((Math.random() * 2 - 1) - prev) * br;
      line[i] = prev;
    }
    var mean = 0;
    for (i = 0; i < M; i++) mean += line[i];
    mean /= M;
    var mx = 0;
    for (i = 0; i < M; i++) { line[i] -= mean; mx = Math.max(mx, Math.abs(line[i])); }
    if (mx > 0) for (i = 0; i < M; i++) line[i] /= mx;

    var buf = ctx.createBuffer(1, n, sr);
    var d = buf.getChannelData(0);
    var damp = S.damp == null ? 0.5 : S.damp;
    var d2 = S.damp2 == null ? 0.5 : S.damp2;
    var dec = S.decay == null ? 0.996 : S.decay;
    if (band === 2) { d2 = Math.min(0.9, d2 + 0.08); dec -= 0.0006; }
    if (band === 0) { d2 = Math.max(0.2, d2 - 0.06); }
    var w = 0, last = 0, y, y2, v;

    function read(k) {
      var a = line[(w + k) % M], b2 = line[(w + k + 1) % M];
      return a * (1 - frac) + b2 * frac;
    }
    for (i = 0; i < n; i++) {
      y = read(1); y2 = read(2);
      v = dec * ((1 - damp) * y + damp * y2);
      last = d2 * v + (1 - d2) * last;       /* 高频掉得比低频快,这是弦的物理 */
      line[w] = last;
      d[i] = y;
      w = (w + 1) % M;
    }
    /* 收尾淡出,免得缓冲区截断处"啪"一声 */
    var fade = Math.min(n, Math.floor(sr * 0.03));
    for (i = 0; i < fade; i++) d[n - 1 - i] *= i / fade;
    /* **开头也要淡入** —— 原来是"尾巴有淡出、头没有",于是缓冲从 0 一步跨到 ±0.5
       (实测:只用 5 个样本、0.1 毫秒就冲到峰值;低音弦因为归一化后振幅最大,那一步最狠)。
       这一步在手机上就是一声"啪",**每次换音都响一下** —— 用户的原话是"一换音就有爆破音"。
       1.2 毫秒的淡入把它摊平到每样本 0.01 的坡度:听感上还是"拨"的那一下,但"啪"没了。
       (1.2ms 是权衡:再短压不住那一步,再长高音区会被吃掉"颗粒感"——最高那几根弦
        一个周期才 0.29ms,2ms 以上就等于把拨弦的起音削平了。) */
    var atk = Math.min(Math.round(sr * 0.0012), Math.floor(n / 8));
    for (i = 0; i < atk; i++) d[i] *= i / atk;
    return buf;
  }

  /* ---------------- 三种发声体 ---------------- */

  /**
   * 弹拨与击弦。kind:
   *   'harm' 泛音 —— 真琴上泛音是"轻触弦长的 1/2 处",出来的是**高一个八度**、
   *          余韵短一半、音色更薄的一层(不是"把原音调高",高音弦的泛音本来就在更高处);
   *   'mute' 闷音 —— 掌根压住弦,余韵只剩一两百毫秒,而且闷(高音被吃掉)。
   */
  function ksVoice(inst, midi, vel, when, dur, kind, dst) {
    var S = inst.synth, f = freq(midi);
    if (kind === 'harm') f *= 2;
    /* 缓冲长度**只从 wantLen 取**(与 warm() 同一个出处),别在这儿再算一遍 */
    var m2 = kind === 'harm' ? midi + 12 : midi;
    var want = wantLen(inst, m2, dur, kind);
    var buf = ksBuffer(inst, m2, want, vel, kind);
    var src = ctx.createBufferSource(); src.buffer = buf;
    var lp = ctx.createBiquadFilter();
    var tp = (S.tone || 4200) * (kind === 'harm' ? 1.5 : kind === 'mute' ? 0.55 : 1);
    lp.type = 'lowpass'; lp.frequency.value = Math.min(16000, tp * (0.7 + 0.5 * vel)); lp.Q.value = 0.4;
    var pk = ctx.createBiquadFilter();
    pk.type = 'peaking'; pk.frequency.value = S.body || 240; pk.Q.value = 1.0; pk.gain.value = S.bodyGain == null ? 5 : S.bodyGain;
    var g = ctx.createGain();
    g.gain.value = (kind === 'mute' ? 0.7 : kind === 'harm' ? 0.68 : 0.85) * vel * (inst.gain || 1) * pitchGain(m2);  /* 泛音响的是高八度(m2) */
    src.connect(lp); lp.connect(pk); pk.connect(g); g.connect(dst || master);
    src.start(when);
    var end = when + buf.duration;
    if (dur && dur + 0.2 < buf.duration) {
      /* 谱子里写明了时值:到点收住。**收不是"切"** —— 0.24 秒的淡出才像弦自己衰减,
         0.14 秒那种听着就是一扇门被关上(句尾那一下尤其明显)。 */
      var fade = 0.24;
      if (when + dur + fade > when + buf.duration) fade = Math.max(0.08, buf.duration - dur - 0.02);
      g.gain.setValueAtTime(g.gain.value, when + dur);
      g.gain.linearRampToValueAtTime(0.0001, when + dur + fade);
      end = when + dur + fade + 0.02;
    }
    try { src.stop(end + 0.02); } catch (e) { }
    return { osc: null, gain: g, src: src, end: end, base: midi, lp: lp, hz: f };
  }

  function addVoice(inst, midi, vel, when, dur, dst) {
    var S = inst.synth, f = freq(midi);
    var band = vel < 0.45 ? 0 : (vel < 0.75 ? 1 : 2);
    var osc = ctx.createOscillator();
    osc.setPeriodicWave(waveOf(inst, band));
    osc.frequency.setValueAtTime(f, when);

    var lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    var top = Math.min(17000, (S.lp ? S.lp.f : 6000) * (0.65 + 0.6 * vel));
    lp.frequency.setValueAtTime(top, when);
    if (S.lp && S.lp.q) lp.Q.value = S.lp.q;

    var g = ctx.createGain();
    var peak = 0.26 * vel * (inst.gain || 1) * pitchGain(midi);
    /* 弱奏起音慢一点、强奏快一点 —— 这一条比单纯调音量更能让人听出"轻重" */
    var a = (S.a == null ? 0.02 : S.a) * (band === 0 ? 1.45 : band === 2 ? 0.78 : 1);
    var dcy = S.d == null ? 0.2 : S.d, sus = S.s == null ? 0.7 : S.s;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.linearRampToValueAtTime(peak, when + a);
    var sustain = Math.max(0.0002, peak * sus);
    var holdEnd = dur ? when + Math.max(a + 0.005, dur) : null;
    var decayEnd = when + a + dcy;
    /* A later decay ramp used to override a short note's release target,
       raising its volume again before stop(). Truncate decay at note-off. */
    if (holdEnd != null && holdEnd < decayEnd) {
      var fraction = Math.max(0, Math.min(1, (holdEnd - when - a) / Math.max(0.0001, dcy)));
      g.gain.linearRampToValueAtTime(peak + (sustain - peak) * fraction, holdEnd);
    } else g.gain.linearRampToValueAtTime(sustain, decayEnd);

    osc.connect(lp); lp.connect(g); g.connect(dst || master);

    var lfo = null, lg = null;
    if (S.vib) {
      lfo = ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = S.vib.rate;
      lg = ctx.createGain();
      lg.gain.setValueAtTime(0, when);
      lg.gain.setValueAtTime(0, when + (S.vib.delay || 0.25));
      lg.gain.linearRampToValueAtTime(S.vib.cents, when + (S.vib.delay || 0.25) + 0.45);
      lfo.connect(lg); lg.connect(osc.detune);
      lfo.start(when);
    }
    var nsSrc = null, nsGain = null;
    if (S.breath) {
      nsSrc = ctx.createBufferSource(); nsSrc.buffer = noise(); nsSrc.loop = true;
      var nf = ctx.createBiquadFilter();
      nf.type = 'bandpass'; nf.frequency.value = Math.min(9000, f * 2.2); nf.Q.value = 0.8;
      nsGain = ctx.createGain();
      nsGain.gain.setValueAtTime(0.0001, when);
      nsGain.gain.linearRampToValueAtTime(S.breath * vel * 0.5, when + a + 0.02);
      nsSrc.connect(nf); nf.connect(nsGain); nsGain.connect(g);
      nsSrc.start(when);
    }
    osc.start(when);

    var rel = S.r == null ? 0.28 : S.r;
    var stopAt = null;
    if (dur) {
      if (holdEnd >= decayEnd) g.gain.setValueAtTime(sustain, holdEnd);
      g.gain.exponentialRampToValueAtTime(0.0001, holdEnd + rel);
      g.gain.linearRampToValueAtTime(0, holdEnd + rel + 0.008);
      /* 一定要真的 stop:不然每个音都留一整套节点在图上跑,
         一首曲子跑完能攒出上千个活着的振荡器,手机上迟早卡死。 */
      stopAt = holdEnd + rel + 0.028;
      stopAll3(stopAt, osc, lfo, nsSrc);
    }
    function gainAt(t) {
      if (t <= when) return 0.0001;
      if (t < when + a) return 0.0001 + (peak - 0.0001) * (t - when) / a;
      var at = holdEnd == null ? t : Math.min(t, holdEnd);
      var value = peak + (sustain - peak) * Math.max(0, Math.min(1, (at - when - a) / Math.max(0.0001, dcy)));
      if (holdEnd != null && t > holdEnd) {
        if (t >= holdEnd + rel + 0.008) return 0;
        if (t >= holdEnd + rel) return 0.0001 * (1 - (t - holdEnd - rel) / 0.008);
        return value * Math.pow(0.0001 / value, (t - holdEnd) / rel);
      }
      return value;
    }
    return { osc: osc, gain: g, lfo: lfo, lg: lg, ns: nsSrc, rel: rel, end: stopAt, gainAt: gainAt,
      releaseNotBefore: when + Math.max(0.02, a + 0.005), lp: lp, base: midi, hz: f };
  }

  function stopAll3(t, a, b, c) {
    try { if (a) a.stop(t); } catch (e) { }
    try { if (b) b.stop(t); } catch (e) { }
    try { if (c) c.stop(t); } catch (e) { }
  }

  /** 击弦/钟/木:泛音不是整数倍 —— 这一点是"金属味"与"木头味"的全部秘密 */
  function strikeVoice(inst, midi, vel, when, dur, kind, dst) {
    var S = inst.synth, f = freq(midi);
    if (kind === 'harm') f *= 2;
    var out = ctx.createGain(); out.gain.value = 0.3 * vel * (inst.gain || 1) * pitchGain(midi); out.connect(dst || master);
    var list = [];
    var tau0 = 0;
    for (var i = 0; i < S.ratios.length; i++) {
      var o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.value = Math.min(18000, f * S.ratios[i]);
      var og = ctx.createGain();
      var tau = S.decays[Math.min(i, S.decays.length - 1)] * (S.len || 1.6);
      if (tau > tau0) tau0 = tau;
      og.gain.setValueAtTime(0.0001, when);
      og.gain.linearRampToValueAtTime(S.amps[i], when + (S.atk || 0.002));
      og.gain.exponentialRampToValueAtTime(0.0001, when + tau);
      o.connect(og); og.connect(out);
      o.start(when); try { o.stop(when + tau + 0.05); } catch (e) { }
      list.push(o);
    }
    /* 槌头/木头那一下"哒" */
    var ns = ctx.createBufferSource(); ns.buffer = noise();
    var nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = Math.min(11000, f * 3); nf.Q.value = 0.7;
    var ng = ctx.createGain();
    ng.gain.setValueAtTime((S.hit == null ? 0.5 : S.hit) * vel, when);
    ng.gain.exponentialRampToValueAtTime(0.0001, when + 0.09);
    ns.connect(nf); nf.connect(ng); ng.connect(out);
    ns.start(when); try { ns.stop(when + 0.12); } catch (e) { }
    list.push(ns);
    return { osc: null, sources: list, gain: out, end: when + Math.max(tau0 + 0.05, (S.len || 1.6) * 1.2), hz: f };
  }

  function drumVoice(pad, vel, when, dst) {
    var P = pad.snd;
    /* 真鼓每一下都不一样:皮的张力、槌的落点差之毫厘。
       全用同一个采样听两遍就露馅了,所以给一点点随机。 */
    var jit = 0.984 + Math.random() * 0.032;
    var out = ctx.createGain(); out.gain.value = 0.9 * vel * (0.92 + Math.random() * 0.16); out.connect(dst || master);
    var tau = (P.tau || 0.4) * (0.94 + Math.random() * 0.12);
    var o = ctx.createOscillator(); o.type = P.wave || 'sine';
    o.frequency.setValueAtTime(P.f * jit, when);
    if (P.drop) o.frequency.exponentialRampToValueAtTime(Math.max(30, P.f * P.drop * jit), when + tau * 0.9);
    var og = ctx.createGain();
    og.gain.setValueAtTime(0.0001, when);
    og.gain.linearRampToValueAtTime(P.body == null ? 0.9 : P.body, when + 0.004);
    og.gain.exponentialRampToValueAtTime(0.0001, when + tau);
    o.connect(og); og.connect(out);
    o.start(when); try { o.stop(when + tau + 0.05); } catch (e) { }
    var sources = [o];
    if (P.noise) {
      var ns = ctx.createBufferSource(); ns.buffer = noise();
      var nf = ctx.createBiquadFilter();
      nf.type = P.bp ? 'bandpass' : 'lowpass';
      nf.frequency.value = P.tone || 1600; nf.Q.value = P.q || 0.9;
      var ng = ctx.createGain();
      ng.gain.setValueAtTime(P.noise, when);
      ng.gain.exponentialRampToValueAtTime(0.0001, when + tau * (P.nlen || 0.7));
      ns.connect(nf); nf.connect(ng); ng.connect(out);
      ns.start(when); try { ns.stop(when + tau + 0.05); } catch (e) { }
      sources.push(ns);
    }
    return { osc: null, sources: sources, gain: out, end: when + tau + 0.1 };
  }

  /* ---------------- 对外:一个音的一生 ---------------- */

  function prune() {
    var now = ctx ? ctx.currentTime : 0;
    for (var i = live.length - 1; i >= 0; i--) {
      if (live[i].v.end && live[i].v.end < now - 0.02) live.splice(i, 1);
    }
  }

  /**
   * 复音数上限:只用来兜住"手指乱刮"这种事。
   * **排给将来的音一个都不许顶掉** —— 自动演奏是一口气把整首谱排进音频图的(几十上百个),
   * 原来那一版是 `live.shift()`,被顶掉的正好是"最老的那个" = **曲子开头的那几个音**,
   * 于是 44 个音的曲子前 16 个音在自己该响的时刻之前就被 fade 掉了:
   * 用户听到的就是"开头一句句根本不响"。只顶**已经在响的**才对。
   */
  function guardPolyphony(when) {
    var t = Math.max(ctx.currentTime, when), i, sounding = 0;
    function overlaps(item) {
      return !item.dead && item.start <= t && (!item.v.end || item.v.end > t) && (item.stolenAt == null || item.stolenAt > t);
    }
    for (i = 0; i < live.length; i++) if (overlaps(live[i])) sounding++;
    if (sounding < MAX_LIVE) return;
    for (i = 0; i < live.length; i++) {
      if (overlaps(live[i])) {
        var old = live[i]; old.stolenAt = t;
        try { releaseAt(old.v, t, 0.08); } catch (e) { }
        return;
      }
    }
  }

  /**
   * 发一个音。
   * @param inst  乐器对象
   * @param midi  音高
   * @param vel   力度 0~1
   * @param when  AudioContext 时间(自动演奏要提前排);不传 = 立刻
   * @param dur   持续几秒(弹拨类只用来决定"要不要提前收掉")
   */
  function noteOn(inst, midi, vel, when, dur, kind, dst) {
    if (!unlock()) return null;
    when = when || ctx.currentTime;
    vel = vel == null ? 0.85 : (vel < 0.05 ? 0.05 : (vel > 1 ? 1 : vel));
    if (midi != null && (midi < 21 || midi > 108)) return null;
    var k = inst.synth.kind;
    /* 打击那一类没有"音高":谱面上的音按**第几面鼓**来读(C4=第 1 面、D4=第 2 面…)。
       不加这一条,打击乐在自动演奏与跟弹里会走振荡器那一路,出来的是怪音而不是鼓声。 */
    if (k === 'drum') {
      var pd = inst.pads || [];
      if (!pd.length) return null;
      var idx = (((midi - 36) % pd.length) + pd.length) % pd.length;
      var dv = hit(inst, idx, vel, when, dst);
      lastKind = 'drum'; lastVel = vel; lastHz = 0;
      return dv;
    }
    var v;
    if (k === 'ks') v = ksVoice(inst, midi, vel, when, dur, kind, dst);
    else if (k === 'strike') v = strikeVoice(inst, midi, vel, when, dur, kind, dst);
    else v = addVoice(inst, midi, vel, when, dur, dst);
    if (!v) return null;
    lastHz = hzOf(v);
    lastKind = kind || '';
    lastVel = vel;
    /* **拨响的弦不该因为手指抬起来就断。** 真琴上手指只负责"拨",弦什么时候停是弦自己的事 ——
       上一版一松手就 release,于是刮奏与扫弦全被切成一串短音,整件乐器都是"点一下就没了"。
       现在弹拨/击弦默认让余韵自己走完(除非谱子里写明了时值)。 */
    var rings = !dur && (k === 'ks' || k === 'strike');

    prune();
    guardPolyphony(when);
    var item = { v: v, inst: inst, midi: midi, dead: false, start: when };
    live.push(item);

    var voice = {
      midi: midi,
      inst: inst,
      /** 松手:按这个乐器的释放时间收掉(拉弦/吹管才有意义) */
      release: function (t) {
        if (item.dead) return;
        /* 拨响的弦自己响完:连"死"都不标 —— 标了 dead,prune() 下一趟就把它从
           live 里摘掉,复音数的账当场失真(自检里"四个音都还在响"量到 1 就是这个)。 */
        if (rings) return;
        item.dead = true;
        /* Touch activation may resume the clock only on pointerup. Keep the
           immediate attack audible even when note-off arrives at audio time 0.
           Forced stop/cancel still bypasses this minimum musical gate. */
        try { releaseAt(v, Math.max(t || ctx.currentTime, v.releaseNotBefore || 0), v.rel || 0.12); } catch (e) { }
      },
      /** 揉弦:拉弦与吹管的左手。cents 是揉的深度(音分),由手指抖动的幅度给 */
      vib: function (cents) {
        if (!v.lg) return;
        var t = ctx.currentTime;
        try {
          v.lg.gain.cancelScheduledValues(t);
          v.lg.gain.setTargetAtTime(Math.max(0, cents), t, 0.06);
        } catch (e) { }
      },
      /** 这一下还响着吗(自动演奏与"目标高亮"要用) */
      alive: function () { return !item.dead && (!v.end || v.end > ctx.currentTime) && (item.stolenAt == null || item.stolenAt > ctx.currentTime); },
      /** 滑音:拉弦换音高;弹拨则是"左手按弦把音推上去"(改回放速率) */
      glide: function (m, t) {
        t = t || ctx.currentTime;
        if (v.osc) {
          try { v.osc.frequency.cancelScheduledValues(t); } catch (e) { }
          v.osc.frequency.setTargetAtTime(freq(m), t, 0.02);
        } else if (v.src) {
          try {
            var r = freq(m) / freq(v.base);
            v.src.playbackRate.cancelScheduledValues(t);
            v.src.playbackRate.setTargetAtTime(r, t, 0.025);
          } catch (e) { }
        } else return;
        item.midi = m;
        voice.midi = m;
      },
      stop: function (t) {
        item.dead = true;
        try { releaseAt(v, t || ctx.currentTime, 0.05); } catch (e) { }
      }
    };
    return voice;
  }

  function releaseAt(v, t, rel) {
    var g = v.gain;
    if (!g) return;
    try {
      if (g.gain.cancelAndHoldAtTime) g.gain.cancelAndHoldAtTime(t);
      else {
        /* For a scheduled note-off the current value belongs to now, not t.
           Use the known envelope at t so older WebViews cannot jump to 1. */
        var held = v.gainAt && t > ctx.currentTime + 0.000001 ? v.gainAt(t) : g.gain.value;
        g.gain.cancelScheduledValues(t);
        g.gain.setValueAtTime(held, t);
      }
      g.gain.setTargetAtTime(0.0001, t, Math.max(0.004, rel / 5));
      g.gain.linearRampToValueAtTime(0, t + Math.max(0.02, rel));
    } catch (e) { }
    /* 松手时高频先走(弦停振、气断了),只降音量会听着"假" */
    try {
      if (v.lp) {
        var f0 = v.lp.frequency.value;
        v.lp.frequency.cancelScheduledValues(t);
        v.lp.frequency.setTargetAtTime(Math.max(300, f0 * 0.45), t, rel);
      }
    } catch (e) { }
    var stopAt = t + Math.max(0.02, rel) + 0.02;
    v.end = stopAt;
    try { if (v.src) v.src.stop(stopAt); } catch (e) { }
    try { if (v.osc) v.osc.stop(stopAt); } catch (e) { }
    try { if (v.lfo) v.lfo.stop(stopAt); } catch (e) { }
    try { if (v.ns) v.ns.stop(stopAt); } catch (e) { }
    if (v.sources) for (var si = 0; si < v.sources.length; si++) {
      try { v.sources[si].stop(stopAt); } catch (e) { }
    }
  }

  /** 打击乐:pad 是乐器上那一格的定义 */
  function hit(inst, idx, vel, when, dst) {
    if (!unlock()) return null;
    when = when || ctx.currentTime;
    vel = vel == null ? 0.9 : vel;
    var pad = inst.pads[idx];
    if (!pad) return null;
    var v = drumVoice(pad, vel, when, dst);
    prune(); guardPolyphony(when);
    live.push({ v: v, inst: inst, midi: -1, dead: false, start: when });
    return { midi: -1, release: function () { }, glide: function () { }, stop: function () { releaseAt(v, ctx.currentTime, 0.03); } };
  }

  /** 节拍器:一声木头的「嗒」。强拍高一点、弱拍低一点 —— 打拍只需要听得清在不在点上 */
  function tick(accent, when) {
    if (!unlock()) return null;
    tickCount++;
    var t = when || ctx.currentTime;
    var out = ctx.createGain();
    out.gain.value = accent ? 0.42 : 0.24;
    out.connect(master);
    var o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(accent ? 1560 : 1040, t);
    o.frequency.exponentialRampToValueAtTime(accent ? 900 : 640, t + 0.05);
    var og = ctx.createGain();
    og.gain.setValueAtTime(0.0001, t);
    og.gain.linearRampToValueAtTime(1, t + 0.002);
    og.gain.exponentialRampToValueAtTime(0.0001, t + (accent ? 0.11 : 0.075));
    o.connect(og); og.connect(out);
    o.start(t);
    try { o.stop(t + 0.16); } catch (e) { }
    /* 一点点敲击的"啪",不然只有一只正弦音,像电子表 */
    var ns = ctx.createBufferSource(); ns.buffer = noise();
    var nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 3200; nf.Q.value = 1.2;
    var ng = ctx.createGain();
    ng.gain.setValueAtTime(0.18, t);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
    ns.connect(nf); nf.connect(ng); ng.connect(out);
    ns.start(t); try { ns.stop(t + 0.05); } catch (e) { }
    /* 排出去的打拍还要能被收回来:停止演奏时,那一小节里已经排进来的节拍不该继续响 */
    return { stop: function () {
      releaseAt({gain: out, sources: [o, ns]}, ctx.currentTime, 0.02);
    } };
  }

  function stopAll() {
    if (!ctx) return;
    var now = ctx.currentTime;
    for (var i = 0; i < live.length; i++) {
      live[i].dead = true;
      try { releaseAt(live[i].v, now, 0.06); } catch (e) { }
    }
    live.length = 0;
  }

  function setVolume(v) {
    vol = Math.max(0, Math.min(1, v));
    /* 音量变化走一小段斜坡:直接拍 .value,正在响的音会"咔"一声 */
    if (master) { try { master.gain.setTargetAtTime(vol, ctx.currentTime, 0.04); } catch (e) { master.gain.value = vol; } }
  }

  /** 一条自己的增益轨:乐器块 / 录音层 / 声部各领一条,汇进 master。
      调它的 gain 只改音量 —— 不动音色,也不惊动已经在响的音。
      用法:var b = bus(0.8); 之后 noteOn/hit 的最后一参传 b。 */
  function bus(g) {
    ensure();
    if (!ctx) return null;
    var n = ctx.createGain();
    n.gain.value = g == null ? 1 : g;
    n.connect(master);
    return n;
  }
  function setWet(v) {
    wet = Math.max(0, Math.min(0.6, v));
    /* 与 setVolume 同一条道理:直接拍 .value,拖杆子的时候正在响的音会一路"咔咔"响
       (混响那一段尤其明显,听起来就是"沙拉沙拉")。走一小段斜坡就没这回事。 */
    var t = ctx ? ctx.currentTime : 0;
    if (wetBus) { try { wetBus.gain.setTargetAtTime(wet, t, 0.04); } catch (e) { wetBus.gain.value = wet; } }
    if (dryBus) { try { dryBus.gain.setTargetAtTime(1 - wet * 0.35, t, 0.04); } catch (e) { dryBus.gain.value = 1 - wet * 0.35; } }
  }
  function now() { return ctx ? ctx.currentTime : 0; }

  /* ============================================================
     乐器表
     ------------------------------------------------------------
     ui 决定这一样在页面上是"什么形状":
       zither 立着的一排弦(古筝/古琴/竖琴/卡林巴)·每弦一音,横滑可刮奏
       fret   有品的指板(吉他/琵琶/阮…)·点格子
       bow    无品的按弦带(二胡/提琴)·按住拖出滑音
       pads   音孔/音键方块(吹管/扬琴/编钟)
       keys   钢琴键盘
       drum   打击垫

     strings 一律**从高音弦到低音弦**排列(一弦在最上面一行),
     与吉他谱的写法一致,这样点第几行就是第几弦。
     ============================================================ */

  function pscale(lo, count, steps) {
    steps = steps || [0, 2, 4, 7, 9];            /* 五声:宫商角徵羽 */
    var out = [];
    for (var i = 0; i < count; i++) out.push(lo + 12 * Math.floor(i / steps.length) + steps[i % steps.length]);
    return out;
  }
  function dscale(lo, count) {
    return pscale(lo, count, [0, 2, 4, 5, 7, 9, 11]);
  }

  var INSTRUMENTS = [
    /* ---- 弹拨 ---- */
    {
      id: 'guzheng', name: '古筝', fam: '弹拨', ui: 'zither', tint: 'wood',
      deco: 'bridge',
      desc: '二十一弦 · D 调五声 D₂–d³',
      /* 现代 21 弦筝:D 调五声(D E F♯ A B)铺满四个八度,
         21 弦(最粗)空弦 D2 = 73.42Hz,1 弦(最细)空弦 D6。
         页面上从左到右 = 从低到高,和坐在筝前看到的一致。 */
      strings: pscale(38, 21),                       /* D2 … D6 */
      bend: 2,                                       /* 左手按弦最多可把音推高两个半音 */
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.5, damp2: 0.62, decay: 0.9978, bright: 0.78, tone: 4800, body: 300, bodyGain: 5, len: 3.8 }
    },
    {
      id: 'guqin', name: '古琴', fam: '弹拨', ui: 'zither', tint: 'wood',
      deco: 'hui',
      desc: '七弦 · 正调 C D F G A c d',
      /* 正调(仲吕均)散音,一弦最粗最低:一 C2 二 D2 三 F2 四 G2 五 A2 六 c1 七 d1。
         **数组与筝一样是"从左到右、由低到高"** —— 上一版这里排反了(最左是七弦),
         与筝、与"坐在琴前从左往右"的习惯都对不上。 */
      strings: [36, 38, 41, 43, 45, 48, 50],          /* C2 D2 F2 G2 A2 C3 D3 */
      bend: 2,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.62, damp2: 0.36, decay: 0.9989, bright: 0.28, tone: 1700, body: 190, bodyGain: 7, len: 4.4 }
    },
    {
      id: 'harp', name: '竖琴', fam: '弹拨', ui: 'zither', tint: 'wood',
      deco: 'stringcolor',
      desc: '二十二弦 · 七声排列(C 弦红、F 弦蓝)',
      strings: dscale(60, 22),
      gain: 0.95,
      synth: { kind: 'ks', damp: 0.52, damp2: 0.55, decay: 0.9975, bright: 0.55, tone: 3600, body: 260, bodyGain: 5, len: 3.4 }
    },
    {
      id: 'kalimba', name: '卡林巴', fam: '弹拨', ui: 'zither', tint: 'wood',
      deco: 'tine',
      desc: '十七键拇指琴 · C4–E6',
      /* 十七键拇指琴就是 C4 到 E6 —— 上一版从 C5 起,整件乐器高了一个八度 */
      strings: dscale(60, 17),
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.48, damp2: 0.66, decay: 0.998, bright: 0.8, tone: 5400, body: 420, bodyGain: 6, len: 2.8 }
    },
    {
      id: 'yangqin', name: '扬琴', fam: '弹拨', ui: 'pads', tint: 'wood',
      desc: '双槌击弦 · 两个八度',
      padsLo: 48, padsCount: 22, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.95,
      synth: { kind: 'strike', ratios: [1, 2.01, 3.02, 4.06, 5.1], amps: [1, 0.42, 0.22, 0.12, 0.06], decays: [1, 0.62, 0.45, 0.3, 0.22], atk: 0.002, hit: 0.5, len: 1.7 }
    },
    {
      id: 'guitar', name: '吉他', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '六弦 · E A D G B E',
      strings: [64, 59, 55, 50, 45, 40], frets: 12,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.5, damp2: 0.5, decay: 0.9955, bright: 0.6, tone: 3200, body: 210, bodyGain: 6, len: 3.0 }
    },
    {
      id: 'ukulele', name: '尤克里里', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '四弦 · G C E A',
      strings: [69, 64, 60, 67], frets: 12,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.46, damp2: 0.58, decay: 0.9935, bright: 0.74, tone: 3900, body: 330, bodyGain: 5, len: 2.0 }
    },
    {
      id: 'pipa', name: '琵琶', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '四弦 · A d e a(一四弦为八度)',
      /* 一弦 a(A3) 二弦 e(E3) 三弦 d(D3) 四弦 A(A2) —— 一弦与四弦正好差八度 */
      strings: [57, 52, 50, 45], frets: 12,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.44, damp2: 0.7, decay: 0.9925, bright: 0.86, tone: 5200, body: 300, bodyGain: 6, len: 1.9 }
    },
    {
      id: 'ruan', name: '中阮', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '四弦 · G d a e¹',
      /* 一弦 e1(E4) 二弦 a(A3) 三弦 d(D3) 四弦 G(G2),五—四—五度关系 */
      strings: [64, 57, 50, 43], frets: 12,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.54, damp2: 0.48, decay: 0.9962, bright: 0.5, tone: 2600, body: 200, bodyGain: 6, len: 2.8 }
    },
    {
      id: 'mandolin', name: '曼陀林', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '四对复弦 · 同小提琴定弦',
      strings: [76, 69, 62, 55], frets: 12,
      gain: 0.9,
      synth: { kind: 'ks', damp: 0.42, damp2: 0.72, decay: 0.991, bright: 0.9, tone: 6200, body: 380, bodyGain: 5, len: 1.4 }
    },
    {
      id: 'sanxian', name: '三弦', fam: '弹拨', ui: 'fret', tint: 'wood',
      desc: '三弦 · 书弦 G d g',
      /* 北方大三弦(书弦):子弦 g(G3) 中弦 d(D3) 老弦 G(G2) */
      strings: [55, 50, 43], frets: 12,
      gain: 1.0,
      synth: { kind: 'ks', damp: 0.5, damp2: 0.44, decay: 0.995, bright: 0.62, tone: 3000, body: 240, bodyGain: 7, len: 2.6 }
    },

    /* ---- 拉弦 ---- */
    {
      id: 'erhu', name: '二胡', fam: '拉弦', ui: 'bow', tint: 'red',
      desc: '两根弦 · 内 d¹ 外 a¹',
      strings: [69, 62], span: 24,          /* 外弦 a1 在上,内弦 d1 在下 */
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.72, 0.5, 0.36, 0.26, 0.18, 0.13, 0.09, 0.06, 0.04],
        a: 0.1, d: 0.14, s: 0.86, r: 0.3, lp: { f: 3400, q: 0.8 }, breath: 0.05,
        vib: { rate: 5.8, cents: 26, delay: 0.32 }
      }
    },
    {
      id: 'violin', name: '小提琴', fam: '拉弦', ui: 'bow', tint: 'red',
      desc: '四弦 · G D A E',
      strings: [76, 69, 62, 55], span: 24,
      gain: 0.95,
      synth: {
        kind: 'add', harm: [1, 0.68, 0.52, 0.4, 0.3, 0.22, 0.16, 0.11, 0.07, 0.05],
        a: 0.07, d: 0.16, s: 0.85, r: 0.26, lp: { f: 4600, q: 0.7 }, breath: 0.04,
        vib: { rate: 6.0, cents: 16, delay: 0.4 }
      }
    },
    {
      id: 'cello', name: '大提琴', fam: '拉弦', ui: 'bow', tint: 'red',
      desc: '四弦 · C G d a',
      strings: [57, 50, 43, 36], span: 24,
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.8, 0.6, 0.44, 0.3, 0.2, 0.14, 0.09, 0.06, 0.03],
        a: 0.11, d: 0.2, s: 0.88, r: 0.36, lp: { f: 2200, q: 0.9 }, breath: 0.05,
        vib: { rate: 5.2, cents: 14, delay: 0.5 }
      }
    },
    {
      id: 'matouqin', name: '马头琴', fam: '拉弦', ui: 'bow', tint: 'red',
      desc: '两根弦 · 内 d¹ 外 a(内弦反比外弦高)',
      /* 这是马头琴与别的胡琴最不一样的地方:四度定弦,
         内弦 d1(62) 比外弦 a(57) 高,弓子也不夹在两弦中间。 */
      strings: [62, 57], span: 24, innerIsHigh: true,
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.9, 0.55, 0.42, 0.28, 0.2, 0.12, 0.08, 0.05],
        a: 0.13, d: 0.22, s: 0.88, r: 0.4, lp: { f: 1900, q: 1.0 }, breath: 0.06,
        vib: { rate: 4.8, cents: 24, delay: 0.45 }
      }
    },

    /* ---- 吹管 ---- */
    {
      id: 'dizi', name: '竹笛', fam: '吹管', ui: 'pads', tint: 'bamboo',
      padShape: 'hole',
      desc: '梆笛 · 两个八度',
      padsLo: 62, padsCount: 15, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.95,
      synth: {
        kind: 'add', harm: [1, 0.34, 0.2, 0.1, 0.05, 0.03],
        a: 0.05, d: 0.1, s: 0.82, r: 0.2, lp: { f: 5200, q: 0.6 }, breath: 0.13,
        vib: { rate: 5.6, cents: 22, delay: 0.45 }
      }
    },
    {
      id: 'xiao', name: '洞箫', fam: '吹管', ui: 'pads', tint: 'bamboo',
      padShape: 'hole',
      desc: '竖吹 · 幽远',
      padsLo: 62, padsCount: 15, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.14, 0.07, 0.03],
        a: 0.1, d: 0.14, s: 0.86, r: 0.3, lp: { f: 2000, q: 0.7 }, breath: 0.16,
        vib: { rate: 4.6, cents: 10, delay: 0.6 }
      }
    },
    {
      id: 'xun', name: '埙', fam: '吹管', ui: 'pads', tint: 'bamboo',
      padShape: 'hole',
      desc: '陶埙 · 音域窄,呜咽',
      padsLo: 60, padsCount: 10, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 1.05,
      synth: {
        kind: 'add', harm: [1, 0.1, 0.05, 0.02],
        a: 0.14, d: 0.2, s: 0.9, r: 0.42, lp: { f: 1100, q: 0.8 }, breath: 0.14,
        vib: { rate: 4.2, cents: 8, delay: 0.7 }
      }
    },
    {
      id: 'suona', name: '唢呐', fam: '吹管', ui: 'pads', tint: 'bamboo',
      desc: '大嗓门 · 又亮又冲',
      padsLo: 67, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.8,
      synth: {
        kind: 'add', harm: [1, 0.95, 0.75, 0.58, 0.44, 0.34, 0.25, 0.18, 0.12, 0.08, 0.05],
        a: 0.035, d: 0.1, s: 0.86, r: 0.2, lp: { f: 6500, q: 1.1 }, breath: 0.07,
        vib: { rate: 5.4, cents: 14, delay: 0.5 }
      }
    },
    {
      id: 'sheng', name: '笙', fam: '吹管', ui: 'pads', tint: 'bamboo',
      desc: '簧片 · 可以几个音一起按(和音)',
      padsLo: 60, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.9,
      synth: {
        kind: 'add', harm: [1, 0.62, 0.44, 0.3, 0.2, 0.12, 0.07],
        a: 0.03, d: 0.08, s: 0.84, r: 0.18, lp: { f: 3400, q: 0.7 }, breath: 0.05
      }
    },
    {
      id: 'flute', name: '长笛', fam: '吹管', ui: 'pads', tint: 'bamboo',
      desc: '木管 · 干净的气声',
      padsLo: 60, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.95,
      synth: {
        kind: 'add', harm: [1, 0.22, 0.09, 0.04],
        a: 0.07, d: 0.12, s: 0.84, r: 0.24, lp: { f: 4200, q: 0.6 }, breath: 0.12,
        vib: { rate: 5.0, cents: 12, delay: 0.55 }
      }
    },
    {
      id: 'clarinet', name: '单簧管', fam: '吹管', ui: 'pads', tint: 'bamboo',
      desc: '奇数泛音为主 · 木头的圆',
      padsLo: 52, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.95,
      synth: {
        kind: 'add', harm: [1, 0.06, 0.55, 0.06, 0.32, 0.05, 0.18, 0.04, 0.1],
        a: 0.05, d: 0.12, s: 0.85, r: 0.22, lp: { f: 3000, q: 0.8 }, breath: 0.06,
        vib: { rate: 5.2, cents: 8, delay: 0.6 }
      }
    },
    {
      id: 'trumpet', name: '小号', fam: '吹管', ui: 'pads', tint: 'brass',
      desc: '铜管 · 起音带一点炸',
      padsLo: 62, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.85,
      synth: {
        kind: 'add', harm: [1, 0.72, 0.6, 0.48, 0.38, 0.28, 0.2, 0.14, 0.09, 0.06],
        a: 0.03, d: 0.14, s: 0.78, r: 0.18, lp: { f: 5000, q: 1.2 }, breath: 0.04,
        vib: { rate: 5.6, cents: 10, delay: 0.5 }
      }
    },
    {
      id: 'sax', name: '萨克斯', fam: '吹管', ui: 'pads', tint: 'brass',
      desc: '芦苇片 · 沙沙的暖',
      padsLo: 58, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.9,
      synth: {
        kind: 'add', harm: [1, 0.55, 0.5, 0.34, 0.26, 0.18, 0.12, 0.08, 0.05],
        a: 0.05, d: 0.14, s: 0.84, r: 0.26, lp: { f: 2900, q: 0.9 }, breath: 0.09,
        vib: { rate: 5.4, cents: 18, delay: 0.45 }
      }
    },
    {
      id: 'harmonica', name: '口琴', fam: '吹管', ui: 'pads', tint: 'brass',
      desc: '十孔布鲁斯 · 一吹一吸',
      padsLo: 60, padsCount: 14, padsScale: [0, 2, 4, 5, 7, 9, 11],
      gain: 0.95,
      synth: {
        kind: 'add', harm: [1, 0.6, 0.42, 0.3, 0.2, 0.13, 0.08],
        a: 0.04, d: 0.1, s: 0.82, r: 0.2, lp: { f: 3800, q: 0.8 }, breath: 0.07,
        vib: { rate: 6.2, cents: 12, delay: 0.5 }
      }
    },

    /* ---- 键盘 ---- */
    {
      id: 'piano', name: '钢琴', fam: '键盘', ui: 'keys', tint: 'key',
      desc: '两个八度 · 带槌头的敲击感',
      keysLo: 48, keysHi: 84,
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.56, 0.36, 0.22, 0.14, 0.08, 0.05, 0.03, 0.02],
        a: 0.004, d: 0.9, s: 0.26, r: 0.5, lp: { f: 5600, q: 0.5 }
      }
    },
    {
      id: 'epiano', name: '电钢琴', fam: '键盘', ui: 'keys', tint: 'key',
      desc: '铃铛一样的音头',
      keysLo: 48, keysHi: 84,
      gain: 1.0,
      synth: {
        kind: 'add', harm: [1, 0.3, 0.14, 0.06, 0.03],
        a: 0.003, d: 0.7, s: 0.3, r: 0.4, lp: { f: 4600, q: 0.5 }
      }
    },
    {
      id: 'organ', name: '管风琴', fam: '键盘', ui: 'keys', tint: 'key',
      desc: '音栓全拉 · 一直响',
      keysLo: 48, keysHi: 84,
      gain: 0.8,
      synth: {
        kind: 'add', harm: [1, 0.7, 0.5, 0.36, 0.24, 0.17, 0.12, 0.08, 0.06, 0.04],
        a: 0.02, d: 0.06, s: 0.95, r: 0.2, lp: { f: 4200, q: 0.4 }
      }
    },
    {
      id: 'harpsichord', name: '羽管键琴', fam: '键盘', ui: 'keys', tint: 'key',
      desc: '拨子勾弦 · 巴洛克',
      keysLo: 48, keysHi: 84,
      gain: 0.95,
      synth: { kind: 'ks', damp: 0.4, damp2: 0.74, decay: 0.991, bright: 0.92, tone: 6400, body: 420, bodyGain: 4, len: 1.6 }
    },
    {
      id: 'glocken', name: '钢片琴', fam: '键盘', ui: 'keys', tint: 'key',
      desc: '高八度 · 星星一样的亮',
      keysLo: 60, keysHi: 96,
      gain: 0.9,
      synth: {
        kind: 'strike', ratios: [1, 2.76, 5.4, 8.9, 13.3], amps: [1, 0.44, 0.22, 0.1, 0.05],
        decays: [1, 0.5, 0.32, 0.2, 0.12], atk: 0.001, hit: 0.22, len: 2.2
      }
    },

    /* ---- 打击 ---- */
    {
      id: 'drumset', name: '堂鼓', fam: '打击', ui: 'drum', tint: 'drum',
      desc: '大鼓小鼓与锣镲',
      gain: 1.0,
      synth: { kind: 'drum' },
      pads: [
        { name: '堂鼓', snd: { f: 96, drop: 0.62, tau: 0.7, body: 1.0, noise: 0.35, tone: 900 } },
        { name: '排鼓', snd: { f: 168, drop: 0.6, tau: 0.4, body: 0.9, noise: 0.3, tone: 1400 } },
        { name: '板鼓', snd: { f: 300, drop: 0.5, tau: 0.16, body: 0.8, noise: 0.45, tone: 2600, bp: 1, q: 1.4 } },
        { name: '大锣', snd: { f: 132, drop: 0.9, tau: 2.4, body: 0.7, noise: 0.5, tone: 3200, nlen: 1.0 } },
        { name: '镲', snd: { f: 420, drop: 0.95, tau: 1.6, body: 0.28, noise: 0.75, tone: 7000, bp: 1, q: 0.5, nlen: 1.0 } },
        { name: '响板', snd: { f: 780, drop: 0.7, tau: 0.1, body: 0.5, noise: 0.6, tone: 3200, bp: 1, q: 2.2 } }
      ]
    },
    {
      id: 'bianzhong', name: '编钟', fam: '打击', ui: 'bells', tint: 'brass',
      desc: '一钟双音 · 左正鼓,右侧鼓(高大三度)',
      padsLo: 60, padsCount: 15, padsScale: [0, 2, 4, 7, 9],
      padDual: 4,                    /* 先秦的钟敲正鼓与侧鼓是两个音,相差大三度(= 4 个半音) */
      gain: 0.9,
      synth: {
        kind: 'strike', ratios: [1, 1.002, 2.4, 3.9, 5.6], amps: [1, 0.9, 0.4, 0.2, 0.1],
        decays: [1, 0.95, 0.55, 0.34, 0.2], atk: 0.003, hit: 0.3, len: 3.0
      }
    },
    {
      id: 'muyu', name: '木鱼', fam: '打击', ui: 'drum', tint: 'drum',
      desc: '梆梆两声',
      gain: 1.0,
      synth: { kind: 'drum' },
      pads: [
        { name: '大木鱼', snd: { f: 420, drop: 0.55, tau: 0.16, body: 0.55, noise: 0.55, tone: 1800, bp: 1, q: 1.6 } },
        { name: '小木鱼', snd: { f: 720, drop: 0.6, tau: 0.11, body: 0.5, noise: 0.5, tone: 2600, bp: 1, q: 1.8 } },
        { name: '梆子', snd: { f: 980, drop: 0.7, tau: 0.09, body: 0.45, noise: 0.5, tone: 3400, bp: 1, q: 2.0 } },
        { name: '碰钟', snd: { f: 1560, drop: 0.98, tau: 2.6, body: 0.4, noise: 0.3, tone: 6200, bp: 1, q: 0.8, nlen: 0.8 } }
      ]
    },
    {
      id: 'triangle', name: '三角铁', fam: '打击', ui: 'drum', tint: 'drum',
      desc: '叮 ——',
      gain: 0.9,
      synth: { kind: 'drum' },
      pads: [
        { name: '三角铁', snd: { f: 4200, drop: 0.99, tau: 3.0, body: 0.3, noise: 0.22, tone: 9000, bp: 1, q: 0.6, nlen: 0.6 } },
        { name: '铃鼓', snd: { f: 2600, drop: 0.9, tau: 0.5, body: 0.25, noise: 0.55, tone: 7000, bp: 1, q: 0.6 } },
        { name: '沙锤', snd: { f: 1200, drop: 0.85, tau: 0.16, body: 0.1, noise: 0.7, tone: 5200, bp: 1, q: 0.5 } }
      ]
    },
    {
      id: 'luo', name: '锣与钹', fam: '打击', ui: 'drum', tint: 'drum',
      desc: '一片金属的余韵',
      gain: 0.9,
      synth: { kind: 'drum' },
      pads: [
        { name: '大锣', snd: { f: 108, drop: 0.92, tau: 3.2, body: 0.75, noise: 0.5, tone: 2800, nlen: 1.0 } },
        { name: '小锣', snd: { f: 420, drop: 0.86, tau: 0.9, body: 0.5, noise: 0.45, tone: 4200, bp: 1, q: 0.7 } },
        { name: '钹', snd: { f: 360, drop: 0.96, tau: 2.0, body: 0.24, noise: 0.8, tone: 8000, bp: 1, q: 0.4, nlen: 1.0 } },
        { name: '云锣', snd: { f: 880, drop: 0.97, tau: 1.8, body: 0.42, noise: 0.3, tone: 5600, bp: 1, q: 0.9 } }
      ]
    }
  ];

  var FAMS = ['弹拨', '拉弦', '吹管', '键盘', '打击'];

  root.JH_BOX_AUDIO = {
    unlock: unlock,
    noteOn: noteOn,
    hit: hit,
    tick: tick,
    stopAll: stopAll,
    setVolume: setVolume,
    setWet: setWet,
    bus: bus,
    warm: warm,
    now: now,
    freq: freq,
    midiName: midiName,
    midiNameFlat: midiNameFlat,
    instruments: INSTRUMENTS,
    families: FAMS,
    /* 自检用:还响着几个 / 最后一个音多少赫兹 / 打拍打了几下 */
    live: function () { prune(); return live.length; },
    lastHz: function () { return lastHz; },
    lastKind: function () { return lastKind; },
    lastVel: function () { return lastVel; },
    ticks: function () { return tickCount; },
    /* 拨弦缓冲的账:命中/未命中/在缓存里的条数与字节。
       给自检用 —— "开演期间还有没有人在现场生成缓冲"这件事,只有它能精确回答
       (计时会被 JIT、机器快慢、缓存里本来就有没有搅在一起,量出来是白绿)。 */
    ksStats: function () { return { hit: ksHit, miss: ksMiss, keys: ksOrder.length, bytes: ksBytes }; }
  };
})(typeof window !== 'undefined' ? window : this);
