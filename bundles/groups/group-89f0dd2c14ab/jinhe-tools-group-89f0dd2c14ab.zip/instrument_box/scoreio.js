/* ============================================================
   随身钢琴 · 乐谱读写(纯逻辑,不碰 DOM)
   ============================================================

   为什么单独一个文件、为什么一句 DOM 都不许写:
   导入是这一页唯一「外部数据进得来」的地方,而外部数据进来之后**没有人会替它把关** ——
   一个写错的音名在真机上只会表现为「点了没声音」,一个死循环就是页面卡死。
   所以解析、校验、导出全部收在这里,**不依赖 window/document**,也就意味着
   单测能把这份文件原样读进 JVM 里跑(Rhino),测的就是页面上跑的那一份代码。
   见 `app/src/test/java/com/jinhe/toolbox/plugin/PianoImportTest.kt`。

   ------------------------------------------------------------
   文本格式(两种方言,同一段文本里不许混)
   ------------------------------------------------------------
   ① 简谱(推荐,中文用户顺手就写得出来):
        1 2 3 4 5 6 7      —— do re mi fa sol la si
        0                  —— 休止
        #4 / b7            —— 升/降
        1'  1''            —— 高八度 / 高两个八度(`·` 也算高八度,从网页上拷下来常见)
        1,  1,,            —— 低八度 / 低两个八度(全角 `,` 也认)
        一 二 三 四 五 六 七 —— 中文数字等价于 1~7
        5:2                —— 两拍(缺省一拍);5:0.5 半拍;5:1.5 一拍半
        5.                 —— 附点(等价于 5:1.5)
        -                  —— 把**前一个音**再延长一拍(`1 - -` = 三拍;`-:2` = 再延长两拍)
        |                  —— 小节线,只影响排版,不发声
      音与音之间的空格可以省:`1155` 就是 `1 1 5 5`(从网页上拷下来的谱常常一个空格都没有),
      `11:2` 是「一拍的一 + 两拍的一」。音名那一支不留连写(`C4D4` 会报错),因为音名自带八度数字,拆不准。
   ② 音名(与 scores.js 里的内置曲库同一套,为了让老谱面/老用户粘贴的文本照样进来):
        C4 D4 E4 G4:2 C5:0.5 D#4 Bb4
        缺省八度取 4(与 scores.js 头部的老约定一致)。

   两种方言由**第一个像样的音**决定(数字 → 简谱;字母 → 音名),同一段文本里不许混;
   `0`(不出声)与 `-`(把前一个音再拉长一拍)两种方言里通用。只有 `-` 的文本会报
   「`-` 前面没有音可以延长」这句人话,而不是静默吃掉。

   行内以 `//` 开头或行首 `//` 的整段是注释;`@` 开头的是曲头指令:
        @title 小星星        (@标题 也认)
        @key C               (@主音)  —— 决定简谱里 `1` 落在哪个音上
        @base 4              —— 决定简谱里不带点的 `1` 是哪个八度(C4 = base 4)
        @bpm 104             (@拍速)
        @origin 出处说明      (@出处)

   ------------------------------------------------------------
   报错的规矩
   ------------------------------------------------------------
   任何解析失败都返回 `{ok:false, error:{line, col, message, hint}}`,
   `line`/`col` 从 1 开始,`col` 是**该行第几个字符**(按字符算,不按字节)。
   message 是给人看的一句话(带「第 3 行第 5 个字符」),hint 是「那该怎么办」。
   绝不抛异常,绝不静默丢音 —— 解析器里只要发现不对就 return,已解析的一半不落地。
   ============================================================ */
(function (root, factory) {
  var api = factory();
  if (root) root.JH_PIANO_IO = api;
  if (typeof module !== 'undefined' && module && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  /* ============ 上限 ============ */
  var LIMITS = {
    textLen: 200000,        // 一次交给解析器的文本上限(字符)。超了先拒绝,再谈解析 —— 不卡主线程
    songsPerImport: 20,     // 一次导入最多几首
    notesPerSong: 1200,     // 一首谱最多几个音(够四五分钟,再多该拆曲了)
    beatsMin: 0.05,
    beatsMax: 8,
    midiMin: 12,
    midiMax: 108,
    titleLen: 40,
    originLen: 120,
    bpmMin: 40,
    bpmMax: 200,
    userSongs: 30,          // 本地最多存几首用户谱
    libraryChars: 120000,   // 用户谱库的总字符上限(notes 字符串累加)
    octaveMarks: 8          // 简谱八度点最多几个(中央 C 上下四个八度就够任何琴键范围了)
  };

  var LETTER = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  var LETTER_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  var SCALE = [0, 2, 4, 5, 7, 9, 11];          // 大调音阶:1 2 3 4 5 6 7 相对主音的半音数
  var DEGREE = { 0: '1', 2: '2', 4: '3', 5: '4', 7: '5', 9: '6', 11: '7' };
  var CN_DIGIT = { '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '〇': 0, '零': 0 };

  /* ============ 小工具 ============ */
  function err(line, col, message, hint) {
    return { ok: false, error: { line: line, col: col, message: message, hint: hint || '' } };
  }

  function where(line, col) {
    return '第 ' + line + ' 行第 ' + col + ' 个字符';
  }

  function clamp(v, a, b) {
    if (!isFinite(v)) return a;
    return v < a ? a : (v > b ? b : v);
  }

  function midiOfLetter(letter, accidental, oct) {
    var semi = LETTER[letter];
    if (semi === undefined) return null;
    if (accidental === '#') semi += 1;
    else if (accidental === 'b') semi -= 1;
    return (oct + 1) * 12 + semi;
  }

  /* ============ 归一化 ============ */
  /**
   * 只动「换行 / 缩进」这一层,**绝不动正文里的字** ——
   * `@title 第１章`、`@origin 贝多芬,1810 年 · 主题` 这些是用户的原话,要原样留到导出。
   * 全角数字、全角冒号、弯引号这些「音符写法」上的差异,一律在**单个 token 里**折(foldToken),
   * 于是曲名里的全角字符不会被顺手改掉。
   */
  function normalize(text) {
    var s = String(text == null ? '' : text);
    if (s.charCodeAt(0) === 0xFEFF) s = s.slice(1);
    s = s.replace(/\r\n?/g, '\n');
    s = s.replace(/[\u3000\t]/g, ' ');
    return s;
  }

  /** 音符写法上的全角/花样写法 → 半角(只作用在一个 token 上) */
  function foldToken(t) {
    return String(t)
      .replace(/[\uFF10-\uFF19]/g, function (c) {                       // ０-９
        return String.fromCharCode(c.charCodeAt(0) - 0xFF10 + 0x30);
      })
      .replace(/[\uFF21-\uFF3A]/g, function (c) {                       // Ａ-Ｚ
        return String.fromCharCode(c.charCodeAt(0) - 0xFF21 + 0x41);
      })
      .replace(/[\uFF41-\uFF5A]/g, function (c) {                       // ａ-ｚ
        return String.fromCharCode(c.charCodeAt(0) - 0xFF41 + 0x61);
      })
      .replace(/\uFF1A/g, ':')                                          // :
      .replace(/\uFF0C/g, ',')                                          // ,
      .replace(/[\u2018\u2019\u02B9\u00B4]/g, "'")                      // ’ ‘ ´
      .replace(/[\uFF0D\u2013\u2014\u2212]/g, '-');                     // － – — −
  }

  /** 小节线:半角 `|` 与全角 `｜`、`丨` 都算 */
  function isBar(c) {
    return c === '|' || c === '\uFF5C' || c === '\u4E28';
  }

  /* ============ 曲头指令与注释 ============ */
  var DIRECTIVE = {
    title: 'title', '标题': 'title', '曲名': 'title', name: 'title',
    key: 'key', '主音': 'key', '调': 'key',
    base: 'base', '低音': 'base', '起始八度': 'base',
    bpm: 'bpm', '拍速': 'bpm', '速度': 'bpm',
    origin: 'origin', '出处': 'origin', '来源': 'origin'
  };

  /** 把文本切成 {head:{...}, body:[{text, line}]} —— body 里保留行号,报错才说得出「第几行」 */
  function splitLines(text) {
    var raw = normalize(text).split('\n');
    var head = { title: '', key: '', base: null, bpm: null, origin: '' };
    var body = [];
    for (var i = 0; i < raw.length; i++) {
      var line = raw[i];
      var cut = line.indexOf('//');
      if (cut >= 0) line = line.slice(0, cut);
      var trimmed = line.replace(/^\s+/, '');
      if (trimmed === '') continue;
      if (trimmed.charAt(0) === '@') {
        var m = /^@\s*([A-Za-z\u4e00-\u9fa5]+)\s*[:=]?\s*(.*)$/.exec(trimmed);
        var col = line.length - trimmed.length + 1;
        if (!m) {
          return err(i + 1, col, where(i + 1, col) + '的 `@` 后面没写指令名',
            '曲头请写成 `@title 曲名`、`@key C`、`@bpm 100` 这样');
        }
        var key = DIRECTIVE[m[1].toLowerCase()] || DIRECTIVE[m[1]];
        if (!key) {
          return err(i + 1, col, where(i + 1, col) + '的指令 `@' + m[1] + '` 不认识',
            '认得的只有:@title(标题)、@key(主音)、@base(起始八度)、@bpm(拍速)、@origin(出处)');
        }
        var val = m[2].replace(/\s+$/, '');
        if (key === 'title' || key === 'origin') {
          head[key] = val;                                    // 曲名与出处按原话留,不做任何折叠
        } else if (key === 'key') {
          var km = /^([A-Ga-g])([#b]?)$/.exec(foldToken(val));
          if (!km) {
            return err(i + 1, col, where(i + 1, col) + '的主音 `' + val + '` 认不出',
              '主音只能是 A~G(可带 # 或 b),例如 `@key C`、`@key G`');
          }
          head.key = km[1].toUpperCase() + (km[2] || '');
        } else {
          var n = parseFloat(foldToken(val));
          if (!isFinite(n)) {
            return err(i + 1, col, where(i + 1, col) + '的 `@' + key + '` 不是数字:「' + val + '」',
              key === 'bpm' ? '拍速写成 40~200 的整数,例如 `@bpm 104`' : '起始八度写成 0~8 的整数,例如 `@base 4`');
          }
          if (key === 'bpm' && (n < LIMITS.bpmMin || n > LIMITS.bpmMax)) {
            return err(i + 1, col, where(i + 1, col) + '的拍速 ' + n + ' 不合适',
              '拍速请写在 ' + LIMITS.bpmMin + '~' + LIMITS.bpmMax + ' 之间');
          }
          if (key === 'base' && (n < 0 || n > 8)) {
            return err(i + 1, col, where(i + 1, col) + '的起始八度 ' + n + ' 不合适',
              '起始八度请写在 0~8 之间(中央 C 是 4)');
          }
          head[key] = Math.round(n);
        }
        continue;
      }
      body.push({ text: line, line: i + 1 });
    }
    return { head: head, body: body };
  }

  /* ============ 记号 → 音 ============ */
  /**
   * 一个 token → **一组**结果(因为简谱连写要拆):
   *   {list:[{midi, beats, rest}, ...]}  —— 一个或多个音
   *   {sustain:true, beats}              —— `-`,把前一个音拉长
   *   {bad:'...'} / {conflict:'...'}     —— 认不出 / 两套记法混用
   *
   * 「连写」是简谱的常态:`1155` 就是 `1 1 5 5`,`1'2'` 是两个高八度音,
   * `11:2` 是「一拍的一 + 两拍的一」。从网页上拷下来的谱常常一个空格都没有,
   * 所以这里按「一个数字 = 一个音」把连写的串拆开(音名不留连写:音名自带八度数字,拆不准)。
   *
   * ctx = {key, base, dialect:'digit'|'letter'|null}:方言由**第一个像样的音**定下来,
   * 定下来之后另一个记法的 token 一律报「混着写」,不猜 —— 猜错就是跑调。
   */
  function parseToken(tok, ctx) {
    var t = tok;
    // 先摘附点(`5.` = 一拍半),再拆拍数 —— 这样 `5:2.` 也是「两拍的附点」= 三拍
    var dotted = false;
    if (t.length > 1 && t.charAt(t.length - 1) === '.') { dotted = true; t = t.slice(0, -1); }
    var beats = 1;
    var ci = t.indexOf(':');
    if (ci >= 0) {
      var bs = t.slice(ci + 1);
      if (bs === '' || !/^\d*\.?\d*$/.test(bs)) return { bad: '拍数' };
      beats = parseFloat(bs);
      if (!isFinite(beats)) return { bad: '拍数' };
      t = t.slice(0, ci);
    }
    if (dotted) beats = beats * 1.5;
    if (!(beats >= LIMITS.beatsMin && beats <= LIMITS.beatsMax)) return { bad: '拍数越界' };

    if (t === '') return { bad: '空音' };
    if (t === '-') return { sustain: true, beats: beats };
    if (t === '0') return { list: [{ midi: -1, beats: beats, rest: true }] };

    // 这个 token 看起来像简谱吗?(数字、中文数字,或 `#4` / `b7` 这种带升降号的数字)
    var head = t.charAt(0);
    var second = t.charAt(1);
    var isDigitCh = function (c) { return /^[0-7]$/.test(c) || CN_DIGIT[c] !== undefined; };
    var asDigit = isDigitCh(head) || ((head === '#' || head === 'b') && isDigitCh(second));

    if (ctx.dialect === 'letter') {
      var lo = asLetter(t);
      if (lo !== null) return { list: [{ midi: lo, beats: beats, rest: false }] };
      if (asDigit) return { conflict: tok };
      return { bad: '音' };
    }
    if (ctx.dialect === 'digit') {
      if (!asDigit) {
        if (asLetter(t) !== null) return { conflict: tok };
        return { bad: '音' };
      }
      return digitNotes(t, beats, ctx);
    }
    // 方言还没定:数字优先当简谱,其余当音名
    if (asDigit) return digitNotes(t, beats, ctx);
    var l0 = asLetter(t);
    if (l0 !== null) { ctx.dialect = 'letter'; return { list: [{ midi: l0, beats: beats, rest: false }] }; }
    return { bad: '音' };
  }

  /** 音名:C4 / D#5 / Bb4 / C(缺省八度取 4,与 scores.js 的注释一致)。对不上返回 null */
  function asLetter(t) {
    var m = /^([A-Ga-g])([#b]?)(-?\d)?$/.exec(t);
    if (!m) return null;
    var oct = (m[3] === undefined || m[3] === '') ? 4 : parseInt(m[3], 10);
    return midiOfLetter(m[1].toUpperCase(), m[2] || '', oct);
  }

  /** 简谱:先按「一个数字一个音」拆连写,再逐个算音高 */
  function digitNotes(t, beats, ctx) {
    var pieces = splitDigitRun(t);
    if (!pieces) return { bad: '音' };
    var out = [];
    for (var i = 0; i < pieces.length; i++) {
      var one = digitPiece(pieces[i], i === pieces.length - 1 ? beats : 1, ctx);
      if (one.bad || one.conflict) return one;
      out.push(one);
    }
    ctx.dialect = 'digit';
    return { list: out };
  }

  /**
   * 把 `1'2'` / `1155` / `11:2` / `#4b7` 拆成一个个「单音」串。
   * 拆不出来(混了别的字符)返回 null —— 让上层报「认不出」,不要猜。
   */
  function splitDigitRun(t) {
    var out = [];
    var i = 0;
    var isDigitCh = function (c) { return /^[0-7]$/.test(c) || CN_DIGIT[c] !== undefined; };
    while (i < t.length) {
      var start = i;
      if (t.charAt(i) === '#' || t.charAt(i) === 'b') i++;
      if (!isDigitCh(t.charAt(i))) return null;
      i++;
      while (i < t.length && (t.charAt(i) === "'" || t.charAt(i) === ',')) i++;
      if (t.charAt(i) === '#' || t.charAt(i) === 'b') i++;      // `4#` 反着写也认
      if (t.charAt(i) === ':') {
        i++;
        while (i < t.length && /[0-9.]/.test(t.charAt(i))) i++;
      }
      out.push(t.slice(start, i));
    }
    return out.length ? out : null;
  }

  /** 单音简谱:`#4` / `1''` / `0` / `5:2`(拍数已在外层摘好) */
  function digitPiece(t, beats, ctx) {
    var accidental = '';
    var body = t;
    if (body.charAt(0) === '#' || body.charAt(0) === 'b') {
      accidental = body.charAt(0);
      body = body.slice(1);
    }
    var ch = body.charAt(0);
    var digit = LNUM[ch];
    if (digit === undefined) digit = CN_DIGIT[ch];
    if (digit === undefined) return { bad: '音' };
    var marks = body.slice(1);
    var up = 0, down = 0;
    if (marks.length) {
      var tailAcc = /([#b])$/.exec(marks);                       // `4#` 这种反着写的
      if (tailAcc && accidental === '') { accidental = tailAcc[1]; marks = marks.slice(0, -1); }
      if (marks === '') { /* 只剩升降号,已经吃掉了 */ }
      else if (/^'+$/.test(marks)) up = marks.length;
      else if (/^,+$/.test(marks)) down = marks.length;
      else return { bad: '八度点' };
      if (up > LIMITS.octaveMarks || down > LIMITS.octaveMarks) return { bad: '八度点太多' };
    }
    if (digit === 0) {
      if (up || down) return { bad: '八度点' };                   // 休止没有高低八度
      return { midi: -1, beats: beats, rest: true };
    }
    var tonic = LETTER[ctx.key];
    if (tonic === undefined) return { bad: '主音' };
    var semi = SCALE[digit - 1];
    if (semi === undefined) return { bad: '音' };
    if (accidental === '#') semi += 1;
    else if (accidental === 'b') semi -= 1;
    var midi = (ctx.base + 1) * 12 + tonic + semi + 12 * (up - down);
    return { midi: midi, beats: beats, rest: false, digit: digit, up: up, down: down };
  }

  var LNUM = { '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7 };

  /* ============ 正文 → 音符序列 ============ */
  function parseBody(body, head) {
    var ctx = { key: head.key || 'C', base: head.base === null ? 4 : head.base, dialect: null, seen: 0 };
    var notes = [];
    var bars = [];
    var pendingBar = false;
    for (var i = 0; i < body.length; i++) {
      var text = body[i].text;
      var lineNo = body[i].line;
      var pos = 0;
      while (pos < text.length) {
        var c = text.charAt(pos);
        if (c === ' ' || c === '\t') { pos++; continue; }
        if (isBar(c)) {
          if (notes.length > 0 && !pendingBar) { bars.push(notes.length); pendingBar = true; }
          pos++;
          continue;
        }
        var start = pos;
        while (pos < text.length && text.charAt(pos) !== ' ' && text.charAt(pos) !== '\t' && !isBar(text.charAt(pos))) pos++;
        var tok = foldToken(text.slice(start, pos));
        pendingBar = false;
        var col = start + 1;
        var r = parseToken(tok, ctx);
        if (r && r.bad) {
          return badToken(tok, lineNo, col, r.bad);
        }
        if (r && r.conflict) {
          return err(lineNo, col, where(lineNo, col) + '的「' + tok + '」和前面的记法不是同一套',
            '一段谱要么全用简谱数字(1~7),要么全用音名(C4/D4),别混着写');
        }
        if (r && r.sustain) {
          if (!notes.length) {
            return err(lineNo, col, where(lineNo, col) + '的 `-` 前面没有音可以延长',
              '`-` 是把上一个音再拉长一拍;要写「不出声」请用 0');
          }
          notes[notes.length - 1].beats = notes[notes.length - 1].beats + r.beats;
          if (notes[notes.length - 1].beats > LIMITS.beatsMax) {
            return err(lineNo, col, where(lineNo, col) + '的 `-` 把前一个音拉得太长(超过 ' + LIMITS.beatsMax + ' 拍)',
              '长音请写成一拍一拍的音,或者用 `:拍数`');
          }
          continue;
        }
        for (var g = 0; g < r.list.length; g++) {
          var one = r.list[g];
          if (one.midi !== -1 && (one.midi < LIMITS.midiMin || one.midi > LIMITS.midiMax)) {
            return err(lineNo, col, where(lineNo, col) + '的「' + tok + '」算出来是 ' + midiName(one.midi) + '(MIDI ' + one.midi + '),超出琴键够得着的范围',
                '能弹的音在 ' + midiName(LIMITS.midiMin) + '~' + midiName(LIMITS.midiMax) + ' 之间;简谱用 `,` 降八度、`\'` 升八度');
          }
          notes.push({ midi: one.midi, beats: one.beats, rest: !!one.rest });
          if (notes.length > LIMITS.notesPerSong) {
            return err(lineNo, col, '这首谱超过 ' + LIMITS.notesPerSong + ' 个音了(在' + where(lineNo, col) + ')',
              '内置曲库每首只有一两句;太长的曲子请拆成两首分别导入');
          }
        }
      }
    }
    return { notes: notes, bars: bars };
  }

  function badToken(tok, line, col, kind) {
    var hint = '';
    if (kind === '音') {
      hint = '认得的音:简谱 1~7(可加 #/b,后面跟 `\'` 升八度、`,` 降八度)、音名 C4~B5、休止 0';
      if (/[\u4e00-\u9fa5]/.test(tok)) hint = '这看着像文字而不是音符 —— 曲名请单独起一行写 `@title 曲名`,出处写 `@origin …`';
    } else if (kind === '八度点') hint = '八度点只能写在数字后面(`1\'` 高八度、`1,` 低八度),最多三个;休止不写八度点';
    else if (kind === '八度点太多') hint = '一个音最多跨三个八度,写这么高/低基本是笔误';
    else if (kind === '拍数') hint = '拍数写成 `:2`、`:0.5` 这样的小数,例如 `5:2`';
    else if (kind === '拍数越界') hint = '拍数请写在 ' + LIMITS.beatsMin + '~' + LIMITS.beatsMax + ' 拍之间(`:0.5` 半拍、`:4` 四拍)';
    else if (kind === '空音') hint = '`:` 前面要有音,例如 `5:2`';
    else if (kind === '主音') hint = '主音只能是 A~G,例如 `@key C`';
    return err(line, col, where(line, col) + '的「' + tok + '」认不出', hint);
  }

  function midiName(midi) {
    return LETTER_NAMES[((midi % 12) + 12) % 12] + (Math.floor(midi / 12) - 1);
  }

  /* ============ 一首歌的成形 ============ */
  /**
   * 把文本解析成一首歌。head 里的 title/key/base/bpm/origin 缺省用 fallback。
   * 返回 {ok:true, song} 或 {ok:false, error}
   */
  function songFromText(text, fallback) {
    fallback = fallback || {};
    var sp = splitLines(text);
    if (sp.error) return sp;
    var head = sp.head;
    var pr = parseBody(sp.body, head);
    if (pr.error) return pr;
    if (!pr.notes.length) {
      return {
        ok: false,
        error: {
          line: 1, col: 1,
          message: '这段文本里一个音都没有',
          hint: '至少写几个音:简谱 `1 2 3 4 5` 或音名 `C4 D4 E4`;曲名请另起一行写 `@title 歌名`'
        }
      };
    }
    var title = String(head.title || fallback.title || '未命名').replace(/\s+$/, '');
    if (title.length > LIMITS.titleLen) title = title.slice(0, LIMITS.titleLen);
    var origin = String(head.origin || fallback.origin || '自己导入');
    if (origin.length > LIMITS.originLen) origin = origin.slice(0, LIMITS.originLen);
    return {
      ok: true,
      song: {
        id: fallback.id || newId(),
        title: title || '未命名',
        origin: origin,
        license: fallback.license || 'user',
        key: head.key || fallback.key || 'C',
        base: head.base === null ? 4 : head.base,
        bpm: head.bpm === null ? (fallback.bpm || 100) : head.bpm,
        notes: notesToText(pr.notes, pr.bars, head.key || 'C', head.base === null ? 4 : head.base),
        source: 'user'
      }
    };
  }

  /** 音符序列 → 简谱文本(导入即归一化成简谱,导出、回读都走这条路) */
  function notesToText(notes, bars, key, base) {
    var barSet = {};
    for (var i = 0; i < bars.length; i++) barSet[bars[i]] = 1;
    var parts = [];
    for (var j = 0; j < notes.length; j++) {
      if (barSet[j] && j > 0) parts.push('|');
      parts.push(tokenOf(notes[j], key, base));
    }
    return parts.join(' ');
  }

  /** 一个音 → 简谱记号 */
  function tokenOf(n, key, base) {
    var beats = n.beats;
    var beatTxt = (beats === 1 || !(beats > 0)) ? '' : ':' + trimNum(beats);
    if (n.rest) return '0' + beatTxt;
    var d = digits(n.midi, key, base);
    var marks = '';
    for (var i = 0; i < d.up; i++) marks += "'";
    for (var j = 0; j < d.low; j++) marks += ',';
    return d.digit + marks + beatTxt;   // d.digit 里已经带着 #(不在大调音阶上的音)
  }

  function trimNum(v) {
    var s = (Math.round(v * 1000) / 1000).toString();
    return s;
  }

  /**
   * 音 → 简谱数字(相对曲子主音)。
   *
   * **八度点要按「锚点」算,不能按科学八度算** —— 踩过这个坑:
   * A 调的 `5`(= E)在不带点时应当是 E5(76),而 E5 的科学八度是 5、`@base 4` 是 4,
   * 按「科学八度 - base」去算会多画一个点,导出再导入就整体高了一个八度(致爱丽丝与绿袖子就这么跑偏的)。
   * 正确的问法是:「这个音**不带点时**该是多少 MIDI?差几个八度才到它?」
   * up/low 不做视觉上的截断(截断会让导出再导入时跑调),显示层自己去少画几个点。
   */
  function digits(midi, key, base) {
    var name = midiName(midi);
    var tonic = LETTER[key] || 0;
    var pc = ((midi % 12) + 12) % 12;
    var rel = ((pc - tonic) % 12 + 12) % 12;
    var digit = DEGREE[rel];
    var sharp = '';
    var semi;
    if (digit) {
      semi = SCALE[parseInt(digit, 10) - 1];
    } else {
      var lower = rel === 0 ? 11 : rel - 1;
      digit = DEGREE[lower] || '1';
      sharp = '#';
      semi = SCALE[parseInt(digit, 10) - 1] + 1;      // 升号音:在大调音阶上再升半音
    }
    var anchor = (base + 1) * 12 + tonic + semi;
    var k = Math.round((midi - anchor) / 12);
    return {
      name: name,
      digit: sharp + digit,
      up: k > 0 ? k : 0,
      low: k < 0 ? -k : 0
    };
  }

  /* ============ 对外:导入 ============ */
  function newId() {
    return 'u' + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
  }

  /**
   * 导入一段文本(自动判别 JSON / 简谱文本)。
   * → {ok:true, songs:[song], warnings:[string]} | {ok:false, error:{...}}
   */
  function parseText(text, opt) {
    opt = opt || {};
    var s = String(text == null ? '' : text);
    // 空文本这一句别写成 s.replace(/\s/g,'') —— 那会为 200 万字符的输入多造一个 160 万字符的字符串,
    // 「先拒绝」本身就跑成了 100ms(实测);正则 test 是零分配的
    if (/^\s*$/.test(s)) {
      return { ok: false, error: { line: 1, col: 1, message: '内容是空的', hint: '把简谱文本粘进输入框,或者选一个 .txt / .json 文件' } };
    }
    if (s.length > LIMITS.textLen) {
      return {
        ok: false,
        error: {
          line: 1, col: 1,
          message: '文本太长了(' + s.length + ' 个字符,上限 ' + LIMITS.textLen + ' 个)',
          hint: '内置曲库每首只有一两句,请拆成短谱分别导入'
        }
      };
    }
    var head = s.replace(/^\s+/, '').charAt(0);
    if (head === '{' || head === '[') return parseJson(s, opt);
    var one = songFromText(s, opt);
    if (!one.ok) return one;
    return { ok: true, songs: [one.song], warnings: [] };
  }

  /** JSON:单个对象或数组,字段 title/key/base/bpm/origin/notes(notes 可以是字符串或数组) */
  function parseJson(text, opt) {
    opt = opt || {};
    var data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      var m = /position (\d+)/.exec(String(e && e.message));
      var at = m ? parseInt(m[1], 10) : 0;
      var before = text.slice(0, at);
      var line = before.split('\n').length;
      var col = at - before.lastIndexOf('\n');
      return {
        ok: false,
        error: {
          line: line, col: col,
          message: 'JSON 在第 ' + line + ' 行第 ' + col + ' 个字符附近断了:' + trimMsg(e && e.message),
          hint: 'JSON 要带引号,例如 {"title":"小星星","notes":"1 1 5 5 6 6 5:2"}'
        }
      };
    }
    var arr = Object.prototype.toString.call(data) === '[object Array]' ? data : [data];
    if (!arr.length) return { ok: false, error: { line: 1, col: 1, message: 'JSON 里没有曲子', hint: '至少要有一个 {"title":...,"notes":...} 这样的对象' } };
    if (arr.length > LIMITS.songsPerImport) {
      return { ok: false, error: { line: 1, col: 1, message: '一次最多导入 ' + LIMITS.songsPerImport + ' 首,这份有 ' + arr.length + ' 首', hint: '分几次导入' } };
    }
    var songs = [];
    var warnings = [];
    for (var i = 0; i < arr.length; i++) {
      var it = arr[i];
      if (!it || typeof it !== 'object') {
        return { ok: false, error: { line: 1, col: 1, message: 'JSON 里第 ' + (i + 1) + ' 个不是对象', hint: '每首要写成 {"title":"曲名","notes":"1 2 3"}' } };
      }
      var notesRaw = it.notes;
      if (Object.prototype.toString.call(notesRaw) === '[object Array]') notesRaw = notesRaw.join(' ');
      if (typeof notesRaw !== 'string' || notesRaw.replace(/\s/g, '') === '') {
        return { ok: false, error: { line: 1, col: 1, message: 'JSON 里第 ' + (i + 1) + ' 首「' + (it.title || '无题') + '」没有 notes(谱面)', hint: 'notes 是简谱文本,例如 "1 1 5 5 6 6 5:2"' } };
      }
      var head = '';
      if (it.title) head += '@title ' + it.title + '\n';
      if (it.key) head += '@key ' + it.key + '\n';
      if (typeof it.base === 'number') head += '@base ' + it.base + '\n';
      if (typeof it.bpm === 'number') head += '@bpm ' + it.bpm + '\n';
      if (it.origin) head += '@origin ' + it.origin + '\n';
      var one = songFromText(head + '\n' + notesRaw, {
        title: it.title || opt.title,
        origin: it.origin,
        key: it.key,
        base: it.base,
        bpm: it.bpm,
        id: safeId(it.id)
      });
      if (!one.ok) {
        return {
          ok: false,
          error: {
            line: one.error.line, col: one.error.col,
            message: 'JSON 第 ' + (i + 1) + ' 首:' + one.error.message,
            hint: one.error.hint
          }
        };
      }
      if (it.origin || it.key || it.base) { /* 已由指令带入 */ }
      else warnings.push('第 ' + (i + 1) + ' 首没写主音,按 C 处理;若它不是 C 调,简谱数字会对不上');
      songs.push(one.song);
    }
    return { ok: true, songs: songs, warnings: warnings };
  }

  function trimMsg(m) {
    var s = String(m || '').replace(/\s+/g, ' ').replace(/^JSON\.parse:\s*/, '');
    return s.length > 80 ? s.slice(0, 80) + '…' : s;
  }

  function safeId(id) {
    if (typeof id === 'string' && /^[A-Za-z0-9_-]{1,32}$/.test(id)) return 'u_' + id;
    return null;
  }

  /* ============ 对外:导出 ============ */
  /** 一首歌 → 简谱文本(可直接再导入;也能粘给别人) */
  function formatSong(song) {
    if (!song) return '';
    var key = song.key || 'C';
    var base = typeof song.base === 'number' ? song.base : 4;
    var pr = parseBody(splitLines(String(song.notes || '')).body, { key: key, base: base });
    var bodyText = pr.error ? String(song.notes || '') : notesToText(pr.notes, pr.bars, key, base);
    var head = '@title ' + (song.title || '未命名') + '\n' +
      '@key ' + key + '\n' +
      '@base ' + base + '\n' +
      '@bpm ' + (song.bpm || 100) + '\n';
    if (song.origin) head += '@origin ' + song.origin + '\n';
    return head + '\n' + wrapBars(bodyText);
  }

  /** 每行放 8 个小节左右,导出成文件之后也好读 */
  function wrapBars(text) {
    var toks = text.split(/\s+/);
    var out = [];
    var line = [];
    var bars = 0;
    for (var i = 0; i < toks.length; i++) {
      if (toks[i] === '|') {
        line.push('|');
        bars++;
        if (bars >= 4) { out.push(line.join(' ')); line = []; bars = 0; }
        continue;
      }
      line.push(toks[i]);
    }
    if (line.length) out.push(line.join(' '));
    return out.join('\n');
  }

  /* ============ 对外:曲库 ============ */
  /**
   * 内置 + 用户 合并成一个列表,并把每首的谱面解析一遍。
   * → {items:[{song, notes:[...], bars:[...], builtin:bool, error?}], bad:[...]}
   */
  function buildLibrary(builtin, user) {
    var items = [];
    var bad = [];
    function add(list, builtin_) {
      var arr = list || [];
      for (var i = 0; i < arr.length; i++) {
        var song = arr[i];
        if (!song || typeof song !== 'object') continue;
        var key = song.key || 'C';
        var base = typeof song.base === 'number' ? song.base : 4;
        var pr = parseBody(splitLines(String(song.notes || '')).body, { key: key, base: base });
        var item = {
          song: song,
          builtin: !!builtin_,
          notes: pr.error ? [] : pr.notes,
          bars: pr.error ? [] : pr.bars,
          error: pr.error || null
        };
        if (pr.error) bad.push({ title: song.title || '未命名', error: pr.error });
        items.push(item);
      }
    }
    add(builtin, true);
    add(user, false);
    return { items: items, bad: bad };
  }

  /** 用户谱库的体量校验(存储上限要有界;超了要说人话,不是写坏数据) */
  function checkLibrarySize(userSongs, incoming) {
    var list = (userSongs || []).concat(incoming || []);
    if (list.length > LIMITS.userSongs) {
      return { ok: false, message: '本地最多存 ' + LIMITS.userSongs + ' 首自己导入的谱(现在会有 ' + list.length + ' 首)', hint: '先在「乐谱库」里删掉几首再加' };
    }
    var chars = 0;
    for (var i = 0; i < list.length; i++) chars += String(list[i].notes || '').length;
    if (chars > LIMITS.libraryChars) {
      return { ok: false, message: '自己导入的谱加起来太长(' + chars + ' 个字符,上限 ' + LIMITS.libraryChars + ')', hint: '删掉几首长谱再加' };
    }
    return { ok: true, chars: chars };
  }

  /** 从存储里读回来的数据做一次把关:坏数据丢掉,不许让页面崩 */
  function sanitizeStored(raw) {
    var out = [];
    var arr = null;
    try {
      arr = typeof raw === 'string' ? JSON.parse(raw) : raw;
    } catch (e) {
      return out;
    }
    if (!arr || Object.prototype.toString.call(arr) !== '[object Array]') return out;
    for (var i = 0; i < arr.length && out.length < LIMITS.userSongs; i++) {
      var it = arr[i];
      if (!it || typeof it !== 'object') continue;
      if (typeof it.notes !== 'string') continue;
      if (String(it.notes).length > LIMITS.textLen) continue;
      out.push({
        id: typeof it.id === 'string' ? it.id : newId(),
        title: String(it.title || '未命名').slice(0, LIMITS.titleLen),
        origin: String(it.origin || '自己导入').slice(0, LIMITS.originLen),
        license: typeof it.license === 'string' ? it.license : 'user',
        key: /^[A-G][#b]?$/.test(it.key || '') ? it.key : 'C',
        base: isFinite(it.base) ? clamp(Math.round(it.base), 0, 8) : 4,
        bpm: isFinite(it.bpm) ? clamp(Math.round(it.bpm), LIMITS.bpmMin, LIMITS.bpmMax) : 100,
        notes: it.notes,
        source: 'user'
      });
    }
    return out;
  }

  /** 乐谱要用的琴键范围(选曲后把键盘滚到这首歌的键位上) */
  function matchRange(notes) {
    var lo = -1, hi = -1, mids = [];
    for (var i = 0; i < notes.length; i++) {
      if (notes[i].rest) continue;
      var m = notes[i].midi;
      if (lo < 0 || m < lo) lo = m;
      if (hi < 0 || m > hi) hi = m;
      mids.push(m);
    }
    if (lo < 0) return null;
    mids.sort(function (a, b) { return a - b; });
    return { min: lo, max: hi, mid: mids[Math.floor(mids.length / 2)] };
  }

  /** 一首歌大概多长(秒),给「这一首大约 40 秒」这类人话用 */
  function durationSec(song, notes, speed) {
    var total = 0;
    for (var i = 0; i < notes.length; i++) total += notes[i].beats;
    var bpm = (song && song.bpm) || 100;
    return total * 60 / bpm / (speed || 1);
  }

  return {
    LIMITS: LIMITS,
    normalize: normalize,
    parseText: parseText,
    parseJson: parseJson,
    songFromText: songFromText,
    formatSong: formatSong,
    buildLibrary: buildLibrary,
    checkLibrarySize: checkLibrarySize,
    sanitizeStored: sanitizeStored,
    matchRange: matchRange,
    durationSec: durationSec,
    digits: digits,
    midiName: midiName,
    newId: newId,
    notesToText: notesToText,
    tokenOf: tokenOf
  };
});
