/* ============================================================
   乐器盒 · 内置曲库
   ============================================================
   两类东西:
     · **名曲与民歌** —— 只有公有领域的曲子(作者逝世超 70 年,或作者不明的传统民谣);
       谱面是「旋律骨架」,主歌一两句,够在手机上跟着弹,不是完整编曲。
     · **练习** —— 每件乐器各两首,**按这件乐器真实按得出来的音位写的**:
       音域、走向、句法都对得上。音高只从这件乐器自己的音位表里取 ——
       立弦取弦、音孔取孔、指板与按弦取它够得着的音域;
       取不到的音,跟弹时用户根本点不到那颗音。

   `level` 是练习难度(入门 / 进阶 / 专家),曲库里按它显示,也是排序用的,不是考级。

   记谱与「随身钢琴」完全同一套:
        C4         中央 C,一拍
        G4:2       两拍
        C5:0.5     半拍
        E4:1.      附点(一拍半)
        0          休止   ·   |  小节线,解析时忽略
   也认简谱(`1 2 3` / `1'` 高八度 / `1,` 低八度),导入时用哪一种都行。

   `inst` 是推荐乐器 —— 页面会显示一颗「这首适合古筝」的小胶囊,点一下就换过去,
   **不会自己偷偷换**(乐器是用户在挑的,替他做决定会让人莫名其妙)。
   ============================================================ */
window.JH_BOX_SCORES = [

  /* ---- 名曲与民歌 · 中国 ---- */
  { id: "jasmine", title: "茉莉花", level: "advanced",
    origin: "江苏民歌,清乾隆年间已见于《缀白裘》· 传统",
    key: "C", base: 4, bpm: 92, inst: "guzheng",
    notes: 'E4 E4 G4 A4 C5:2 | C5 A4 G4 A4 G4 | E4 G4 A4 G4 E4 D4 | E4 G4 E4 D4 C4:2 | E4 E4 G4 A4 C5:2 | C5 ' +
           'A4 G4 A4 G4 | E4 G4 A4 G4 E4 D4 | E4 D4 C4:2' },
  { id: "pentarun", title: "五声刮奏(古筝)", level: "basic",
    origin: "练习谱 · 宫商角徵羽上下行",
    key: "C", base: 4, bpm: 132, inst: "guzheng",
    notes: 'C4:0.25 D4:0.25 E4:0.25 G4:0.25 A4:0.25 C5:0.25 D5:0.25 E5:0.25 G5:0.25 A5:0.25 C6:0.5 | A5:0.25 ' +
           'G5:0.25 E5:0.25 D5:0.25 C5:0.25 A4:0.25 G4:0.25 E4:0.25 D4:0.25 C4:1.' },
  { id: "penta", title: "五声音阶", level: "basic",
    origin: "练习谱 · 宫商角徵羽",
    key: "C", base: 4, bpm: 96,
    notes: 'C4 D4 E4 G4 A4 | C5 A4 G4 E4 | D4 E4 G4 A4 C5 | A4 G4 E4 D4 | C4:2' },
  { id: "scale1", title: "音阶 · C 大调", level: "basic",
    origin: "练习谱 · 上下行",
    key: "C", base: 4, bpm: 110, inst: "piano",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | B4 A4 G4 F4 | E4 D4 C4:2' },
  { id: "arp1", title: "琶音 · 三和弦", level: "basic",
    origin: "练习谱 · 适合吉他与竖琴",
    key: "C", base: 4, bpm: 120, inst: "harp",
    notes: 'C4 E4 G4 C5 | E5 C5 G4 E4 | D4 F4 A4 D5 | F5 D5 A4 F4 | E4 G4 B4 E5 | G5 E5 B4 G4 | C4 E4 G4 ' +
           'C5:2' },
  { id: "erhu1", title: "二胡 · 慢弓长音", level: "basic",
    origin: "练习谱 · 长音找感觉",
    key: "D", base: 4, bpm: 60, inst: "erhu",
    notes: 'D4:2 E4:2 | F#4:2 A4:2 | B4:2 A4:2 | F#4:2 E4:2 | D4:4' },

  /* ---- 名曲与民歌 · 西方 ---- */
  { id: "farewell", title: "送别", level: "advanced",
    origin: "曲:Hays《Dreaming of Home and Mother》1851 年;词:李叔同 1915 年",
    key: "C", base: 4, bpm: 80, inst: "erhu",
    notes: 'G4 E4 G4:2 | A4 G4 E4 D4:2 | G4 E4 G4:2 | A4 G4 E4 D4:2 | G4 G4 C5:2 | B4 A4 G4:2 | E4 G4 A4:2 | ' +
           'G4 E4 D4:2' },
  { id: "twinkle", title: "小星星", level: "basic",
    origin: "法国童谣《Ah! vous dirai-je, maman》,约 1761 年 · 传统",
    key: "C", base: 4, bpm: 104,
    notes: 'C4 C4 G4 G4 A4 A4 G4:2 | F4 F4 E4 E4 D4 D4 C4:2 | G4 G4 F4 F4 E4 E4 D4:2 | G4 G4 F4 F4 E4 E4 ' +
           'D4:2 | C4 C4 G4 G4 A4 A4 G4:2 | F4 F4 E4 E4 D4 D4 C4:2' },
  { id: "ode", title: "欢乐颂", level: "basic",
    origin: "贝多芬《第九交响曲》第四乐章,1824 年 · Beethoven(1827 年卒)",
    key: "C", base: 4, bpm: 108,
    notes: 'E4 E4 F4 G4 | G4 F4 E4 D4 | C4 C4 D4 E4 | E4:1. D4:0.5 D4:2 | E4 E4 F4 G4 | G4 F4 E4 D4 | C4 C4 ' +
           'D4 E4 | D4:1. C4:0.5 C4:2' },
  { id: "elise", title: "致爱丽丝(主题)", level: "advanced",
    origin: "贝多芬,1810 年 · Beethoven(1827 年卒)",
    key: "A", base: 4, bpm: 116, inst: "piano",
    notes: 'E5 D#5 E5 D#5 E5 B4 D5 C5 | A4:2 C4 E4 A4 | B4:2 E4 G#4 B4 | C5:2 E4 E5 D#5 | E5 D#5 E5 B4 D5 C5 ' +
           '| A4:2 C4 E4 A4 | B4:2 E4 C5 B4 | A4:2' },
  { id: "canon", title: "卡农(低音线)", level: "basic",
    origin: "帕赫贝尔,约 1680 年 · Pachelbel(1706 年卒)",
    key: "C", base: 3, bpm: 88, inst: "organ",
    notes: 'C3:2 G3:2 A3:2 E3:2 | F3:2 C3:2 F3:2 G3:2 | C3:2 G3:2 A3:2 E3:2 | F3:2 C3:2 F3:2 G3:2' },
  { id: "greensleeves", title: "绿袖子", level: "advanced",
    origin: "英格兰传统曲调,16 世纪 · 传统",
    key: "A", base: 4, bpm: 100, inst: "violin",
    notes: 'A4 C5 D5 E5:1. F5:0.5 | E5 D5:2 B4 G4:1. A4:0.5 | B4 C5:2 A4 A4:1. G#4:0.5 | A4 B4:2 G4 G4:1. ' +
           'A4:0.5 | B4 C5:2 A4 A4:1. G#4:0.5 | A4 B4:2 C5 B4:1. A4:0.5 | G#4 A4:4' },
  { id: "lullaby", title: "摇篮曲", level: "basic",
    origin: "勃拉姆斯,1868 年 · Brahms(1897 年卒)",
    key: "C", base: 4, bpm: 76, inst: "cello",
    notes: 'E4 E4 G4:2 | E4 E4 G4:2 | E4 G4 C5:2 | B4:1. A4:0.5 A4:2 | G4 E4 G4:2 | G4 E4 G4:2 | G4 E4 G4:2 ' +
           '| C5:1. B4:0.5 A4:2' },
  { id: "susanna", title: "苏珊娜", level: "basic",
    origin: "Stephen Foster,1848 年 · Foster(1864 年卒)",
    key: "C", base: 4, bpm: 112,
    notes: 'C4 C4 E4 G4:2 | G4:1. F4:0.5 E4 C4 | C4 C4 E4 G4:2 | G4:1. F4:0.5 E4 C4 | C4 C4 E4 G4 | G4 F4 E4 ' +
           'D4 | D4 D4 E4 D4:2 | D4:2' },
  { id: "jingle", title: "铃儿响叮当", level: "basic",
    origin: "James Lord Pierpont,1857 年 · Pierpont(1893 年卒)",
    key: "C", base: 4, bpm: 120, inst: "glocken",
    notes: 'E4 E4 E4:2 | E4 E4 E4:2 | E4 G4 C4 D4 E4:4 | F4 F4 F4 F4 | F4 E4 E4 E4 | E4 D4 D4 E4 | D4:2 G4:2' },
  { id: "birthday", title: "生日快乐", level: "basic",
    origin: "Patty 与 Mildred Hill,1893 年(美国法院 2016 年判定版权主张无效)",
    key: "C", base: 4, bpm: 108,
    notes: 'C4:0.5 C4:0.5 D4 C4 F4 E4:2 | C4:0.5 C4:0.5 D4 C4 G4 F4:2 | C4:0.5 C4:0.5 C5 A4 F4 E4 D4 | ' +
           'Bb4:0.5 Bb4:0.5 A4 F4 G4 F4:2' },
  { id: "rowboat", title: "划船歌", level: "basic",
    origin: "美国传统曲调,1852 年 · 传统",
    key: "C", base: 4, bpm: 92,
    notes: 'C4:1. C4:0.5 C4:1. D4:0.5 E4 | E4:1. D4:0.5 E4:1. F4:0.5 G4:2 | C5:0.5 C5:0.5 C5:0.5 G4:0.5 ' +
           'G4:0.5 G4:0.5 E4:0.5 E4:0.5 E4:0.5 C4:0.5 C4:0.5 C4:0.5 | G4:1. F4:0.5 E4:1. D4:0.5 C4:2' },
  { id: "frajacques", title: "两只老虎", level: "basic",
    origin: "法国传统轮唱《Frère Jacques》· 传统",
    key: "C", base: 4, bpm: 112,
    notes: 'C4 D4 E4 C4 | C4 D4 E4 C4 | E4 F4 G4:2 | E4 F4 G4:2 | G4 A4 G4 F4 E4 C4 | G4 A4 G4 F4 E4 C4 | C4 ' +
           'G3 C4:2 | C4 G3 C4:2' },
  { id: "mary", title: "玛丽有只小羊羔", level: "basic",
    origin: "美国童谣,1830 年 · 传统",
    key: "C", base: 4, bpm: 112,
    notes: 'E4 D4 C4 D4 E4 E4 E4:2 | D4 D4 D4:2 | E4 G4 G4:2 | E4 D4 C4 D4 E4 E4 E4 E4 | D4 D4 E4 D4 C4:4' },
  { id: "london", title: "伦敦桥", level: "basic",
    origin: "英格兰传统童谣 · 传统",
    key: "C", base: 4, bpm: 116,
    notes: 'G4 A4 G4 F4 | E4 F4 G4:2 | D4 E4 F4:2 | E4 F4 G4:2 | G4 A4 G4 F4 E4 F4 G4 | D4 G4 E4 C4:2' },
  { id: "auldlang", title: "友谊地久天长", level: "basic",
    origin: "苏格兰民谣,罗伯特·彭斯记词 1788 年 · 传统",
    key: "C", base: 4, bpm: 84, inst: "xiao",
    notes: 'G3:2 | C4 C4 C4 E4 | D4 C4 D4 E4 | C4 C4 E4 G4 | A4:2 A4 | A4 A4 A4 G4 | E4 C4 D4 E4 | C4 A3 A3 ' +
           'C4 | G3:2 C4:2' },
  { id: "bee", title: "小蜜蜂", level: "basic",
    origin: "德国传统儿歌《Summ, summ, summ》· 传统",
    key: "C", base: 4, bpm: 120,
    notes: 'G4 E4 E4:2 | F4 D4 D4:2 | C4 D4 E4 F4 G4 G4 G4:2 | G4:0.5 G4:0.5 E4 E4 | F4:0.5 F4:0.5 D4 D4 | ' +
           'C4 E4 G4:2' },

  /* ---- 名曲骨架 · 奇异恩典 ---- */
  { id: "amazing", title: "奇异恩典(首句)", level: "expert",
    origin: "词:John Newton 1779 年 · 曲:美国传统《New Britain》",
    key: "C", base: 4, bpm: 72, inst: "flute",
    notes: 'G4 C5 E5 C5 | E5 D5 C5 A4 | G4:2 G4 C5 E5 C5 | E5 D5 G5 E5' },

  /* ---- 练习 · 弹拨(每件乐器两首,按它自己的音位写) ---- */
  { id: "ex_guzheng_A", title: "古筝·上下行", level: "basic",
    origin: "练习谱 · 一件乐器的音位走一遍",
    key: "C", base: 4, bpm: 88, inst: "guzheng",
    notes: 'B2 D3 E3 F#3 | A3 B3 D4 D4 | B3 A3 F#3 E3 | D3 B2' },
  { id: "ex_guzheng_B", title: "古筝·三度模进", level: "advanced",
    origin: "练习谱 · 隔一根弦走",
    key: "C", base: 4, bpm: 100, inst: "guzheng",
    notes: 'B2:0.5 E3:0.5 D3:0.5 F#3:0.5 E3:0.5 A3:0.5 F#3:0.5 B3:0.5 | A3:0.5 D4:0.5 B3:0.5 E4:0.5 F#4:2' },
  { id: "ex_guqin_A", title: "古琴·上下行", level: "basic",
    origin: "练习谱 · 一件乐器的音位走一遍",
    key: "C", base: 4, bpm: 88, inst: "guqin",
    notes: 'D2 F2 G2 A2 | C3 D3 D3 D3 | D3 C3 A2 G2 | F2 D2' },
  { id: "ex_guqin_B", title: "古琴·三度模进", level: "advanced",
    origin: "练习谱 · 隔一根弦走",
    key: "C", base: 4, bpm: 100, inst: "guqin",
    notes: 'D2:0.5 G2:0.5 F2:0.5 A2:0.5 G2:0.5 C3:0.5 D3:2' },
  { id: "ex_harp_A", title: "竖琴·上下行", level: "basic",
    origin: "练习谱 · 一件乐器的音位走一遍",
    key: "C", base: 4, bpm: 88, inst: "harp",
    notes: 'A4 B4 C5 D5 | E5 F5 G5 G5 | F5 E5 D5 C5 | B4 A4' },
  { id: "ex_harp_B", title: "竖琴·三度模进", level: "advanced",
    origin: "练习谱 · 隔一根弦走",
    key: "C", base: 4, bpm: 100, inst: "harp",
    notes: 'A4:0.5 C5:0.5 B4:0.5 D5:0.5 C5:0.5 E5:0.5 D5:0.5 F5:0.5 | E5:0.5 G5:0.5 F5:0.5 A5:0.5 B5:2' },
  { id: "ex_kalimba_A", title: "卡林巴·上下行", level: "basic",
    origin: "练习谱 · 一件乐器的音位走一遍",
    key: "C", base: 4, bpm: 88, inst: "kalimba",
    notes: 'E4 F4 G4 A4 | B4 C5 D5 D5 | C5 B4 A4 G4 | F4 E4' },
  { id: "ex_kalimba_B", title: "卡林巴·三度模进", level: "advanced",
    origin: "练习谱 · 隔一根弦走",
    key: "C", base: 4, bpm: 100, inst: "kalimba",
    notes: 'E4:0.5 G4:0.5 F4:0.5 A4:0.5 G4:0.5 B4:0.5 A4:0.5 C5:0.5 | B4:0.5 D5:0.5 C5:0.5 E5:0.5 F5:2' },
  { id: "ex_yangqin_A", title: "扬琴·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "yangqin",
    notes: 'C3 D3 E3 F3 | G3 A3 B3 C4 | C4 B3 A3 G3 | F3 E3 D3 C3' },
  { id: "ex_yangqin_B", title: "扬琴·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "yangqin",
    notes: 'C3:0.5 E3:0.5 D3:0.5 F3:0.5 E3:0.5 G3:0.5 F3:0.5 A3:0.5 | G3:0.5 B3:0.5 A3:0.5 C4:0.5 B3:0.5 ' +
           'D4:0.5 C4:0.5 E4:0.5 | E4:2' },
  { id: "ex_guitar_A", title: "吉他·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "guitar",
    notes: 'E2:0.5 A2:0.5 B2:0.5 A2:0.5 A2:0.5 D3:0.5 E3:0.5 D3:0.5 | D3:0.5 G3:0.5 A3:0.5 G3:0.5 G3:0.5 ' +
           'C4:0.5 D4:0.5 C4:0.5 | B3:0.5 E4:0.5 F#4:0.5 E4:0.5 E4:0.5 A4:0.5 B4:0.5 A4:0.5' },
  { id: "ex_guitar_B", title: "吉他·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "guitar",
    notes: 'C3:0.5 E3:0.5 G3:0.5 C4:0.5 E4:0.5 G4:0.5 C5:2' },
  { id: "ex_ukulele_A", title: "尤克里里·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "ukulele",
    notes: 'C4:0.5 F4:0.5 G4:0.5 F4:0.5 E4:0.5 A4:0.5 B4:0.5 A4:0.5 | G4:0.5 C5:0.5 D5:0.5 C5:0.5 A4:0.5 ' +
           'D5:0.5 E5:0.5 D5:0.5' },
  { id: "ex_ukulele_B", title: "尤克里里·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "ukulele",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:2' },
  { id: "ex_pipa_A", title: "琵琶·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "pipa",
    notes: 'A2:0.5 D3:0.5 E3:0.5 D3:0.5 D3:0.5 G3:0.5 A3:0.5 G3:0.5 | E3:0.5 A3:0.5 B3:0.5 A3:0.5 A3:0.5 ' +
           'D4:0.5 E4:0.5 D4:0.5' },
  { id: "ex_pipa_B", title: "琵琶·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "pipa",
    notes: 'C3:0.5 E3:0.5 G3:0.5 C4:0.5 E4:0.5 G4:2' },
  { id: "ex_ruan_A", title: "中阮·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "ruan",
    notes: 'G2:0.5 C3:0.5 D3:0.5 C3:0.5 D3:0.5 G3:0.5 A3:0.5 G3:0.5 | A3:0.5 D4:0.5 E4:0.5 D4:0.5 E4:0.5 ' +
           'A4:0.5 B4:0.5 A4:0.5' },
  { id: "ex_ruan_B", title: "中阮·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "ruan",
    notes: 'C3:0.5 E3:0.5 G3:0.5 C4:0.5 E4:0.5 G4:0.5 C5:2' },
  { id: "ex_mandolin_A", title: "曼陀林·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "mandolin",
    notes: 'G3:0.5 C4:0.5 D4:0.5 C4:0.5 D4:0.5 G4:0.5 A4:0.5 G4:0.5 | A4:0.5 D5:0.5 E5:0.5 D5:0.5 E5:0.5 ' +
           'A5:0.5 B5:0.5 A5:0.5' },
  { id: "ex_mandolin_B", title: "曼陀林·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "mandolin",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:0.5 C6:2' },
  { id: "ex_sanxian_A", title: "三弦·空弦与五品", level: "basic",
    origin: "练习谱 · 每根弦都走一遍",
    key: "C", base: 4, bpm: 84, inst: "sanxian",
    notes: 'G2:0.5 C3:0.5 D3:0.5 C3:0.5 D3:0.5 G3:0.5 A3:0.5 G3:0.5 | G3:0.5 C4:0.5 D4:0.5 C4:0.5' },
  { id: "ex_sanxian_B", title: "三弦·分解和弦", level: "expert",
    origin: "练习谱 · C 大三和弦铺满音域",
    key: "C", base: 4, bpm: 96, inst: "sanxian",
    notes: 'C3:0.5 E3:0.5 G3:0.5 C4:0.5 E4:0.5 G4:2' },

  /* ---- 练习 · 拉弦(每件乐器两首,按它自己的音位写) ---- */
  { id: "ex_erhu_A", title: "二胡·长弓", level: "basic",
    origin: "练习谱 · 一弓一个音,把音听平",
    key: "C", base: 4, bpm: 60, inst: "erhu",
    notes: 'A4:4 | D4:4 | A4:2 D4:2' },
  { id: "ex_erhu_B", title: "二胡·一个八度的音阶", level: "expert",
    origin: "练习谱 · 换把别跳",
    key: "C", base: 4, bpm: 72, inst: "erhu",
    notes: 'D5 E5 F5 G5 | A5 B5 C6 D6 | C6 B5 A5 G5 | F5 E5 D5' },
  { id: "ex_violin_A", title: "小提琴·长弓", level: "basic",
    origin: "练习谱 · 一弓一个音,把音听平",
    key: "C", base: 4, bpm: 60, inst: "violin",
    notes: 'E5:4 | G3:4 | E5:2 G3:2' },
  { id: "ex_violin_B", title: "小提琴·一个八度的音阶", level: "expert",
    origin: "练习谱 · 换把别跳",
    key: "C", base: 4, bpm: 72, inst: "violin",
    notes: 'G4 A4 B4 C5 | D5 E5 F5 G5 | F5 E5 D5 C5 | B4 A4 G4' },
  { id: "ex_cello_A", title: "大提琴·长弓", level: "basic",
    origin: "练习谱 · 一弓一个音,把音听平",
    key: "C", base: 4, bpm: 60, inst: "cello",
    notes: 'A3:4 | C2:4 | A3:2 C2:2' },
  { id: "ex_cello_B", title: "大提琴·一个八度的音阶", level: "expert",
    origin: "练习谱 · 换把别跳",
    key: "C", base: 4, bpm: 72, inst: "cello",
    notes: 'C3 D3 E3 F3 | G3 A3 B3 C4 | B3 A3 G3 F3 | E3 D3 C3' },
  { id: "ex_matouqin_A", title: "马头琴·长弓", level: "basic",
    origin: "练习谱 · 一弓一个音,把音听平",
    key: "C", base: 4, bpm: 60, inst: "matouqin",
    notes: 'D4:4 | A3:4 | D4:2 A3:2' },
  { id: "ex_matouqin_B", title: "马头琴·一个八度的音阶", level: "expert",
    origin: "练习谱 · 换把别跳",
    key: "C", base: 4, bpm: 72, inst: "matouqin",
    notes: 'A4 B4 C5 D5 | E5 F5 G5 A5 | G5 F5 E5 D5 | C5 B4 A4' },

  /* ---- 练习 · 吹管(每件乐器两首,按它自己的音位写) ---- */
  { id: "ex_dizi_A", title: "竹笛·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "dizi",
    notes: 'D4 E4 F#4 G4 | A4 B4 C#5 D5 | D5 C#5 B4 A4 | G4 F#4 E4 D4' },
  { id: "ex_dizi_B", title: "竹笛·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "dizi",
    notes: 'D4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 A4:0.5 G4:0.5 B4:0.5 | A4:0.5 C#5:0.5 B4:0.5 D5:0.5 C#5:0.5 ' +
           'E5:0.5 D5:0.5 F#5:0.5 | F#5:2' },
  { id: "ex_xiao_A", title: "洞箫·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "xiao",
    notes: 'D4 E4 F#4 G4 | A4 B4 C#5 D5 | D5 C#5 B4 A4 | G4 F#4 E4 D4' },
  { id: "ex_xiao_B", title: "洞箫·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "xiao",
    notes: 'D4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 A4:0.5 G4:0.5 B4:0.5 | A4:0.5 C#5:0.5 B4:0.5 D5:0.5 C#5:0.5 ' +
           'E5:0.5 D5:0.5 F#5:0.5 | F#5:2' },
  { id: "ex_xun_A", title: "埙·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "xun",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | C5 B4 A4 G4 | F4 E4 D4 C4' },
  { id: "ex_xun_B", title: "埙·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "xun",
    notes: 'C4:0.5 E4:0.5 D4:0.5 F4:0.5 E4:0.5 G4:0.5 F4:0.5 A4:0.5 | G4:0.5 B4:0.5 A4:0.5 C5:0.5 B4:0.5 ' +
           'D5:0.5 C5:0.5 E5:0.5 | E5:2' },
  { id: "ex_suona_A", title: "唢呐·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "suona",
    notes: 'G4 A4 B4 C5 | D5 E5 F#5 G5 | G5 F#5 E5 D5 | C5 B4 A4 G4' },
  { id: "ex_suona_B", title: "唢呐·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "suona",
    notes: 'G4:0.5 B4:0.5 A4:0.5 C5:0.5 B4:0.5 D5:0.5 C5:0.5 E5:0.5 | D5:0.5 F#5:0.5 E5:0.5 G5:0.5 F#5:0.5 ' +
           'A5:0.5 G5:0.5 B5:0.5 | B5:2' },
  { id: "ex_sheng_A", title: "笙·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "sheng",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | C5 B4 A4 G4 | F4 E4 D4 C4' },
  { id: "ex_sheng_B", title: "笙·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "sheng",
    notes: 'C4:0.5 E4:0.5 D4:0.5 F4:0.5 E4:0.5 G4:0.5 F4:0.5 A4:0.5 | G4:0.5 B4:0.5 A4:0.5 C5:0.5 B4:0.5 ' +
           'D5:0.5 C5:0.5 E5:0.5 | E5:2' },
  { id: "ex_flute_A", title: "长笛·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "flute",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | C5 B4 A4 G4 | F4 E4 D4 C4' },
  { id: "ex_flute_B", title: "长笛·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "flute",
    notes: 'C4:0.5 E4:0.5 D4:0.5 F4:0.5 E4:0.5 G4:0.5 F4:0.5 A4:0.5 | G4:0.5 B4:0.5 A4:0.5 C5:0.5 B4:0.5 ' +
           'D5:0.5 C5:0.5 E5:0.5 | E5:2' },
  { id: "ex_clarinet_A", title: "单簧管·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "clarinet",
    notes: 'E3 F#3 G#3 A3 | B3 C#4 D#4 E4 | E4 D#4 C#4 B3 | A3 G#3 F#3 E3' },
  { id: "ex_clarinet_B", title: "单簧管·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "clarinet",
    notes: 'E3:0.5 G#3:0.5 F#3:0.5 A3:0.5 G#3:0.5 B3:0.5 A3:0.5 C#4:0.5 | B3:0.5 D#4:0.5 C#4:0.5 E4:0.5 ' +
           'D#4:0.5 F#4:0.5 E4:0.5 G#4:0.5 | G#4:2' },
  { id: "ex_trumpet_A", title: "小号·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "trumpet",
    notes: 'D4 E4 F#4 G4 | A4 B4 C#5 D5 | D5 C#5 B4 A4 | G4 F#4 E4 D4' },
  { id: "ex_trumpet_B", title: "小号·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "trumpet",
    notes: 'D4:0.5 F#4:0.5 E4:0.5 G4:0.5 F#4:0.5 A4:0.5 G4:0.5 B4:0.5 | A4:0.5 C#5:0.5 B4:0.5 D5:0.5 C#5:0.5 ' +
           'E5:0.5 D5:0.5 F#5:0.5 | F#5:2' },
  { id: "ex_sax_A", title: "萨克斯·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "sax",
    notes: 'A#3 C4 D4 D#4 | F4 G4 A4 A#4 | A#4 A4 G4 F4 | D#4 D4 C4 A#3' },
  { id: "ex_sax_B", title: "萨克斯·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "sax",
    notes: 'A#3:0.5 D4:0.5 C4:0.5 D#4:0.5 D4:0.5 F4:0.5 D#4:0.5 G4:0.5 | F4:0.5 A4:0.5 G4:0.5 A#4:0.5 A4:0.5 ' +
           'C5:0.5 A#4:0.5 D5:0.5 | D5:2' },
  { id: "ex_harmonica_A", title: "口琴·级进", level: "basic",
    origin: "练习谱 · 一口气吹完一句",
    key: "C", base: 4, bpm: 76, inst: "harmonica",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | C5 B4 A4 G4 | F4 E4 D4 C4' },
  { id: "ex_harmonica_B", title: "口琴·隔一个音走", level: "advanced",
    origin: "练习谱 · 手指要落得准",
    key: "C", base: 4, bpm: 92, inst: "harmonica",
    notes: 'C4:0.5 E4:0.5 D4:0.5 F4:0.5 E4:0.5 G4:0.5 F4:0.5 A4:0.5 | G4:0.5 B4:0.5 A4:0.5 C5:0.5 B4:0.5 ' +
           'D5:0.5 C5:0.5 E5:0.5 | E5:2' },

  /* ---- 练习 · 键盘(每件乐器两首,按它自己的音位写) ---- */
  { id: "ex_piano_A", title: "钢琴·一个八度的音阶", level: "basic",
    origin: "练习谱 · 手指先站住",
    key: "C", base: 4, bpm: 80, inst: "piano",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | B4 A4 G4 F4 | E4 D4 C4' },
  { id: "ex_piano_B", title: "钢琴·琶音", level: "expert",
    origin: "练习谱 · 和弦摊开弹",
    key: "C", base: 4, bpm: 96, inst: "piano",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:0.5 C6:2' },
  { id: "ex_epiano_A", title: "电钢琴·一个八度的音阶", level: "basic",
    origin: "练习谱 · 手指先站住",
    key: "C", base: 4, bpm: 80, inst: "epiano",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | B4 A4 G4 F4 | E4 D4 C4' },
  { id: "ex_epiano_B", title: "电钢琴·琶音", level: "expert",
    origin: "练习谱 · 和弦摊开弹",
    key: "C", base: 4, bpm: 96, inst: "epiano",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:0.5 C6:2' },
  { id: "ex_organ_A", title: "管风琴·一个八度的音阶", level: "basic",
    origin: "练习谱 · 手指先站住",
    key: "C", base: 4, bpm: 80, inst: "organ",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | B4 A4 G4 F4 | E4 D4 C4' },
  { id: "ex_organ_B", title: "管风琴·琶音", level: "expert",
    origin: "练习谱 · 和弦摊开弹",
    key: "C", base: 4, bpm: 96, inst: "organ",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:0.5 C6:2' },
  { id: "ex_harpsichord_A", title: "羽管键琴·一个八度的音阶", level: "basic",
    origin: "练习谱 · 手指先站住",
    key: "C", base: 4, bpm: 80, inst: "harpsichord",
    notes: 'C4 D4 E4 F4 | G4 A4 B4 C5 | B4 A4 G4 F4 | E4 D4 C4' },
  { id: "ex_harpsichord_B", title: "羽管键琴·琶音", level: "expert",
    origin: "练习谱 · 和弦摊开弹",
    key: "C", base: 4, bpm: 96, inst: "harpsichord",
    notes: 'C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 G5:0.5 C6:2' },
  { id: "ex_glocken_A", title: "钢片琴·一个八度的音阶", level: "basic",
    origin: "练习谱 · 手指先站住",
    key: "C", base: 4, bpm: 80, inst: "glocken",
    notes: 'C5 D5 E5 F5 | G5 A5 B5 C6 | B5 A5 G5 F5 | E5 D5 C5' },
  { id: "ex_glocken_B", title: "钢片琴·琶音", level: "expert",
    origin: "练习谱 · 和弦摊开弹",
    key: "C", base: 4, bpm: 96, inst: "glocken",
    notes: 'C5:0.5 E5:0.5 G5:0.5 C6:0.5 E6:0.5 G6:0.5 C7:2' },

  /* ---- 练习 · 打击(每件乐器两首,按它自己的音位写) ---- */
  { id: "ex_drumset_a", title: "堂鼓·单跳与重音", level: "basic",
    origin: "练习谱 · 跟着亮的地方敲",
    key: "C", base: 4, bpm: 84, inst: "drumset",
    notes: 'C4 C4 C#4 C4 | C4 C4 C#4 D4' },
  { id: "ex_drumset_b", title: "堂鼓·四分八分", level: "expert",
    origin: "练习谱 · 手上先稳",
    key: "C", base: 4, bpm: 72, inst: "drumset",
    notes: 'C4 C#4:0.5 C#4:0.5 C4 D4:0.5 D4:0.5 | C4 D#4 C4:0.5 C#4:0.5 D4:0.5 D#4:0.5' },
  { id: "ex_bianzhong_A", title: "编钟·一台钟走一遍", level: "basic",
    origin: "练习谱 · 左半边是正鼓",
    key: "C", base: 4, bpm: 72, inst: "bianzhong",
    notes: 'C4 D4 E4 G4 | A4 C5 D5 E5' },
  { id: "ex_bianzhong_B", title: "编钟·隔一口钟", level: "advanced",
    origin: "练习谱 · 手要跨得开",
    key: "C", base: 4, bpm: 84, inst: "bianzhong",
    notes: 'C4 E4 G4 C5 | D5 G5 A5 D6 | E6 A6' },
  { id: "ex_muyu_a", title: "木鱼·单跳与重音", level: "basic",
    origin: "练习谱 · 跟着亮的地方敲",
    key: "C", base: 4, bpm: 84, inst: "muyu",
    notes: 'C4 C4 C#4 C4 | C4 C4 C#4 D4' },
  { id: "ex_muyu_b", title: "木鱼·四分八分", level: "expert",
    origin: "练习谱 · 手上先稳",
    key: "C", base: 4, bpm: 72, inst: "muyu",
    notes: 'C4 C#4:0.5 C#4:0.5 C4 D4:0.5 D4:0.5 | C4 D#4 C4:0.5 C#4:0.5 D4:0.5 D#4:0.5' },
  { id: "ex_triangle_a", title: "三角铁·单跳与重音", level: "basic",
    origin: "练习谱 · 跟着亮的地方敲",
    key: "C", base: 4, bpm: 84, inst: "triangle",
    notes: 'C4 C4 C#4 C4 | C4 C4 C#4 D4' },
  { id: "ex_triangle_b", title: "三角铁·四分八分", level: "expert",
    origin: "练习谱 · 手上先稳",
    key: "C", base: 4, bpm: 72, inst: "triangle",
    notes: 'C4 C#4:0.5 C#4:0.5 C4 D4:0.5 D4:0.5 | C4 D#4 C4:0.5 C#4:0.5 D4:0.5 D#4:0.5' },
  { id: "ex_luo_a", title: "锣与钹·单跳与重音", level: "basic",
    origin: "练习谱 · 跟着亮的地方敲",
    key: "C", base: 4, bpm: 84, inst: "luo",
    notes: 'C4 C4 C#4 C4 | C4 C4 C#4 D4' },
  { id: "ex_luo_b", title: "锣与钹·四分八分", level: "expert",
    origin: "练习谱 · 手上先稳",
    key: "C", base: 4, bpm: 72, inst: "luo",
    notes: 'C4 C#4:0.5 C#4:0.5 C4 D4:0.5 D4:0.5 | C4 D#4 C4:0.5 C#4:0.5 D4:0.5 D#4:0.5' },

  /* ---- 名曲与民歌 · 经典(只收我敢保证音高的:抄错音符比少一首更坏) ---- */
  { id: "silentnight", title: "平安夜(首句)", level: "advanced",
    origin: "词:Joseph Mohr 1818 年 · 曲:Franz Gruber(1863 年卒,公有领域)",
    key: "C", base: 4, bpm: 72, inst: "glocken",
    notes: "G4:1.5 A4:0.5 G4 E4:2 | G4:1.5 A4:0.5 G4 E4:2 | D5:2 D5:2 | B4:3 C5 | C5 C5 G4:2" },
  { id: "mcdonald", title: "老麦克唐纳", level: "advanced",
    origin: "美国传统童谣 · 传统(作者不明)",
    key: "C", base: 4, bpm: 104, inst: "kalimba",
    notes: "G4 G4 G4 D4 E4 E4 D4:2 | B4 B4 A4 A4 G4:2 | D4 G4 G4 D4 E4 E4 D4:2" },
  { id: "saints", title: "圣徒进行曲", level: "expert",
    origin: "美国传统圣歌《When the Saints Go Marching In》· 传统(作者不明)",
    key: "C", base: 4, bpm: 116, inst: "harmonica",
    notes: "C4 E4 F4 G4:3 C4 E4 F4 G4:3 C4 E4 F4 G4 E4 C4 E4 D4:4" },
  { id: "hanon1", title: "古典练习 · 固定音型逐级上移", level: "expert",
    origin: "练习谱 · 照古典钢琴教程的固定音型写法(每句换一个位置)",
    key: "C", base: 4, bpm: 72, inst: "piano",
    notes: "C4:0.5 E4:0.5 F4:0.5 G4:0.5 A4:0.5 G4:0.5 F4:0.5 E4:0.5 | " +
           "D4:0.5 F4:0.5 G4:0.5 A4:0.5 B4:0.5 A4:0.5 G4:0.5 F4:0.5 | " +
           "E4:0.5 G4:0.5 A4:0.5 B4:0.5 C5:0.5 B4:0.5 A4:0.5 G4:0.5 | " +
           "F4:0.5 A4:0.5 B4:0.5 C5:0.5 D5:0.5 C5:0.5 B4:0.5 A4:0.5" },

  /* ============================================================
     ② 名曲与民歌 · 扩编
     ------------------------------------------------------------
     规矩和上面一样:**只收我敢保证音高的**。音高是这一页唯一的硬事实 ——
     谱面上一个音写错,用户跟弹时按下去就是"不对劲",而他不会说"谱写错了",
     只会说"这个乐器坏了吧"。宁可少收一首。
     · 传统曲调(作者不明)、逝世逾七十年的作曲家、或美国法院已判归公有的作品;
     · 每一首都**照着推荐乐器真实按得出的音位写**(照音位挑调,不是照谱硬挪);
       所以《扬基歌》落在竹笛的 D 调上、《卖货郎》落在曼陀林的 Am 上,都不是巧合。
     ============================================================ */
  { id: "yankeedoodle", title: "扬基歌", level: "advanced",
    origin: "北美传统曲调,约 1755 年 · 传统(作者不明)",
    key: "D", base: 5, bpm: 112, inst: "dizi",
    notes: 'D5 D5 E5 F#5 D5 F#5 E5 A4 | D5 D5 E5 F#5 D5 F#5 E5 A4 | D5 D5 E5 F#5 G5 F#5 E5 D5 | ' +
           'C#5 A4 B4 C#5 D5:2 D5:2' },
  { id: "clairdelune", title: "月光下", level: "basic",
    origin: "法国传统歌谣《Au clair de la lune》,18 世纪 · 传统(作者不明)",
    key: "C", base: 4, bpm: 96, inst: "ukulele",
    notes: 'C4 C4 C4 D4 | E4:2 D4:2 | C4 E4 D4 D4 | C4:4 | C4 C4 C4 D4 | E4:2 D4:2 | ' +
           'C4 E4 D4 D4 | C4:4' },
  { id: "korobeiniki", title: "卖货郎", level: "expert",
    origin: "俄罗斯传统民歌《Коробейники》,19 世纪 · 传统(作者不明)",
    key: "A", base: 4, bpm: 132, inst: "mandolin",
    notes: 'E5:0.5 B4:0.5 C5:0.5 D5:0.5 | C5:0.5 B4:0.5 A4:0.5 A4:0.5 | C5:0.5 E5:0.5 D5:0.5 C5:0.5 | ' +
           'B4:0.5 B4:0.5 C5:0.5 D5:0.5 | E5:0.5 C5:0.5 A4:0.5 A4:0.5 | D5:0.5 F5:0.5 A5:0.5 G5:0.5 | ' +
           'F5:0.5 E5:0.5 E5:0.5 C5:0.5 | E5:0.5 D5:0.5 C5:0.5 B4:0.5 | B4:0.5 C5:0.5 D5:0.5 E5:0.5 | ' +
           'C5:0.5 A4:0.5 A4:1' },
  { id: "fate", title: "命运(首句 · 四音动机)", level: "expert",
    origin: "贝多芬《第五交响曲》开头,1808 年 · Beethoven(1827 年卒)",
    key: "C", base: 4, bpm: 88, inst: "cello",
    notes: 'G4:0.5 G4:0.5 G4:0.5 D#4:3.5 | F4:0.5 F4:0.5 F4:0.5 D4:3.5 | ' +
           'G4:0.5 G4:0.5 G4:0.5 D#4:3.5 | F4:0.5 F4:0.5 F4:0.5 D4:3.5' },
  { id: "surprise", title: "惊愕(第二乐章主题)", level: "advanced",
    origin: "海顿《第 94 交响曲》第二乐章,1791 年 · Haydn(1809 年卒)",
    key: "C", base: 4, bpm: 84, inst: "epiano",
    notes: 'C4 C4 E4 E4 G4 G4 E4:2 | F4 F4 D4 D4 B3 B3 G3:2 | C4 C4 E4 E4 G4 G4 E4:2 | ' +
           'F4 F4 D4 D4 B3 B3 C4:2' },
  { id: "prelude_c", title: "巴赫 · C 大调前奏曲(前四小节)", level: "expert",
    origin: "巴赫《平均律键盘曲集》第一册第一首,1722 年 · Bach(1750 年卒)",
    key: "C", base: 4, bpm: 72, inst: "harpsichord",
    notes: 'C4:0.25 E4:0.25 G4:0.25 C5:0.25 E5:0.25 G4:0.25 C5:0.25 E5:0.25 | ' +
           'C4:0.25 D4:0.25 A4:0.25 D5:0.25 F5:0.25 A4:0.25 D5:0.25 F5:0.25 | ' +
           'B3:0.25 D4:0.25 G4:0.25 D5:0.25 F5:0.25 G4:0.25 D5:0.25 F5:0.25 | ' +
           'C4:0.25 E4:0.25 G4:0.25 C5:0.25 E5:0.25 G4:0.25 C5:0.25 E5:0.25' },

  /* ============================================================
     ③ 专家档 · 每件乐器一首「本色曲」
     ------------------------------------------------------------
     上一段(②)解决"名曲该落在哪件乐器上",这一段解决**剩下的那些乐器没有曲子**的问题:
     古琴、扬琴、吉他、琵琶、中阮、三弦、马头琴、埙、唢呐、笙、单簧管、小号、萨克斯、
     编钟、堂鼓、木鱼、三角铁、锣钹 —— 这些都是只有练习谱的(或者连练习都不够用的)。
     每一首都按这件乐器的**本门技法**写:琵琶写轮指与换把、竹笛写吐音、唢呐写喜庆锣鼓、
     编钟写踏五声、打击写复合节奏。**不标"传统曲调"** —— 它们是照本门语气写的曲子,
     标成民谣就是骗人。
     ============================================================ */
  { id: "ex2_guqin", title: "古琴 · 五声小曲", level: "expert",
    origin: "风格小曲 · 照着七弦的散音与按音写(五声, 无清角变宫)",
    key: "C", base: 2, bpm: 60, inst: "guqin",
    notes: 'A2 C3 A2 G2 | F2 G2 A2:2 | C2 D2 F2 D2 | C2:2 A2:2 | G2 A2 C3 A2 | G2 F2 G2:2 | ' +
           'F2 D2 C2 D2 | C2:4' },
  { id: "ex2_yangqin", title: "扬琴 · 轮竹与双音", level: "expert",
    origin: "风格小曲 · 分解和弦走一圈再收回来",
    key: "C", base: 4, bpm: 104, inst: "yangqin",
    notes: 'C4 E4 G4 E4 C4 E4 G4:2 | D4 F4 A4 F4 D4 F4 A4:2 | E4 G4 C5 G4 E4 G4 C5:2 | ' +
           'B3 D4 G4 D4 B3 D4 G4:2 | C4 E4 G4 C5 E5 C5 G4 E4 | D4 F4 A4 D5 F5 D5 A4 F4 | ' +
           'C4 E4 G4 C5 E5 G5 E5 C5 | C4:4' },
  { id: "ex2_guitar", title: "吉他 · 分解和弦与扫弦", level: "expert",
    origin: "风格小曲 · 四个和弦各走一遍分解, 最后收在 C",
    key: "C", base: 3, bpm: 92, inst: "guitar",
    notes: 'C3 E3 G3 C4 E4 G4 C5:2 | A2 C3 E3 A3 C4 E4 A4:2 | F2 A2 C3 F3 A3 C4 F4:2 | ' +
           'G2 B2 D3 G3 B3 D4 G4:2 | C3:0.5 E3:0.5 G3:0.5 C4:0.5 E4:0.5 G4:0.5 C5:0.5 E5:0.5 ' +
           'C5:0.5 G4:0.5 E4:0.5 C4:0.5 G3:0.5 E3:0.5 C3:2' },
  { id: "ex2_pipa", title: "琵琶 · 轮指与换把", level: "expert",
    origin: "风格小曲 · 一句轮指一句挑, 手在相把与品位之间来回",
    key: "C", base: 4, bpm: 96, inst: "pipa",
    notes: 'A3 C4 D4 E4 A3 C4 D4 E4 | D4 F4 A4 F4 D4 C4 B3:2 | A3 C4 E4 A4 E4 C4 A3:2 | ' +
           'B3 D4 E4 D4 B3 A3 B3:2 | A3:0.5 C4:0.5 E4:0.5 A4:0.5 C4:0.5 E4:0.5 A4:0.5 E4:0.5 ' +
           'C4:0.5 A3:0.5 E4:0.5 C4:0.5 A3:4' },
  { id: "ex2_ruan", title: "中阮 · 双弦滚奏", level: "expert",
    origin: "风格小曲 · 相邻两弦来回滚, 第三句才往上走",
    key: "G", base: 3, bpm: 100, inst: "ruan",
    notes: 'G3 A3 B3 D4 G4 D4 B3 A3 | G3 A3 B3 D4 E4 D4 B3 A3 | C4 D4 E4 G4 E4 D4 C4 A3 | ' +
           'G3 A3 B3 D4 G4:2 D4 B3:2 | G3:4' },
  { id: "ex2_sanxian", title: "三弦 · 弹挑与滚奏", level: "expert",
    origin: "风格小曲 · 一根弦上把位走满, 中间插一段滚奏",
    key: "G", base: 3, bpm: 108, inst: "sanxian",
    notes: 'G3 A3 B3 C4 D4 C4 B3 A3 | G3 D4 G3 D4 G3 D4 G3:2 | C4 D4 E4 D4 C4 B3 A3:2 | ' +
           'G3 A3 B3 C4 D4 E4 D4:2 | G3:4' },
  { id: "ex2_matouqin", title: "马头琴 · 长调与颤指", level: "expert",
    origin: "风格小曲 · 长音打底, 长音上带颤指, 句尾往下拖",
    key: "A", base: 4, bpm: 64, inst: "matouqin",
    notes: 'A4:3 B4:1 C5:2 A4:2 | G4:2 A4:2 C5:4 | D5:3 C5:1 A4:2 G4:2 | A4:4 A4:2 C5:2 | ' +
           'D5:2 E5:2 D5:2 C5:2 | A4:4 G4:2 A4:2 | C5:4 D5:4 | A4:8' },
  { id: "ex2_xun", title: "埙 · 远古吟唱", level: "expert",
    origin: "风格小曲 · 五声为主, 长音多, 不留棱角",
    key: "C", base: 4, bpm: 66, inst: "xun",
    notes: 'C4:2 E4:1 D4:1 G4:2 A4:2 | G4:1 A4:1 C5:2 A4:1 G4:1 E4:2 | D4:2 E4:2 G4:1 A4:1 C5:2 | ' +
           'D5:2 C5:1 A4:1 G4:2 E4:1 D4:1 | C4:4' },
  { id: "ex2_suona", title: "唢呐 · 喜庆锣鼓", level: "expert",
    origin: "风格小曲 · 号角式起句 + 花舌式快句, 大喜事的走法",
    key: "G", base: 4, bpm: 120, inst: "suona",
    notes: 'G4 A4 B4 D5 B4 A4 G4:2 | D5 E5 F#5 G5 F#5 E5 D5:2 | G5 A5 B5 A5 G5 E5 D5:2 | ' +
           'G4:0.5 A4:0.5 B4:0.5 D5:0.5 G5:2 D5 B4 | G4:4' },
  { id: "ex2_sheng", title: "笙 · 和音吹奏", level: "expert",
    origin: "风格小曲 · 一句和弦一句单音, 呼吸长一点",
    key: "C", base: 4, bpm: 72, inst: "sheng",
    notes: 'C4:2 E4:2 G4:2 C5:2 | D4:1 F4:1 A4:2 G4:1 E4:1 C4:2 | E4:2 G4:2 B4:2 D5:2 | ' +
           'C5:1 B4:1 A4:1 G4:1 F4:1 E4:1 D4:2 | C4:4' },
  { id: "ex2_clarinet", title: "单簧管 · 音阶与跳进", level: "expert",
    origin: "风格小曲 · 级进到顶再跳回来, 练的是气息与指法同步",
    key: "E", base: 4, bpm: 96, inst: "clarinet",
    notes: 'E4 F#4 G#4 A4 B4 A4 G#4:2 | F#4 G#4 A4 B4 C#5 B4 A4:2 | G#4 A4 B4 C#5 D#5:2 C#5:2 | ' +
           'B4 C#5 D#5 C#5 B4 A4 G#4:2 | E4:4' },
  { id: "ex2_trumpet", title: "小号 · 号角与分解和弦", level: "expert",
    origin: "风格小曲 · 照着铜管泛音列走, 高音区收得干净",
    key: "D", base: 4, bpm: 108, inst: "trumpet",
    notes: 'D4 F#4 A4 D5 A4 F#4 D4:2 | G4 A4 B4 D5 B4 A4 G4:2 | D5 E5 F#5 A5 F#5 E5 D5:2 | ' +
           'D4:0.5 F#4:0.5 A4:0.5 D5:0.5 F#5:0.5 A5:0.5 D5:2 | D4:4' },
  { id: "ex2_sax", title: "萨克斯 · 布鲁斯行走", level: "expert",
    origin: "风格小曲 · 降三度降七度到处露脸, 走的是十二小节的味道",
    key: "Bb", base: 4, bpm: 88, inst: "sax",
    notes: 'A#3 C4 D4 D#4 F4 D#4 D4:2 | C4 D4 D#4 F4 G4 F4 D#4:2 | F4 G4 A4 A#4 A4 G4 F4:2 | ' +
           'D#4 F4 G4 A#4 C5 A#4 A4:2 | A#3:4' },
  { id: "ex2_bianzhong", title: "编钟 · 上下行与跳进", level: "expert",
    origin: "风格小曲 · 踏着五声上下走, 句尾用一大跳收住",
    key: "C", base: 5, bpm: 76, inst: "bianzhong",
    notes: 'C5 E5 G5 C6 G5 E5 C5:2 | D5 E5 G5 A5 G5 E5 D5:2 | C5 D5 E5 G5 A5 C6 A5:2 | ' +
           'G5 A5 C6 A5 G5 E5 D5:2 | C5:4' },
  { id: "ex2_drumset", title: "堂鼓 · 复合节奏", level: "expert",
    origin: "风格小曲 · 鼓心鼓边交替, 最后一下落在大锣上",
    key: "C", base: 4, bpm: 92, inst: "drumset",
    notes: 'C4 C4 C#4:0.5 D4:0.5 C4:2 | C4 D4:0.5 D#4:0.5 C#4 C4:2 | C4 C4 C#4:0.5 D4:0.5 E4:2 | ' +
           'C4:0.5 C#4:0.5 D4:0.5 D#4:0.5 G3:4' },
  { id: "ex2_muyu", title: "木鱼 · 快速单跳", level: "expert",
    origin: "风格小曲 · 一个音上把速度稳住, 只在句尾换音色",
    key: "C", base: 4, bpm: 126, inst: "muyu",
    notes: 'C4:0.5 C4:0.5 C4:0.5 C4:0.5 C4 C4:2 | C4:0.5 C4:0.5 C#4 C4:0.5 C4:0.5 C#4:2 | ' +
           'C4:0.5 C4:0.5 C4:0.5 C4:0.5 C4 C4:2 | C4 C#4 D4 D#4 C4:4' },
  { id: "ex2_triangle", title: "三角铁 · 滚奏与重音", level: "expert",
    origin: "风格小曲 · 轻的铺底, 重的那几下不许含糊",
    key: "C", base: 4, bpm: 104, inst: "triangle",
    notes: 'C4:0.5 C4:0.5 C4 C4:2 | C4:0.5 C4:0.5 C#4 C#4:2 | C4:0.5 C4:0.5 C4 C4:2 | ' +
           'C4 C#4 D4 C4:4' },
  { id: "ex2_luo", title: "锣钹 · 开场与收尾", level: "expert",
    origin: "风格小曲 · 大锣开场、小锣接句、钹收尾, 中间不许抢",
    key: "C", base: 4, bpm: 80, inst: "luo",
    notes: 'C4:4 | D4 C4:2 D4:2 | C4:2 D4 C4:2 | C#4:4 D4:4' },
];
