/* ============================================================
   随身钢琴 · 内置乐谱
   ============================================================

   为什么是这几首:用户说「完全可以加入乐谱功能,可以内置一些乐谱」。
   **全部是公有领域作品** —— 作者逝世超过 70 年(Beethoven 1827 / Brahms 1897 /
   Foster 1864 / Pachelbel 1706),或者是作者不明的传统民谣(茉莉花、绿袖子、两只老虎、
   划船歌);《生日快乐》的旋律作于 1893 年,美国法院 2016 年已判定其版权主张无效。
   所以这些谱面可以直接随包分发,不需要任何授权。

   谱面数据是「旋律骨架」(主歌一两句,够在手机上跟着弹),不是完整编曲。
   每个音记成:  音名 + 八度[:拍数][.]
     C4        中央 C,一拍
     G4:2      两拍
     C5:0.5    半拍
     D4:1.     附点(一拍半)
     0         休止(同样可以带 :拍数)
   `|` 是分隔线,渲染成小节线,解析时忽略。小写、不加八度(如 `C`)都认,八度缺省取 4。

   2026-09-22 补:这一份曲库现在只是「默认的那一摞」—— 用户还能从「乐谱 → 导入」把自己写的
   简谱存进本机(存的是 `piano.songs.v1`,与这一份内置数据分开,内置这 12 首谁也删不掉)。
   解析与校验全在 `scoreio.js`;这个文件只放数据,不要往里塞逻辑。
   ============================================================ */
window.JH_PIANO_SCORES = [
  {
    id: 'twinkle',
    title: '小星星',
    origin: '法国童谣《Ah! vous dirai-je, maman》,约 1761 年 · 传统',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 104,
    notes: 'C4 C4 G4 G4 A4 A4 G4:2 | F4 F4 E4 E4 D4 D4 C4:2 | ' +
           'G4 G4 F4 F4 E4 E4 D4:2 | G4 G4 F4 F4 E4 E4 D4:2 | ' +
           'C4 C4 G4 G4 A4 A4 G4:2 | F4 F4 E4 E4 D4 D4 C4:2'
  },
  {
    id: 'frajacques',
    title: '两只老虎',
    origin: '法国传统轮唱《Frère Jacques》 · 传统',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 112,
    notes: 'C4 D4 E4 C4 | C4 D4 E4 C4 | E4 F4 G4:2 | E4 F4 G4:2 | ' +
           'G4 A4 G4 F4 E4 C4 | G4 A4 G4 F4 E4 C4 | C4 G3 C4:2 | C4 G3 C4:2'
  },
  {
    id: 'ode',
    title: '欢乐颂',
    origin: '贝多芬《第九交响曲》第四乐章,1824 年 · Beethoven(1827 年卒)',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 108,
    notes: 'E4 E4 F4 G4 | G4 F4 E4 D4 | C4 C4 D4 E4 | E4:1. D4:0.5 D4:2 | ' +
           'E4 E4 F4 G4 | G4 F4 E4 D4 | C4 C4 D4 E4 | D4:1. C4:0.5 C4:2'
  },
  {
    id: 'jingle',
    title: '铃儿响叮当',
    origin: 'James Lord Pierpont,1857 年 · Pierpont(1893 年卒)',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 120,
    notes: 'E4 E4 E4:2 | E4 E4 E4:2 | E4 G4 C4 D4 E4:4 | ' +
           'F4 F4 F4 F4 | F4 E4 E4 E4 | E4 D4 D4 E4 | D4:2 G4:2'
  },
  {
    id: 'birthday',
    title: '生日快乐',
    origin: 'Patty 与 Mildred Hill,1893 年(美国法院 2016 年判定其版权主张无效)',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 108,
    notes: 'C4:0.5 C4:0.5 D4 C4 F4 E4:2 | ' +
           'C4:0.5 C4:0.5 D4 C4 G4 F4:2 | ' +
           'C4:0.5 C4:0.5 C5 A4 F4 E4 D4 | ' +
           'Bb4:0.5 Bb4:0.5 A4 F4 G4 F4:2'
  },
  {
    id: 'jasmine',
    title: '茉莉花',
    origin: '江苏民歌,清乾隆年间已见于《缀白裘》 · 传统',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 96,
    notes: 'E4 E4 G4 A4 C5:2 | C5 A4 G4 A4 G4 | E4 G4 A4 G4 E4 D4 | ' +
           'E4 G4 E4 D4 C4:2 | E4 E4 G4 A4 C5:2 | C5 A4 G4 A4 G4 | E4 G4 A4 G4 E4 D4 | E4 D4 C4:2'
  },
  {
    id: 'farewell',
    title: '送别',
    origin: '曲:William S. Hays《Dreaming of Home and Mother》1851 年;词:李叔同 1915 年',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 84,
    notes: 'G4 E4 G4:2 | A4 G4 E4 D4:2 | G4 E4 G4:2 | A4 G4 E4 D4:2 | ' +
           'G4 G4 C5:2 | B4 A4 G4:2 | E4 G4 A4:2 | G4 E4 D4:2'
  },
  {
    id: 'elise',
    title: '致爱丽丝(主题)',
    origin: '贝多芬,1810 年 · Beethoven(1827 年卒)',
    license: 'public-domain',
    key: 'A', base: 4, bpm: 120,
    notes: 'E5 D#5 E5 D#5 E5 B4 D5 C5 | A4:2 C4 E4 A4 | B4:2 E4 G#4 B4 | C5:2 E4 E5 D#5 | ' +
           'E5 D#5 E5 B4 D5 C5 | A4:2 C4 E4 A4 | B4:2 E4 C5 B4 | A4:2'
  },
  {
    id: 'greensleeves',
    title: '绿袖子',
    origin: '英格兰传统曲调,16 世纪 · 传统',
    license: 'public-domain',
    key: 'A', base: 4, bpm: 100,
    notes: 'A4 C5 D5 E5:1. F5:0.5 | E5 D5:2 B4 G4:1. A4:0.5 | B4 C5:2 A4 A4:1. G#4:0.5 | ' +
           'A4 B4:2 G4 G4:1. A4:0.5 | B4 C5:2 A4 A4:1. G#4:0.5 | A4 B4:2 C5 B4:1. A4:0.5 | ' +
           'G#4 A4:4'
  },
  {
    id: 'lullaby',
    title: '摇篮曲',
    origin: '勃拉姆斯,1868 年 · Brahms(1897 年卒)',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 76,
    notes: 'E4 E4 G4:2 | E4 E4 G4:2 | E4 G4 C5:2 | B4:1. A4:0.5 A4:2 | ' +
           'G4 E4 G4:2 | G4 E4 G4:2 | G4 E4 G4:2 | C5:1. B4:0.5 A4:2'
  },
  {
    id: 'susanna',
    title: '苏珊娜',
    origin: 'Stephen Foster,1848 年 · Foster(1864 年卒)',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 112,
    notes: 'C4 C4 E4 G4:2 | G4:1. F4:0.5 E4 C4 | C4 C4 E4 G4:2 | G4:1. F4:0.5 E4 C4 | ' +
           'C4 C4 E4 G4 | G4 F4 E4 D4 | D4 D4 E4 D4:2 | D4:2'
  },
  {
    id: 'rowboat',
    title: '划船歌',
    origin: '美国传统曲调,1852 年 · 传统',
    license: 'public-domain',
    key: 'C', base: 4, bpm: 92,
    notes: 'C4:1. C4:0.5 C4:1. D4:0.5 E4 | E4:1. D4:0.5 E4:1. F4:0.5 G4:2 | ' +
           'C5:0.5 C5:0.5 C5:0.5 G4:0.5 G4:0.5 G4:0.5 E4:0.5 E4:0.5 E4:0.5 C4:0.5 C4:0.5 C4:0.5 | ' +
           'G4:1. F4:0.5 E4:1. D4:0.5 C4:2'
  },
  {
    id: 'canon',
    title: '卡农(低音线)',
    origin: '帕赫贝尔,约 1680 年 · Pachelbel(1706 年卒)',
    license: 'public-domain',
    key: 'C', base: 3, bpm: 88,
    notes: 'C3:2 G3:2 A3:2 E3:2 | F3:2 C3:2 F3:2 G3:2 | ' +
           'C3:2 G3:2 A3:2 E3:2 | F3:2 C3:2 F3:2 G3:2'
  }
];
