/* ============================================================
   乐谱播放 · 页面逻辑
   ------------------------------------------------------------
   一句话:把一份**多声部简谱**交给几件乐器一起奏出来。

   三件事是自己写的,其余全部复用「乐器盒」那两份文件:
     ① 多声部:在现有简谱格式上**只加一层** `@part 乐器 | 声部名`。
        做法是先把整段按 @part 切成若干单声部文本(头部一起带上),
        再逐段交给 IO.parseText() / IO.buildLibrary() —— scoreio.js 一个字都没动;
     ② 时间表:句读(乐句在哪断、各族乐器怎么收尾、力度怎么跟着句子走)用的就是
        乐器盒那三个函数 phraseEnds() / articOf() / planSong(),逐条照抄,味道才一样。
        多声部多出来的一件事是**时钟**:几个声部各自的句尾留白不一样长(弹拨 0.6、
        吹管 1.0),各排各的就会越走越散 —— 所以时间尺只有一把,由**第一个声部(主旋律)**
        的 planSong() 定,别的声部按"自己第几拍"落在这把尺上;各声部自己的收尾仍按各自的乐器走;
     ③ 可视化:每个声部一条时间轴,正在响的那一段亮起来。整页不做动画,只改那一小段的颜色。
   导出音频用 OfflineAudioContext:临时把 window.AudioContext 换成一个"交给我那台离线机器"
   的壳,再加载**第二份 audio.js**(新闭包 = 新引擎),让它离线奏完一整遍,存成 WAV。
   ============================================================ */
(function () {
  'use strict';

  var IO = window.JH_PIANO_IO;
  var ARR = window.JH_BOX_ARRANGEMENTS || [];
  /* 页面活着的时候认这一份引擎。导出音频时会临时再加载一份(见 exportWav),那时
     window.JH_BOX_AUDIO 会被换掉 —— 所以这里先把它攥住,别每次去读 window 上那个。 */
  var A = window.JH_BOX_AUDIO;
  /* 自己这个文件住在哪儿。导出音频要再加载一份 audio.js,写死 "audio.js" 只在两者同目录时成立,
     照 app.js 自己的地址推一个前缀,放在哪个目录下都对 */
  var BASE = (function () {
    var s = document.currentScript, all, i;
    if (!s) {
      all = document.getElementsByTagName('script');
      for (i = all.length - 1; i >= 0; i--) if (/app\.js(\?|$)/.test(String(all[i].src))) { s = all[i]; break; }
    }
    return (s && s.src) ? String(s.src).replace(/[^/]*$/, '') : '';
  })();

  var KEY = 'piece';         /* 存档:当前这一份谱子与各声部的音量/静音 */
  var PX_PER_BEAT = 32;      /* 时间轴上一个四分音符多宽 */
  var MAX_WAV = 40 * 1024 * 1024;
  var WAV_SR = 44100;
  var DEFAULT_GAIN_OTHERS = 0.8;   /* 主旋律之外的声部默认轻一点:伴奏不该盖过旋律 */

  var state = {
    text: '',          /* 当前谱子的原文(多声部文本) */
    piece: null,       /* 排好的曲子:{title,bpm,key,base,origin,parts:[…],total} */
    speed: 1,
    master: 0.9, wet: 0.18, click: false, loop: false,
    playing: false, exporting: false,
    t0: 0, endAt: 0, raf: 0, position: 0, seeking: false,
    voices: [], clicks: [],
    curFam: 0, instFor: 0,
    sheets: [],
    volTimer: 0, spdTimer: 0, refillT: 0
  };

  function $(id) { return document.getElementById(id); }
  function jh() { return window.JH || null; }
  /** 声音引擎(没起来就别装死 —— 说一句人话) */
  function AE() {
    if (!A) { say('声音引擎没起来,把插件页关掉重新进一次'); return null; }
    return A;
  }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function say(m) {
    if (!jh()) { console.log(m); return; }
    var p = JH.toast(m);
    /* 连提示都发不出去的时候,没有更下面一层可以说话了(也不许抛出去把这一下打断) */
    if (p && p.catch) p.catch(function () { });
  }
  function tip(m) { $('tip').textContent = m || ''; }
  function fail(e) { say((e && e.message) || '这一步没做成'); }
  /** 桥上每一次调用都要接 catch,把 e.message 说出来(§3.14) */
  function jcall(p) {
    if (p && p.catch) return p.catch(function (e) { fail(e); });
    return p;
  }
  function ping() { if (jh() && JH.vibrate) jcall(JH.vibrate(12)); }

  /* ============================================================
     一、句读 —— 与「乐器盒」逐字相同的那三条判断
     ============================================================ */
  function noteBeats(n) { return Math.max(0.05, n.beats || 1); }
  function beatSec() { return 60 / ((state.piece && state.piece.bpm) || 100) / state.speed; }

  /** 乐句在哪断:休止 / 拖到两拍以上 / 一拍半又正好换小节。推得准不准,时间轴上一眼能看见 */
  function phraseEnds(notes, bars) {
    var set = {}, i, n = notes.length, out = [];
    for (i = 0; i < bars.length; i++) set[bars[i]] = 1;
    for (i = 0; i < n; i++) {
      var b = notes[i].rest ? 0 : noteBeats(notes[i]), why = '';
      if (i === n - 1) why = 'last';
      else if (!notes[i].rest) {
        if (notes[i + 1] && notes[i + 1].rest) why = 'rest';
        else if (b >= 2) why = 'long';
        else if (b >= 1.5 && set[i + 1]) why = 'bar';
      }
      out.push(why);
    }
    return out;
  }

  /** 每一族的"断开方式"。换弓是手上的事、换气是身体的事、弦的余韵是物理的事,尺度不一样 */
  function articOf(I) {
    var k = (I.synth && I.synth.kind) || 'add';
    var ph = clamp(beatSec() * 0.5, 0.16, 0.45);
    if (k === 'ks') return { inner: 0.01, phrase: ph * 0.6, holdEnd: 0.92, ring: true };
    if (k === 'strike') return { inner: 0.05, phrase: ph * 0.72, holdEnd: 0.94, ring: true };
    if (k === 'drum') return { inner: 0, phrase: 0, holdEnd: 1, ring: true };
    return { inner: 0.07, phrase: ph, holdEnd: 0.86, ring: false };
  }

  /** 把一个声部排成一张时间表 —— 与乐器盒的 planSong 同一套规矩(句尾留白是真花时间、
   *  同句内弹拨不掐、力度跟着句子走),只是这里允许把时间尺换成外面给的那把 */
  function planSong(notes, bars, I, clock) {
    var ends = phraseEnds(notes, bars), art = articOf(I), beat = beatSec();
    var steps = [], t = 0, i, n = notes.length;
    for (i = 0; i < n; i++) {
      var nn = notes[i], base = noteBeats(nn) * beat;
      var why = ends[i], isEnd = !!why;
      var tail = (isEnd && why !== 'rest') ? art.phrase : 0;
      var hold = null;
      if (isEnd) hold = base * art.holdEnd;
      else if (!art.ring) hold = Math.max(0.05, base - art.inner);
      if (i === n - 1) tail = (why === 'rest' ? 0 : art.phrase) + 0.5;
      steps.push({ at: clock ? clock(i, t) : t, rest: !!nn.rest, hold: hold, base: base,
        vel: isEnd ? 0.78 : (i === 0 || ends[i - 1] ? 0.92 : 0.86) });
      t += base + tail;
    }
    return { steps: steps, total: t };
  }

  /* ============================================================
     二、多声部文本:切分、查乐器、解析
     ============================================================ */
  /** 按 `@part …` 把整段切成「头部 + 若干声部」 */
  function splitParts(text) {
    var lines = String(text == null ? '' : text).replace(/\r\n?/g, '\n').split('\n');
    var head = [], parts = [], cur = null, i;
    for (i = 0; i < lines.length; i++) {
      var m = /^\s*@part\b\s*(.*)$/.exec(lines[i]);
      if (m) { cur = { decl: m[1], body: [] }; parts.push(cur); }
      else if (cur) cur.body.push(lines[i]);
      else head.push(lines[i]);
    }
    return { head: head.join('\n'), parts: parts };
  }

  function instList() { return (A && A.instruments) || []; }

  /** 乐器名或 id → 乐器对象(名字优先,再按 id 不分大小写) */
  function findInst(q) {
    q = String(q == null ? '' : q).trim();
    if (!q) return null;
    var list = instList(), i, low = q.toLowerCase();
    for (i = 0; i < list.length; i++) if (list[i].name === q) return list[i];
    for (i = 0; i < list.length; i++) if (String(list[i].id).toLowerCase() === low) return list[i];
    return null;
  }

  /**
   * 一段多声部文本 → 若干声部。
   * → {ok:true, title, bpm, key, base, origin, parts:[{name,inst,notes,bars,gain,…}]}
   * → {ok:false, error:{message, hint, which}}
   */
  function parsePiece(text) {
    var sp = splitParts(text);
    var segs;
    if (sp.parts.length) segs = sp.parts;
    else segs = [{ decl: '', body: String(text).replace(/\r\n?/g, '\n').split('\n') }];
    var parts = [], meta = null, i;
    for (i = 0; i < segs.length; i++) {
      var seg = segs[i];
      var body = sp.parts.length ? (sp.head + '\n' + seg.body.join('\n')) : seg.body.join('\n');
      var r = IO.parseText(body);
      if (!r.ok) {
        return { ok: false, error: { message: sp.parts.length > 1
          ? '第 ' + (i + 1) + ' 个声部读不出来:' + r.error.message
          : r.error.message, hint: r.error.hint, which: i + 1 } };
      }
      var song = r.songs[0];
      if (r.songs.length > 1) return { ok: false, error: {
        message: '这段内容有多首曲子，请每次导入一首', hint: '同一首曲子的多个声部用 @part 分开', which: i + 1 } };
      var lib = IO.buildLibrary([song], []);
      var it = lib.items && lib.items[0];
      if (!it || it.error || !it.notes || !it.notes.length) {
        return { ok: false, error: { message: '第 ' + (i + 1) + ' 个声部一个音都没读出来。'
          + ((it && it.error && it.error.message) || ''), hint: '每个 @part 下面至少写几个音', which: i + 1 } };
      }
      var inst = null, name = '';
      if (sp.parts.length) {
        var decl = String(seg.decl || '');
        var cut = decl.indexOf('|');
        var iname = (cut >= 0 ? decl.slice(0, cut) : decl).trim();
        name = (cut >= 0 ? decl.slice(cut + 1) : '').trim();
        if (iname) {
          inst = findInst(iname);
          if (!inst) {
            return { ok: false, error: {
              message: '没见过「' + iname.slice(0, 12) + '」这件乐器',
              hint: '点声部旁的乐器名查看可选乐器,写中文名字或英文 id 都行', which: i + 1 } };
          }
        }
      }
      if (!inst) inst = instList()[0] || null;
      if (!inst) return { ok: false, error: { message: '读不到乐器表(声音引擎没起来)', hint: '把插件页关掉重进一次' } };
      if (!name) name = (sp.parts.length ? inst.name : '主旋律');
      if (!meta) meta = { title: song.title || '未命名', key: song.key || 'C',
        base: typeof song.base === 'number' ? song.base : 4,
        bpm: song.bpm || 100, origin: song.origin || '' };
      var out = 0, j;
      for (j = 0; j < it.notes.length; j++) {
        if (!it.notes[j].rest && (it.notes[j].midi < 21 || it.notes[j].midi > 108)) out++;
      }
      parts.push({ name: name, inst: inst, notes: it.notes, bars: it.bars || [],
        song: song, rangeOut: out, gain: 1, mute: false, solo: false, steps: [], blks: [], cur: -1, ui: null });
    }
    if (sp.parts.length) { /* 曲名以头部 @title 为准,已经在 song 里带过来了 */ }
    if (!parts.length) return { ok: false, error: { message: '这段文本里一个音都没有', hint: '至少写几个音:简谱 1 2 3 或音名 C4 D4 E4' } };
    parts.forEach(function (p, k) { if (k > 0 && p.gain === 1) p.gain = DEFAULT_GAIN_OTHERS; });
    meta.parts = parts;
    return { ok: true, meta: meta };
  }

  /* ============================================================
     三、排音:一把时间尺,几个声部按拍落在上面
     ============================================================ */
  function planPiece() {
    var p = state.piece;
    if (!p) return;
    var beat = beatSec(), lead = p.parts[0], i;
    /* 时间尺 = 主旋律自己的 planSong()。句尾留白、力度、曲终那半秒都在里面 */
    var pl = planSong(lead.notes, lead.bars, lead.inst);
    var lb = [], acc = 0;
    for (i = 0; i < lead.notes.length; i++) { lb.push(acc); acc += noteBeats(lead.notes[i]); }

    /** 第 b 拍落在第几秒(主旋律那把尺上的查询;二分找包含它的那个音) */
    function whenOf(b) {
      if (!lb.length) return 0;
      var k = 0, lo = 0, hi = lb.length - 1;
      while (lo <= hi) {
        var mid = (lo + hi) >> 1;
        if (lb[mid] <= b + 1e-9) { k = mid; lo = mid + 1; } else hi = mid - 1;
      }
      return pl.steps[k].at + Math.max(0, b - lb[k]) * beat;
    }

    var total = pl.total;
    p.parts.forEach(function (pt, pi) {
      var art = articOf(pt.inst);
      var ends = phraseEnds(pt.notes, pt.bars);
      var steps = [], b = 0;
      for (i = 0; i < pt.notes.length; i++) {
        var nn = pt.notes[i], nb = noteBeats(nn), base = nb * beat;
        var st;
        if (pi === 0) {
          st = { at: pl.steps[i].at, hold: pl.steps[i].hold, vel: pl.steps[i].vel, base: base };
        } else {
          var why = ends[i], isEnd = !!why;
          var hold = null;
          if (!nn.rest) {
            if (isEnd) hold = base * art.holdEnd;
            else if (!art.ring) hold = Math.max(0.05, base - art.inner);
          }
          st = { at: whenOf(b), hold: hold, base: base,
            vel: isEnd ? 0.78 : (i === 0 || ends[i - 1] ? 0.92 : 0.86) };
        }
        st.rest = !!nn.rest;
        st.nb = nb;
        steps.push(st);
        b += nb;
      }
      pt.steps = steps;
      pt.beats = b;
      pt.leadBeats = lb.length ? (lb[lb.length - 1] + noteBeats(lead.notes[lead.notes.length - 1])) : 0;
      var last = steps.length ? steps[steps.length - 1] : null;
      pt.total = (pi === 0) ? pl.total
        : (last ? last.at + last.base : 0) + art.phrase + 0.5;
      if (pt.total > total) total = pt.total;
      pt.cur = -1;
    });
    p.total = total;
    p.beat = beat;
    var shortest = 1;
    p.parts.forEach(function (pt) { pt.notes.forEach(function (nn) { shortest = Math.min(shortest, noteBeats(nn)); }); });
    p.pps = Math.max(PX_PER_BEAT, 20 / shortest) / beat;
    planSeq++;
    warmUp();
  }

  /* ============================================================
     开演前把拨弦缓冲算出来
     ------------------------------------------------------------
     拨弦声是按物理弦模型现算缓冲的,一条 3 秒的弦要跑十几万个采样 —— 一件乐器几毫秒,
     一首曲子几十上百条。这活儿从前全挤在**开演那一瞬间**:慢手机上主线程被堵住,
     该响的音迟到、音频欠载,听感就是一串"沙拉沙拉";更早一版还表现为"开头一句句不响"。
     治法:选好谱子之后、还没点开奏的这段时间,分片把它算完(每片 12ms,不挡界面)。
     于是现场那一侧不再有人生成缓冲 —— 点开奏就是立刻出声。
     算不完也不影响用:没算到的音退回"现算现响",只是老样子。
     ============================================================ */
  var planSeq = 0, warmedSeq = -1, warmedSpeed = 0, warmT = 0;
  function warmUp() {
    var p = state.piece;
    if (!p || !A || !A.warm || state.playing) return;
    if (warmedSeq === planSeq && warmedSpeed === state.speed) return;
    warmedSeq = planSeq; warmedSpeed = state.speed;
    if (warmT) { clearTimeout(warmT); warmT = 0; }
    var jobs = [], i;
    p.parts.forEach(function (pt) {
      if (!heard(pt)) return;
      for (i = 0; i < pt.notes.length; i++) {
        var nn = pt.notes[i], st = pt.steps[i];
        if (nn.rest) continue;
        jobs.push([pt.inst, nn.midi, st.hold, clamp(st.vel, 0.05, 1)]);
      }
    });
    if (!jobs.length) return;
    var idx = 0;
    (function slice() {
      warmT = 0;
      if (state.piece !== p || state.playing) { warmedSeq = -1; return; }
      var t0 = Date.now();
      while (idx < jobs.length && Date.now() - t0 < 12) {
        var j = jobs[idx++];
        try { A.warm(j[0], j[1], j[2], j[3], null); } catch (e) { return; }
      }
      if (idx < jobs.length) warmT = setTimeout(slice, 0);
    })();
  }

  /* 手写多声部谱最常见的毛病:几个声部拍数对不齐。不拦着播,但要人话说清,
     短了的声部给一键「补齐休止」—— 对齐之后各声部才真的同时收住。 */
  function beatWarn() {
    var elw = $('beatWarn');
    if (!elw) return;
    var p = state.piece;
    if (!p || p.parts.length < 2) { elw.hidden = true; return; }
    var lead = p.parts[0].beats, worst = null, i;
    for (i = 1; i < p.parts.length; i++) {
      var dd = lead - p.parts[i].beats;
      if (Math.abs(dd) >= 0.49 && (!worst || Math.abs(dd) > Math.abs(worst.d))) worst = { i: i, d: dd };
    }
    if (!worst) { elw.hidden = true; return; }
    var pt = p.parts[worst.i], n = Math.round(Math.abs(worst.d) * 10) / 10;
    elw.hidden = false;
    $('beatWarnTxt').textContent = worst.d > 0
      ? '「' + pt.name + '」比主旋律短 ' + n + ' 拍,后面它先收声'
      : '「' + pt.name + '」比主旋律长 ' + n + ' 拍,主旋律奏完了它还会多奏一段';
    var bp = $('beatWarnPad');
    bp.hidden = worst.d <= 0;            /* 长的那段不补 —— 补休止只对短声部有意义 */
    bp.onclick = function () {
      if (state.exporting) { say('正在导出音频，完成后可以修改谱子'); return; }
      var a = anchor();
      pt.notes.push({ midi: -1, beats: worst.d, rest: true });
      planPiece(); restoreAnchor(a); renderHead(); renderParts(); renderAdvParts();
      if (state.playing) schedule(state.position);
      updatePosition(); saveNow(); beatWarn();
      say('给「' + pt.name + '」末尾补了 ' + n + ' 拍休止');
    };
  }

  /* ============================================================
     四、播放
     ============================================================ */
  function anySolo() {
    var p = state.piece;
    if (!p) return false;
    return p.parts.some(function (pt) { return pt.solo && !pt.mute; });
  }
  /** 这一声部这一遍出不出声 */
  function heard(pt) {
    if (pt.mute || !(pt.gain > 0.02)) return false;
    return anySolo() ? pt.solo : true;
  }

  function clearVoices() {
    state.voices.forEach(function (v) { try { v.stop(); } catch (e) { } });
    state.clicks.forEach(function (c) { try { c.stop(); } catch (e) { } });
    state.voices = []; state.clicks = [];
  }

  /* 力度表达乐句，声部音量只走增益轨；现场与导出使用同一条通路。 */
  function partGain(pt) { return heard(pt) ? clamp(pt.gain, 0, 1) : 0; }
  function partBusGain(pt) { return partGain(pt); }
  function partBus(pt) {
    if (!pt.bus && A.bus) { try { pt.bus = A.bus(partBusGain(pt)); } catch (e) { pt.bus = null; } }
    return pt.bus;
  }
  /** 静音、独奏、推子只改增益，不重新起音。 */
  function partVolTo(pt, v) {
    var b = partBus(pt), g = clamp(v, 0, 4);
    if (b) { try { b.gain.setTargetAtTime(g, A.now(), 0.05); } catch (e) { b.gain.value = g; } }
  }
  function rampAllParts() {
    var p = state.piece;
    if (!p) return;
    p.parts.forEach(function (pt) { partVolTo(pt, partGain(pt)); });
  }

  var HORIZON = 0.8;   /* 留够调度余量，同时避免一次构造整段多声部节点。 */

  function position() {
    var p = state.piece;
    return p ? clamp(state.playing ? A.now() - state.t0 : state.position, 0, p.total) : 0;
  }
  function anchor() {
    var p = state.piece, t = position(), steps = p && p.parts[0].steps, i = 0;
    if (!steps || !steps.length) return null;
    while (i + 1 < steps.length && steps[i + 1].at <= t) i++;
    var end = i + 1 < steps.length ? steps[i + 1].at : p.total;
    return { i: i, f: clamp((t - steps[i].at) / Math.max(0.001, end - steps[i].at), 0, 1) };
  }
  function restoreAnchor(a) {
    if (!a || !state.piece) return;
    var p = state.piece, steps = p.parts[0].steps, st = steps[a.i];
    if (!st) return;
    state.position = st.at + a.f * ((a.i + 1 < steps.length ? steps[a.i + 1].at : p.total) - st.at);
  }

  function schedule(fromSec) {
    var p = state.piece, beat = p.beat;
    if (!p.parts.some(heard)) return 0;
    fromSec = clamp(fromSec, 0, p.total);
    var t0 = A.now() + 0.08;
    state.t0 = t0 - fromSec;
    state.endAt = state.t0 + p.total;
    clearVoices();
    /* 多声部整首一口气排进音频钟,慢手机上开头那句会整个滑进过去 ——
       与乐器盒同一个病灶,同一条治法:游标 + 每 120ms 只补一小班 */
    p.parts.forEach(function (pt) {
      pt.si = 0;
      while (pt.si < pt.steps.length && pt.steps[pt.si].at + pt.steps[pt.si].base <= fromSec + 0.02) pt.si++;
      partBus(pt);
    });
    state.clickI = Math.ceil(fromSec / beat - 1e-6);
    refill();
    if (state.refillT) clearInterval(state.refillT);
    state.refillT = setInterval(function () { if (state.playing) refill(); }, 120);
    var n = 0;
    p.parts.forEach(function (pt) { if (heard(pt)) n++; });
    return n;
  }

  /* 把"接下来 HORIZON 秒内该响的音与打拍"排进音频钟,排一颗走一颗 */
  function refill() {
    var p = state.piece;
    if (!p) return;
    var lim = A.now() + HORIZON;
    state.voices = state.voices.filter(function (v) { return !v.alive || v.alive(); });
    p.parts.forEach(function (pt) {
      var dst = partBus(pt);
      while (pt.si < pt.steps.length) {
        var i = pt.si, nn = pt.notes[i], st = pt.steps[i];
        var when = state.t0 + st.at;
        if (when > lim) break;
        pt.si++;
        if (nn.rest) continue;
        var now0 = A.now();
        /* 卡顿后已经过去的音不挤成一团；从音符中途续播只奏剩余时值。 */
        if (when + st.base <= now0) continue;
        var hold = st.hold == null ? null : Math.max(0.025, st.hold - Math.max(0, now0 - when));
        if (when < now0 + 0.02) when = now0 + 0.02;
        var v = A.noteOn(pt.inst, nn.midi, clamp(st.vel, 0.05, 1), when, hold, null, dst);
        if (v) state.voices.push(v);
      }
    });
    if (state.click && A.tick) {
      for (;;) {
        var t = state.clickI * p.beat;
        if (t >= p.total - 1e-6 || state.t0 + t > lim) break;
        var c = state.t0 + t >= A.now() ? A.tick(state.clickI % 4 === 0, state.t0 + t) : null;
        if (c) state.clicks.push(c);
        state.clickI++;
      }
    }
  }

  function play() {
    if (!state.playing) {
      if (!state.piece) { say('先点「选曲」挑一首，或者「导入」粘一段谱子'); return; }
      if (state.exporting) { say('正在录音频,等它录完'); return; }
      if (!AE()) return;
      A.unlock();
      if (state.position >= state.piece.total - 0.02) state.position = 0;
      if (!schedule(state.position)) { say('所有声部都被静音了'); return; }
      state.playing = true;
      setPlayBtn();
      step();
      return;
    }
    pause();
  }

  /** 打拍开关改了才重排(节拍是排进音频钟的)—— 音量/静音/独奏都走增益轨斜坡,不惊动在响的音 */
  function reseek() {
    state.clicks.forEach(function (c) { try { c.stop(); } catch (e) { } });
    state.clicks = [];
    if (state.piece) state.clickI = Math.ceil(position() / state.piece.beat - 1e-6);
    if (state.playing) refill();
  }

  function pause() {
    var t = position();
    stop(true);
    state.position = t;
    setPlayBtn(); updatePosition();
  }

  function stop(silent) {
    state.playing = false;
    if (state.refillT) { clearInterval(state.refillT); state.refillT = 0; }
    if (state.raf) { cancelAnimationFrame(state.raf); state.raf = 0; }
    clearVoices();
    state.position = 0;
    if (!silent && A) A.stopAll();
    clearCur();
    setPlayBtn();
    updatePosition();
  }

  function setPlayBtn() {
    var b = $('btnPlay');
    b.textContent = state.playing ? '暂停' : (state.position > 0 ? '继续播放' : '播放');
    b.setAttribute('aria-pressed', String(state.playing));
  }

  function clockText(t) {
    t = Math.max(0, Math.floor(t));
    return Math.floor(t / 60) + ':' + (t % 60 < 10 ? '0' : '') + t % 60;
  }
  function updatePosition() {
    var p = state.piece, t = position(), seek = $('seek');
    if (!seek || state.seeking) return;
    seek.max = p ? p.total : 1; seek.value = t;
    seek.style.setProperty('--p', p ? 100 * t / Math.max(0.001, p.total) : 0);
    $('timeTxt').textContent = clockText(t) + ' / ' + clockText(p ? p.total : 0);
  }

  /* ---------- 一遍奏完 ---------- */
  function step() {
    if (!state.playing) return;
    var p = state.piece;
    if (!p) { stop(); return; }
    var el2 = A.now() - state.t0;
    p.parts.forEach(function (pt) {
      var k = pt.cur, i = k < 0 ? 0 : k;
      while (i + 1 < pt.steps.length && pt.steps[i + 1].at <= el2) i++;
      if (i !== k) { paint(pt, k, i); pt.cur = i; }
    });
    follow(el2);
    updatePosition();
    if (A.now() >= state.endAt) {
      if (state.loop) {
        clearCur(); state.position = 0;
        if (!schedule(0)) { stop(); say('所有声部都被静音了'); return; }
        state.raf = requestAnimationFrame(step); return;
      }
      stop();
      if (jh() && JH.vibrate) jcall(JH.vibrate(14));
      say('奏完了');
      return;
    }
    state.raf = requestAnimationFrame(step);
  }

  function paint(pt, from, to) {
    if (!pt.blks.length) return;
    if (from >= 0 && pt.blks[from]) pt.blks[from].className = pt.blks[from].className.replace(' cur', '');
    if (to >= 0 && pt.blks[to]) pt.blks[to].className += ' cur';
  }
  function clearCur() {
    var p = state.piece;
    if (!p) return;
    p.parts.forEach(function (pt) {
      if (pt.cur >= 0 && pt.blks[pt.cur]) pt.blks[pt.cur].className = pt.blks[pt.cur].className.replace(' cur', '');
      pt.cur = -1;
    });
  }

  /* ---------- 时间轴跟着走(几条轨一起滚,横向才对得齐) ---------- */
  var lastMirror = 0;
  function follow(el2) {
    var p = state.piece;
    if (!p || !p.parts.length) return;
    var lane = p.parts[0].ui && p.parts[0].ui.lane;
    if (!lane) return;
    var max = lane.scrollWidth - lane.clientWidth;
    if (max <= 0) return;
    var want = clamp(el2 * p.pps - lane.clientWidth * 0.35, 0, max);
    if (Math.abs(want - lane.scrollLeft) < 0.5) return;
    lane.scrollLeft = want;
    mirror(lane, want);
  }
  function mirror(src, x) {
    lastMirror = Date.now();
    state.piece.parts.forEach(function (pt) {
      if (pt.ui && pt.ui.lane !== src) pt.ui.lane.scrollLeft = x;
    });
  }

  /* ============================================================
     五、界面:曲目卡 / 声部列表 + 时间轴
     ============================================================ */
  function fmtdur(sec) {
    sec = Math.max(1, Math.round(sec));
    if (sec < 60) return '约 ' + sec + ' 秒';
    return '约 ' + Math.floor(sec / 60) + ' 分 ' + (sec % 60) + ' 秒';
  }
  function renderHead() {
    var p = state.piece;
    if (!p) {
      $('songTitle').textContent = '还没有谱子';
      $('songMeta').textContent = '点「选曲」挑一首，或者导入一段多声部简谱';
      return;
    }
    $('songTitle').textContent = p.title;
    $('songMeta').textContent = p.parts.length + ' 个声部 · ' + fmtdur(p.total) + ' · '
      + Math.round(p.bpm * state.speed) + ' BPM';
  }

  function renderParts() {
    var box = $('parts');
    while (box.firstChild) box.removeChild(box.firstChild);
    var p = state.piece;
    if (!p) {
      box.appendChild(el('div', 'empty', '还没有谱子。挑一首或粘一段进来,几个声部就会各占一行。'));
      return;
    }
    p.parts.forEach(function (pt, i) {
      var root = el('div', 'part');
      var prow = el('div', 'prow');
      var nm = el('button', 'pname');
      nm.appendChild(el('span', 'parttitle', pt.name));
      nm.appendChild(el('span', 'partinst', pt.inst.name + ' ›'));
      nm.setAttribute('aria-label', pt.name + '，当前' + pt.inst.name + '，换乐器');
      nm.onclick = function () {
        state.instFor = i; state.curFam = Math.max(0, A.families.indexOf(pt.inst.fam));
        renderFams(); renderInst(); openSheet('sheetInst');
      };
      var vol = document.createElement('input');
      vol.type = 'range'; vol.className = 'pvol';
      vol.min = 0; vol.max = 100; vol.step = 5; vol.value = Math.round(pt.gain * 100);
      vol.setAttribute('aria-label', pt.name + ' 的音量');
      vol.style.setProperty('--p', vol.value);
      var bm = el('button', 'mini', '静音');
      bm.setAttribute('aria-label', '静音:' + pt.name);
      var bs = el('button', 'mini', '独奏');
      bs.setAttribute('aria-label', '独奏:' + pt.name);
      prow.appendChild(nm); prow.appendChild(bm); prow.appendChild(bs);
      var lane = el('div', 'lane');
      lane.setAttribute('data-lane', i);
      root.appendChild(prow); root.appendChild(lane);
      box.appendChild(root);
      pt.ui = { root: root, name: nm, vol: vol, mute: bm, solo: bs, lane: lane, lini: null };
      pt.blks = [];

      vol.addEventListener('input', function () {
        pt.gain = vol.value / 100;
        vol.style.setProperty('--p', vol.value);
        root.className = 'part' + (heard(pt) ? '' : ' mute');
        /* 音量只在那条声部的增益轨上走斜坡 —— 不重排,在响的音不会被重新起音 */
        partVolTo(pt, partGain(pt));
        clearTimeout(state.volTimer);
        state.volTimer = setTimeout(saveNow, 260);
      });
      bm.addEventListener('click', function () { setFlag(pt, 'mute'); });
      bs.addEventListener('click', function () { setFlag(pt, 'solo'); });
      lane.addEventListener('scroll', function () {
        if (Date.now() - lastMirror < 80) return;
        mirror(lane, lane.scrollLeft);
      });
    });
    syncFlags();
    renderRoll();
  }

  function setFlag(pt, which) {
    pt[which] = !pt[which];
    syncFlags();
    rampAllParts();
    saveNow();
    ping();
  }
  function syncFlags() {
    var p = state.piece;
    if (!p) return;
    p.parts.forEach(function (pt) {
      if (!pt.ui) return;
      pt.ui.mute.className = 'mini' + (pt.mute ? ' on' : '');
      pt.ui.mute.setAttribute('aria-pressed', String(pt.mute));
      pt.ui.solo.className = 'mini' + (pt.solo ? ' on' : '');
      pt.ui.solo.setAttribute('aria-pressed', String(pt.solo));
      pt.ui.root.className = 'part' + (heard(pt) ? '' : ' mute');
    });
  }

  /** 时间轴:每个声部一条,同一把时间尺(一小节在几条轨上是同一段像素) */
  function renderRoll() {
    var p = state.piece;
    if (!p) return;
    var pps = p.pps, W = Math.max(80, Math.ceil(p.total * pps) + 10);
    p.parts.forEach(function (pt) {
      if (!pt.ui) return;
      var lane = pt.ui.lane;
      while (lane.firstChild) lane.removeChild(lane.firstChild);
      var ini = el('div', 'lini');
      ini.style.width = W + 'px';
      pt.blks = [];
      pt.notes.forEach(function (nn, i) {
        var st = pt.steps[i];
        var b = el('i', 'blk' + (nn.rest ? ' rest' : ''));
        var label = IO.notesToText([nn], [], pt.song.key || p.key, pt.song.base == null ? p.base : pt.song.base);
        b.textContent = label.replace(/:[\d.]+/g, '');
        b.title = label;
        b.setAttribute('aria-label', label);
        b.style.left = (st.at * pps).toFixed(1) + 'px';
        b.style.width = Math.max(10, st.base * pps - 2).toFixed(1) + 'px';
        pt.blks.push(b);
        ini.appendChild(b);
      });
      lane.appendChild(ini);
      pt.ui.lini = ini;
      lane.scrollLeft = 0;
    });
  }

  /* ============================================================
     六、抽屉
     ============================================================ */
  function openSheet(id) {
    var s = $(id);
    if (!s || state.sheets.indexOf(id) >= 0) return;
    state.sheets.push(id);
    state.sheets.forEach(function (sid) { $(sid).className = 'sheet' + (sid === id ? ' on' : ''); });
    s.className = 'sheet on';
    $('mask').className = 'mask on';
  }
  function closeSheet(id) {
    var s = $(id);
    if (!s) return;
    var i = state.sheets.indexOf(id);
    if (i >= 0) state.sheets.splice(i, 1);
    s.className = 'sheet';
    if (!state.sheets.length) $('mask').className = 'mask';
    else $(state.sheets[state.sheets.length - 1]).className = 'sheet on';
  }
  function closeAll() {
    state.sheets.slice().forEach(closeSheet);
  }

  function renderArr() {
    var box = $('arrList');
    while (box.firstChild) box.removeChild(box.firstChild);
    ARR.forEach(function (a) {
      var row = el('div', 'row');
      var g = el('div', 'grow');
      g.appendChild(el('div', 't1', a.name));
      g.appendChild(el('div', 't2', a.desc));
      var acts = el('div', 'acts');
      var b = el('button', '', '用这首');
      b.setAttribute('aria-label', '用这首:' + a.name);
      b.onclick = function () { closeAll(); load(a.text, true); ping(); };
      acts.appendChild(b);
      row.appendChild(g); row.appendChild(acts);
      box.appendChild(row);
    });
  }

  function renderAdvParts() {
    var box = $('instList');
    while (box.firstChild) box.removeChild(box.firstChild);
    var p = state.piece;
    if (!p) return;
    p.parts.forEach(function (pt, i) {
      var row = el('div', 'row');
      var g = el('div', 'grow');
      g.appendChild(el('div', 't1', pt.name));
      g.appendChild(el('div', 't2', pt.inst.name + (pt.inst.desc ? ' · ' + pt.inst.desc : '')));
      if (pt.ui && pt.ui.vol) g.appendChild(pt.ui.vol);
      var acts = el('div', 'acts');
      var b = el('button', '', '换乐器');
      b.setAttribute('aria-label', '换' + pt.name + '的乐器');
      b.onclick = function () {
        state.instFor = i; state.curFam = Math.max(0, A.families.indexOf(pt.inst.fam));
        renderFams(); renderInst(); openSheet('sheetInst');
      };
      acts.appendChild(b);
      row.appendChild(g); row.appendChild(acts);
      box.appendChild(row);
    });
  }

  function renderFams() {
    var seg = $('famSeg');
    while (seg.firstChild) seg.removeChild(seg.firstChild);
    var fams = (A && A.families) || [];
    fams.forEach(function (f, i) {
      var b = el('button', 'seg44' + (i === state.curFam ? ' on' : ''), f);
      b.setAttribute('aria-label', f + '这一类');
      b.onclick = function () { state.curFam = i; renderFams(); renderInst(); };
      seg.appendChild(b);
    });
  }

  function renderInst() {
    var segs = $('famSeg').children, i;
    for (i = 0; i < segs.length; i++) segs[i].className = 'seg44' + (i === state.curFam ? ' on' : '');
    var p = state.piece;
    var cur = p && p.parts[state.instFor];
    $('instTitle').textContent = cur ? ('换「' + cur.name + '」的乐器') : '换一件乐器';
    var box = $('instRows');
    while (box.firstChild) box.removeChild(box.firstChild);
    var fams = (A && A.families) || [];
    var want = fams[state.curFam];
    instList().forEach(function (I) {
      if (want && I.fam !== want) return;
      var b = el('button', 'irow');
      b.setAttribute('aria-label', I.name + ',用这件乐器');
      var t1 = el('div', 't1', I.name);
      var t2 = el('div', 't2', I.desc || '');
      b.appendChild(t1); b.appendChild(t2);
      var used = cur && cur.inst.id === I.id;
      if (used) {
        t1.appendChild(el('span', 'picked', '正在用'));
        t1.className = 't1 on';
      }
      b.onclick = function () {
        if (!cur) { say('先挑一首谱子'); return; }
        if (state.exporting) { say('正在导出音频，完成后可以换乐器'); return; }
        var a = anchor();
        cur.inst = I;
        closeSheet('sheetInst');
        planPiece(); renderHead(); renderParts(); renderAdvParts(); saveNow();
        restoreAnchor(a);
        if (state.playing) schedule(state.position);
        updatePosition(); beatWarn();
        ping();
      };
      box.appendChild(b);
    });
  }

  /* ============================================================
     七、装进页面 / 存档
     ============================================================ */
  function load(text, remember) {
    if (state.exporting) { say('正在导出音频，完成后可以换谱'); return false; }
    var r = parsePiece(text);
    if (!r.ok) {
      var m = (r.error.message || '这段谱子读不出来') + (r.error.hint ? '\n' + r.error.hint : '');
      $('impErr').textContent = m;
      if (state.sheets.indexOf('sheetImp') < 0) openSheet('sheetImp');
      say(r.error.message);
      if (jh() && JH.sfx) jcall(JH.sfx('err'));
      return false;
    }
    stop(true);
    /* 旧谱子的声部增益轨先断开 —— 不然每换一首就漏一串挂在 master 上的轨 */
    if (state.piece) state.piece.parts.forEach(function (pt) {
      if (pt.bus) {
        var oldBus = pt.bus;
        setTimeout(function () { try { oldBus.disconnect(); } catch (e) { } }, 100);
        pt.bus = null;
      }
    });
    state.text = String(text);
    var m = r.meta;
    state.piece = {
      title: m.title, key: m.key, base: m.base, bpm: m.bpm, origin: m.origin,
      parts: m.parts, total: 0, beat: 0.6, pps: 40
    };
    planPiece();
    renderHead(); renderParts(); renderAdvParts();
    updatePosition();
    beatWarn();
    $('impErr').textContent = '';
    var out = 0;
    state.piece.parts.forEach(function (p) { out += p.rangeOut; });
    tip(out ? ('有 ' + out + ' 个音超出了这件乐器能奏的高低范围,那几个音会不出声') : '');
    if (remember) saveNow();
    pushWidget();
    return true;
  }

  function saveNow() {
    if (!jh() || !JH.storage) return;
    var p = state.piece;
    var data = {
      text: pieceText(), speed: state.speed, master: state.master, wet: state.wet,
      click: state.click, loop: state.loop,
      parts: p ? p.parts.map(function (pt) { return { g: pt.gain, m: pt.mute, s: pt.solo, i: pt.inst.id }; }) : []
    };
    jcall(JH.storage.set(KEY, JSON.stringify(data)));
  }

  function pushWidget() {
    if (!jh() || !JH.widget || !state.piece) return;
    jcall(JH.widget.set({
      title: state.piece.title,
      lines: [
        { t: '声部', d: state.piece.parts.length + ' 个' },
        { t: '长度', d: fmtdur(state.piece.total) }
      ],
      accent: '#0061CB',
      tap: 'plugin:score_player'
    }));
  }

  /* ============================================================
     八、导出
     ============================================================ */
  function safeName(s) {
    return String(s || '乐谱').replace(/[\\/:*?"<>|\n\r\t]/g, '_').slice(0, 40) || '乐谱';
  }

  /** 当前这一份谱子 → 多声部文本(存成文件、送台面都用它) */
  function pieceText() {
    var p = state.piece;
    if (!p) return '';
    var L = ['@title ' + p.title, '@bpm ' + p.bpm, '@key ' + p.key, '@base ' + p.base];
    if (p.origin) L.push('@origin ' + p.origin);
    L.push('');
    p.parts.forEach(function (pt, i) {
      L.push('@part ' + pt.inst.name + ' | ' + pt.name);
      /* 这一声部如果自己带了别的 @key/@base(头部那份是全局的),导出时得写在它自己头上,
         不然再导入进来就变成按全局主音读了 —— 音会整体跑调 */
      var k = pt.song.key || p.key, b = typeof pt.song.base === 'number' ? pt.song.base : p.base;
      if (k !== p.key) L.push('@key ' + k);
      if (b !== p.base) L.push('@base ' + b);
      L.push(wrapBars(IO.notesToText(pt.notes, pt.bars, k, b)));
      if (i < p.parts.length - 1) L.push('');
    });
    return L.join('\n');
  }
  function wrapBars(text) {
    var toks = String(text).split(/\s+/), out = [], line = [], bars = 0, i;
    for (i = 0; i < toks.length; i++) {
      if (toks[i] === '|') {
        line.push('|'); bars++;
        if (bars >= 4) { out.push(line.join(' ')); line = []; bars = 0; }
        continue;
      }
      line.push(toks[i]);
    }
    if (line.length) out.push(line.join(' '));
    return out.join('\n');
  }

  /**
   * 离线把当前这首奏一遍,拿回一条 AudioBuffer。
   * 做法:临时把 window.AudioContext 换成一个"返回我那台离线机器"的壳,
   * 再加载**第二份 audio.js**(新闭包 = 一份全新的引擎),让它离线奏;
   * 奏完立刻把 window 上的东西还回去 —— 页面上正在用的那一份引擎一个字节都没动。
   */
  function renderOffline(frames, sr) {
    var p = state.piece, mix = { master: state.master, wet: state.wet, click: state.click,
      beat: p.beat, total: p.total, parts: p.parts.map(function (pt) {
        return { inst: pt.inst, notes: pt.notes.slice(), steps: pt.steps.slice(), gain: partGain(pt) };
      }) };
    return new Promise(function (res, rej) {
      var OAC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
      if (!OAC) { rej(new Error('这台机器不支持离线录音')); return; }
      var off;
      try { off = new OAC(2, frames, sr); } catch (e) { rej(new Error('离线录音开不起来:' + e.message)); return; }
      /* 引擎里那句 unlock() 会把 suspended 的上下文 resume() 一下 —— 离线机器还没开始跑,
         这时 resume 会把时间轴弄乱,所以壳子上把 state 说成 running、把 resume 变成空动作 */
      var shell = new Proxy(off, {
        get: function (t, k) {
          if (k === 'state') return 'running';
          if (k === 'resume') return function () { };
          var v = t[k];
          return typeof v === 'function' ? v.bind(t) : v;
        },
        set: function (t, k, v) { t[k] = v; return true; }
      });
      var realAC = window.AudioContext, realWK = window.webkitAudioContext;
      var restore = function () {
        window.AudioContext = realAC; window.webkitAudioContext = realWK;
        window.JH_BOX_AUDIO = A;
      };
      window.AudioContext = function () { return shell; };
      window.webkitAudioContext = window.AudioContext;
      var s = document.createElement('script');
      var timeout = setTimeout(function () {
        s.onload = s.onerror = null; restore(); s.remove(); rej(new Error('读取声音引擎超时，请重试'));
      }, 20000);
      s.src = BASE + 'audio.js';
      s.onload = function () {
        clearTimeout(timeout); s.remove();
        var M = window.JH_BOX_AUDIO;          /* 刚加载出来的那一份(新闭包) */
        /* 引擎懒建上下文：先在壳还生效时绑定离线图，再恢复页面构造器。 */
        try {
          if (!M || M === A || !M.unlock()) throw new Error('离线声音引擎没有准备好');
        } catch (e) { restore(); rej(e); return; }
        restore();
        try {
          M.setVolume(mix.master);
          M.setWet(mix.wet);
          var t0 = 0.1, i, pt;
          for (var k = 0; k < mix.parts.length; k++) {
            pt = mix.parts[k];
            if (!pt.gain) continue;
            var dst = M.bus ? M.bus(pt.gain) : null;
            for (i = 0; i < pt.notes.length; i++) {
              var nn = pt.notes[i], st = pt.steps[i];
              if (nn.rest) continue;
              M.noteOn(pt.inst, nn.midi, clamp(st.vel, 0.05, 1), t0 + st.at, st.hold, null, dst);
            }
          }
          if (mix.click && M.tick) for (var ci = 0; ci * mix.beat < mix.total; ci++) M.tick(ci % 4 === 0, t0 + ci * mix.beat);
          off.startRendering().then(res, function (e) {
            rej(new Error('离线录音没跑起来:' + ((e && e.message) || e)));
          });
        } catch (e) { restore(); rej(e); }
      };
      s.onerror = function () { clearTimeout(timeout); s.remove(); restore(); rej(new Error('读不到 audio.js')); };
      document.head.appendChild(s);
    });
  }

  function wavBytes(buf) {
    var n = buf.length, sr = buf.sampleRate, chan = 2, bps = 2;
    var dataLen = n * chan * bps;
    var out = new Uint8Array(44 + dataLen);
    var dv = new DataView(out.buffer);
    function str(at, s) { for (var i = 0; i < s.length; i++) dv.setUint8(at + i, s.charCodeAt(i)); }
    str(0, 'RIFF'); dv.setUint32(4, 36 + dataLen, true); str(8, 'WAVE');
    str(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, chan, true);
    dv.setUint32(24, sr, true); dv.setUint32(28, sr * chan * bps, true);
    dv.setUint16(32, chan * bps, true); dv.setUint16(34, 16, true);
    str(36, 'data'); dv.setUint32(40, dataLen, true);
    var L = buf.getChannelData(0), R = buf.numberOfChannels > 1 ? buf.getChannelData(1) : L;
    var off = 44, i, l, r;
    for (i = 0; i < n; i++) {
      l = L[i]; r = R[i];
      l = l < -1 ? -1 : (l > 1 ? 1 : l);
      r = r < -1 ? -1 : (r > 1 ? 1 : r);
      dv.setInt16(off, l * 32767, true); off += 2;
      dv.setInt16(off, r * 32767, true); off += 2;
    }
    return out;
  }

  function exportWav() {
    if (state.exporting) return;
    if (!state.piece) { say('先挑一首或粘一段谱子'); return; }
    var sec = state.piece.total + 2.4;
    var frames = Math.ceil(sec * WAV_SR);
    var bytes = 44 + frames * 4;
    if (bytes > MAX_WAV) {
      tip('这一首连混响尾巴一共约 ' + Math.round(sec) + ' 秒,存成音频会超过 40MB。'
        + '先把速度调快一点,或者换一首短的。');
      if (jh()) jcall(JH.sfx('err'));
      return;
    }
    state.exporting = true;
    var exportTitle = state.piece.title;
    clearTimeout(state.spdTimer);
    syncSliders();
    var wasPlaying = state.playing;
    if (wasPlaying) pause();
    tip('正在把这几个声部一次奏完(' + Math.round(sec) + ' 秒),大概要等一会儿…');
    renderOffline(frames, WAV_SR).then(function (buf) {
      tip('正在存成 WAV(约 ' + Math.round(bytes / 1048576 * 10) / 10 + ' MB)…');
      var u8 = wavBytes(buf);
      if (!jh() || !JH.saveFile) { tip('浏览器里没法另存文件,手机上可以'); state.exporting = false; return; }
      /* 「用户取消」与「另存为没起来」是两件事(文档 §3.4,2026-10-08 起):
         false = 他自己取消的,静默收场;reject(e.code==='no_picker') = 没起来,要说出来。
         下面那个 .catch 接的就是后者 —— 它的 e.message 已经是一句人话。 */
      return JH.saveFile(safeName(exportTitle) + '.wav', 'audio/wav', u8).then(function (ok) {
        if (!ok) { tip(''); return; }
        tip('音频已经存好了,去「下载」里找 ' + safeName(exportTitle) + '.wav');
        ping(); say('音频存好了');
      });
    }).catch(function (e) {
      tip('');
      say((e && e.message) || '这台机器上没做出音频');
    }).then(function () {
      state.exporting = false;
    });
  }

  function exportText() {
    if (!state.piece) { say('先挑一首或粘一段谱子'); return; }
    var t = pieceText();
    if (!jh() || !JH.saveFile) { say('浏览器里没法另存文件,手机上可以'); return; }
    jcall(JH.saveFile(safeName(state.piece.title) + '.txt', 'text/plain', t).then(function (ok) {
      if (ok) { ping(); say('谱子存好了'); }
    }));
  }

  function toBench() {
    if (!state.piece) { say('先挑一首或粘一段谱子'); return; }
    if (!jh() || !JH.workbench) { say('当前版本不支持工作台'); return; }
    jcall(JH.workbench.put({ type: 'text', text: pieceText(), name: safeName(state.piece.title) + '.txt' })
      .then(function () { ping(); say('已经放到工作台了'); }));
  }

  /* ============================================================
     九、导入
     ============================================================ */
  function takeText() {
    var t = $('impText').value;
    if (!/\S/.test(t || '')) { $('impErr').textContent = '先把谱子粘进来。'; return; }
    if (load(t, true)) {
      $('impText').value = '';
      closeSheet('sheetImp');
      ping();
      say('收下了:' + state.piece.title);
    }
  }
  function pickFile() {
    if (!jh() || !JH.pickText) { say('当前版本不支持选文件'); return; }
    jcall(JH.pickText('text/*').then(function (f) {
      if (!f) return;
      if (load(f.text, true)) { closeSheet('sheetImp'); ping(); say('收下了:' + state.piece.title); }
    }));
  }

  /* ============================================================
     十、启动
     ============================================================ */
  function syncSliders() {
    $('master').value = Math.round(state.master * 100);
    $('volTxt').textContent = Math.round(state.master * 100) + '%';
    $('master').style.setProperty('--p', $('master').value);
    $('wet').value = Math.round(state.wet * 100);
    $('wetTxt').textContent = Math.round(state.wet * 100) + '%';
    $('wet').style.setProperty('--p', $('wet').value);
    $('spd').value = Math.round(state.speed * 100);
    $('spdTxt').textContent = state.speed.toFixed(2) + '×';
    $('spd').style.setProperty('--p', Math.round((state.speed - 0.5) / 1 * 100));
    $('btnClick').className = 'tg' + (state.click ? ' on' : '');
    $('btnClick').setAttribute('aria-pressed', String(state.click));
    $('btnLoop').className = 'tg' + (state.loop ? ' on' : '');
    $('btnLoop').setAttribute('aria-pressed', String(state.loop));
    if (A) { A.setVolume(state.master); A.setWet(state.wet); }
  }

  function boot() {
    renderArr(); renderFams();
    $('spd').addEventListener('input', function () {
      if (state.exporting) { syncSliders(); return; }
      var speed = clamp(parseInt($('spd').value, 10) / 100, 0.5, 1.5);
      $('spdTxt').textContent = speed.toFixed(2) + '×';
      $('spd').style.setProperty('--p', Math.round((speed - 0.5) * 100));
      clearTimeout(state.spdTimer);
      state.spdTimer = setTimeout(function () {
        var a = anchor();
        state.speed = speed;
        planPiece(); restoreAnchor(a); renderHead(); renderRoll();
        if (state.playing) schedule(state.position);
        updatePosition();
        saveNow();
      }, 180);
    });
    $('master').addEventListener('input', function () {
      state.master = parseInt($('master').value, 10) / 100;
      $('volTxt').textContent = Math.round(state.master * 100) + '%';
      $('master').style.setProperty('--p', $('master').value);
      if (A) A.setVolume(state.master);
    });
    $('master').addEventListener('change', saveNow);
    $('wet').addEventListener('input', function () {
      state.wet = parseInt($('wet').value, 10) / 100;
      $('wetTxt').textContent = Math.round(state.wet * 100) + '%';
      $('wet').style.setProperty('--p', $('wet').value);
      if (A) A.setWet(state.wet);
    });
    $('wet').addEventListener('change', saveNow);
    $('btnClick').onclick = function () {
      state.click = !state.click; syncSliders(); saveNow();
      reseek();
    };
    $('btnLoop').onclick = function () { state.loop = !state.loop; syncSliders(); saveNow(); };

    $('btnPlay').onclick = function () { play(); };
    $('btnRestart').onclick = function () {
      if (state.exporting) return;
      var was = state.playing;
      stop(true);
      if (was) play();
    };
    $('seek').addEventListener('input', function () {
      state.seeking = true;
      $('timeTxt').textContent = clockText(Number(this.value)) + ' / ' + clockText(state.piece ? state.piece.total : 0);
      this.style.setProperty('--p', state.piece ? 100 * Number(this.value) / state.piece.total : 0);
    });
    $('seek').addEventListener('change', function () {
      state.seeking = false;
      if (!state.piece || state.exporting) { updatePosition(); return; }
      state.position = clamp(Number(this.value), 0, state.piece.total);
      clearCur();
      if (state.playing && !schedule(state.position)) pause();
      setPlayBtn(); updatePosition();
    });
    $('btnArr').onclick = function () { openSheet('sheetArr'); };
    $('btnImp').onclick = function () { openSheet('sheetImp'); };
    $('btnImp2').onclick = function () { closeSheet('sheetArr'); openSheet('sheetImp'); };
    $('btnAdv').onclick = function () { renderAdvParts(); openSheet('sheetAdv'); };
    $('btnWav').onclick = exportWav;
    $('btnSheet').onclick = exportText;
    $('btnBench').onclick = toBench;
    $('btnTake').onclick = takeText;
    $('btnFile').onclick = pickFile;
    $('mask').onclick = function () { closeAll(); };
    Array.prototype.forEach.call(document.querySelectorAll('[data-close]'), function (b) {
      b.onclick = function () {
        var s = b.closest ? b.closest('.sheet') : null;
        if (s) closeSheet(s.id); else closeAll();
      };
    });

    if (jh() && JH.onBack) {
      /* 注册这一下没有 Promise 可接;它只可能在这里就把异常抛出来,所以就地兜住 */
      try { JH.onBack(function () {
        if (state.sheets.length) { closeSheet(state.sheets[state.sheets.length - 1]); return true; }
        if (state.playing) { pause(); return true; }
        return false;
      }); } catch (e) { fail(e); }
    }
    document.addEventListener('visibilitychange', function () { if (document.hidden && state.playing) pause(); });
    window.addEventListener('pagehide', function () {
      stop(); clearTimeout(warmT); clearTimeout(state.spdTimer); clearTimeout(state.volTimer); saveNow();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (state.sheets.length) { closeSheet(state.sheets[state.sheets.length - 1]); e.preventDefault(); }
      else if (state.playing) { pause(); e.preventDefault(); }
    });

    /* 存档 → 恢复上次那一份;头一次进来就摆一首内置编曲(打开就能听,不必先找谱子) */
    var chain = Promise.resolve();
    if (jh() && JH.storage) {
      chain = JH.storage.get(KEY).then(function (raw) {
        if (!raw) return null;
        try { return JSON.parse(raw); } catch (e) { return null; }
      }).catch(function (e) { fail(e); return null; });
    }
    chain.then(function (st) {
      if (st && typeof st.text === 'string' && st.text) {
        state.speed = (st.speed >= 0.5 && st.speed <= 1.5) ? st.speed : 1;
        state.master = typeof st.master === 'number' && isFinite(st.master) ? clamp(st.master, 0, 1) : 0.9;
        state.wet = typeof st.wet === 'number' && isFinite(st.wet) ? clamp(st.wet, 0, 0.6) : 0.18;
        state.click = !!st.click; state.loop = !!st.loop;
        if (!load(st.text, false) ) load(ARR[0].text, false);
        else if (st.parts && st.parts.length === state.piece.parts.length) {
          state.piece.parts.forEach(function (pt, i) {
            var q = st.parts[i];
            if (!q) return;
            pt.gain = typeof q.g === 'number' && isFinite(q.g) ? clamp(q.g, 0, 1) : pt.gain;
            pt.mute = !!q.m; pt.solo = !!q.s;
            if (q.i) { var I = findInst(q.i); if (I) pt.inst = I; }
          });
          planPiece(); renderHead(); renderParts(); renderAdvParts();
        }
      } else {
        load(ARR[0] ? ARR[0].text : '', false);
      }
    }).then(function () {
      syncSliders();
      renderAdvParts();
      return jh() && JH.launchParams ? jcall(JH.launchParams()) : null;
    }).then(function (lp) {
      if (lp && lp.text && /\S/.test(lp.text)) {
        if (load(lp.text, true)) { syncSliders(); say('工作台送来的谱子已经收下了'); }
      }
    }).catch(function (e) { fail(e); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  /* ============================================================
     十一、只读的自检口子
     ------------------------------------------------------------
     与引擎的 live() / ticks() 同一个用途:自检要断言的是**模型状态**
     ("速度改了以后每个音排在第几秒""哪个声部这一遍出不出声"),不是"看起来变了"。
     页面自己一个字段都不读它,写进去的都是查表函数。
     ============================================================ */
  window.JH_SCORE_PLAYER = {
    title: function () { return state.piece ? state.piece.title : ''; },
    parts: function () { return state.piece ? state.piece.parts.length : 0; },
    notes: function (pi) { var p = state.piece; return p && p.parts[pi] ? p.parts[pi].notes.length : 0; },
    at: function (pi, i) {
      var p = state.piece;
      return (p && p.parts[pi] && p.parts[pi].steps[i]) ? p.parts[pi].steps[i].at : -1;
    },
    total: function () { return state.piece ? state.piece.total : 0; },
    bpm: function () { return state.piece ? state.piece.bpm : 0; },
    speed: function () { return state.speed; },
    played: function (pi, i) {
      var p = state.piece;
      return (p && p.parts[pi] && p.parts[pi].steps[i]) ? !p.parts[pi].steps[i].rest : false;
    },
    muted: function (pi) { var p = state.piece; return p && p.parts[pi] ? p.parts[pi].mute : false; },
    solo: function (pi) { var p = state.piece; return p && p.parts[pi] ? p.parts[pi].solo : false; },
    heard: function (pi) { var p = state.piece; return p && p.parts[pi] ? heard(p.parts[pi]) : false; },
    /* 自检用:这条声部的增益轨现在生效的音量(静音/独奏/推子最后都落在它上面),
       以及这条声部的排音游标走到哪了（只向前补一小段，不一口气排整首） */
    gainNow: function (pi) {
      /* 报**有效增益** = 轨上的值 × 排音时已经乘进力度的那一份。
         轨上的字面值现在只是"相对排音时的倍数",自检要读的是"这一声部现在总共多响"。 */
      var p = state.piece, pt = p && p.parts[pi];
      if (!pt) return -1;
      if (!pt.bus) return -2;
      return pt.bus.gain.value;
    },
    schedAt: function (pi) { var p = state.piece; return p && p.parts[pi] ? p.parts[pi].si : -1; },
    playing: function () { return state.playing; },
    position: position
  };
})();
