/* Strict, bounded SMF 0/1 reader. Original files remain the authoritative export. */
(function(root){'use strict';
function fail(s){throw new Error(s);}
function parse(input){
 var a=input instanceof Uint8Array?input:new Uint8Array(input),p=0,events=[],notes=[],warnings=[],seq=0;
 if(a.length<14||a.length>2000000)fail('MIDI 文件大小不支持。');
 function need(n,end){if(n<0||p+n>(end==null?a.length:end))fail('MIDI 数据不完整。');}
 function u8(end){need(1,end);return a[p++];}function u16(){return u8()*256+u8();}function u32(){return u8()*16777216+u8()*65536+u8()*256+u8();}
 function word(){return String.fromCharCode(u8(),u8(),u8(),u8());}
 function vl(end){var v=0,n,b;for(n=0;n<4;n++){b=u8(end);v=v*128+(b&127);if(!(b&128))return v;}fail('MIDI 变长整数无效。');}
 function data(end){var b=u8(end);if(b>127)fail('MIDI 事件数据无效。');return b;}
 function txt(start,n){var s='',i;for(i=start;i<start+n&&s.length<120;i++){var c=a[i];s+=c>=32&&c<127?String.fromCharCode(c):c>=128?'·':'';}return s;}
 if(word()!=='MThd')fail('不是标准 MIDI 文件。');var hl=u32();if(hl<6||hl>1024)fail('MIDI 文件头无效。');need(hl);
 var format=u16(),nt=u16(),ppq=u16();if(format>1)fail('暂不支持 SMF 2 独立序列。');if(!nt||nt>128||(format===0&&nt!==1))fail('MIDI 轨道数无效。');if(!ppq||(ppq&32768))fail('暂不支持 SMPTE 时间制 MIDI。');p=8+hl;
 var tracks=[],ti;
 for(ti=0;ti<nt;ti++){
  if(word()!=='MTrk')fail('MIDI 轨道头无效。');var len=u32();need(len);var end=p+len,tick=0,running=0,ended=false,track={index:ti,name:'轨道 '+(ti+1),notes:[],channels:[],programs:{}};
  tracks.push(track);
  while(p<end){
   tick+=vl(end);if(tick>ppq*3600*20)fail('MIDI 时长超出范围。');var st=u8(end);
   if(st<128){if(!running)fail('MIDI 缺少运行状态。');p--;st=running;}else if(st<240)running=st;else running=0;
   if(st===255){var type=u8(end),ml=vl(end);need(ml,end);
    if(type===47){if(ml!==0)fail('MIDI 结束事件无效。');ended=true;if(p!==end)fail('MIDI 结束事件后有多余数据。');break;}
    if(type===81){if(ml!==3)fail('MIDI 速度事件无效。');var us=a[p]*65536+a[p+1]*256+a[p+2];if(!us)fail('MIDI 速度无效。');events.push({tick:tick,kind:'tempo',us:us,seq:seq++});}
    else if(type===3)track.name=txt(p,ml)||track.name;
    else if(type===88){if(ml!==4||!a[p]||a[p+1]>7)fail('MIDI 拍号无效。');events.push({tick:tick,kind:'meter',num:a[p],den:Math.pow(2,a[p+1]),seq:seq++});}
    p+=ml;continue;
   }
   if(st===240||st===247){var sl=vl(end);need(sl,end);p+=sl;if(warnings.indexOf('含系统专用消息，试听不还原设备专有音色。')<0)warnings.push('含系统专用消息，试听不还原设备专有音色。');continue;}
   if(st>=240)fail('MIDI 含不支持的系统事件。');
   var kind=st>>4,ch=st&15,d1=data(end),d2=(kind===12||kind===13)?0:data(end);
   if(kind===9||kind===8){events.push({tick:tick,kind:kind===8||d2===0?'off':'on',ch:ch,midi:d1,vel:d2,track:ti,seq:seq++});}
   else if(kind===12){events.push({tick:tick,kind:'program',ch:ch,program:d1,track:ti,seq:seq++});track.programs[ch]=d1;}
   else if(kind===11||kind===14||kind===10||kind===13){if(warnings.indexOf('含控制器或表情消息；合成试听暂不还原踏板、弯音及表情。')<0)warnings.push('含控制器或表情消息；合成试听暂不还原踏板、弯音及表情。');}
   if(events.length>200000)fail('MIDI 事件过多。');
  }
  if(!ended)fail('MIDI 轨道缺少结束事件。');track.endTick=tick;p=end;
 }
 if(p!==a.length)fail('MIDI 文件尾含多余数据。');
 events.sort(function(x,y){return x.tick-y.tick||x.seq-y.seq;});
 var active=Object.create(null),program=[],tempo=500000,at=0,seconds=0,tempos=[{tick:0,us:500000,time:0}],meters=[],durationTick=0;
 events.forEach(function(e){
  seconds+=(e.tick-at)*tempo/ppq/1000000;at=e.tick;e.time=seconds;
  if(seconds>3600)fail('MIDI 时长须在一小时内。');
  if(e.kind==='tempo'){tempo=e.us;if(tempos[tempos.length-1].tick===e.tick)tempos[tempos.length-1]={tick:e.tick,us:tempo,time:seconds};else tempos.push({tick:e.tick,us:tempo,time:seconds});return;}
  if(e.kind==='meter'){meters.push(e);return;}if(e.kind==='program'){program[e.ch]=e.program;return;}
  var key=e.track+':'+e.ch+':'+e.midi,queue=active[key]||(active[key]=[]);
  if(e.kind==='on'){queue.push({tick:e.tick,time:seconds,midi:e.midi,velocity:e.vel/127,channel:e.ch,program:program[e.ch]||0,track:e.track});}
  else if(e.kind==='off'){
   if(!queue.length)fail('MIDI 有音符结束却没有开始。');var n=queue.shift();
   if(e.tick<=n.tick)fail('MIDI 含零时长音符。');n.endTick=e.tick;n.end=seconds;notes.push(n);tracks[n.track].notes.push(n);durationTick=Math.max(durationTick,e.tick);
   if(notes.length>100000)fail('MIDI 音符过多。');
  }
 });
 Object.keys(active).forEach(function(k){if(active[k].length)fail('MIDI 有未结束的音符。');});
 if(!notes.length)fail('MIDI 没有可试听的音符。');notes.sort(function(x,y){return x.time-y.time||x.track-y.track||x.midi-y.midi;});
 var duration=0;notes.forEach(function(n){duration=Math.max(duration,n.end);});
 tracks.forEach(function(t){t.notes.sort(function(x,y){return x.tick-y.tick||x.midi-y.midi;});t.notes.forEach(function(n){if(t.channels.indexOf(n.channel)<0)t.channels.push(n.channel);});});
 return {format:format,ppq:ppq,tracks:tracks,notes:notes,tempos:tempos,meters:meters,duration:duration,durationTick:durationTick,warnings:warnings};
}
function instrument(program){if(program===73)return 'flute';if(program>=40&&program<=43)return program===42?'cello':'violin';if(program>=24&&program<=31)return 'guitar';if(program>=16&&program<=23)return 'organ';if(program===71)return 'clarinet';if(program>=56&&program<=63)return 'trumpet';return 'piano';}
function lanes(score,trackIndex){
 var out=[];score.tracks.forEach(function(t){if(trackIndex!=null&&t.index!==trackIndex)return;var own=[];
 t.notes.forEach(function(n){var lane=null,i;for(i=0;i<own.length;i++)if(own[i].end<=n.tick&&own[i].channel===n.channel&&own[i].program===n.program){lane=own[i];break;}
 if(!lane){lane={name:t.name+' · 声部 '+(own.length+1),track:t.index,channel:n.channel,program:n.program,end:0,notes:[]};own.push(lane);}lane.notes.push(n);lane.end=n.endTick;});out=out.concat(own);});return out;
}
function practice(score,title,origin,selected){
 if(score.tempos.some(function(t){return t.us!==score.tempos[0].us;}))fail('原曲有速度变化，请在本库试听；现有练习文本不支持完整变速。');
 var bpm=60000000/score.tempos[0].us;if(bpm<40||bpm>200||Math.abs(bpm-Math.round(bpm))>0.001)fail('原曲速度不在现有练习文本支持范围。');
 var ls=lanes(score),chosen=selected==null?ls:[ls[selected]];if(!chosen.length||!chosen[0])fail('请选择声部。');if(chosen.length>16)fail('复音拆分超过16个声部，请明确选一声部练习。');
 var head='@title '+String(title).replace(/[\r\n]/g,' ').slice(0,40)+'\n@bpm '+Math.round(bpm)+'\n@origin '+String(origin).replace(/[\r\n]/g,' ').slice(0,120)+'\n',chunks=[],names=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
 chosen.forEach(function(l){var at=0,tokens=[];
 function token(m,d){var beat=d/score.ppq;if(beat<0.05-1e-8||beat>8+1e-8)fail('声部含过短或过长音符，不能完整转成现有练习文本。');var v=Math.round(beat*1000)/1000;tokens.push((m<0?'0':names[m%12]+(Math.floor(m/12)-1))+':'+v);if(tokens.length>1200)fail('声部超过现有工具1200音限制。');}
 l.notes.forEach(function(n){if(n.channel===9)fail('打击乐轨暂不转换为有音高练习谱。');if(n.midi<12||n.midi>108)fail('声部超出现有练习谱的音域。');var start=Math.round(n.tick/score.ppq*1000)/1000*score.ppq,finish=Math.round(n.endTick/score.ppq*1000)/1000*score.ppq,gap=start-at;while(gap>score.ppq*8){token(-1,score.ppq*8);gap-=score.ppq*8;}if(gap)token(-1,gap);token(n.midi,finish-start);at=finish;});
 chunks.push((selected==null?'@part '+instrument(l.program)+' | '+l.name.replace(/[\r\n|]/g,' ').slice(0,50)+'\n':'')+tokens.join(' '));
 });
 var result=head+chunks.join('\n');if(result.length>150000)fail('练习文本超过工作台150000字限制。');return result;
}
var api={parse:parse,lanes:lanes,practice:practice,instrument:instrument};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ScoreMidi=api;
}(typeof window!=='undefined'?window:this));
