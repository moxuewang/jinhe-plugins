/* One serialized writer; optimistic conflict detection, never a silent reset. */
(function (root) {
  'use strict';
  function create(storage, model) {
    var raw, state = model.empty(), ready = false, busy = false, pending = null, conflict = false, epoch = 0, closed = false;
    function error(s) { throw new Error(s); }
    function alive(ticket) { if (closed || ticket !== epoch) error('页面已离开，请重新打开后读取记录。'); }
    function load() {
      if (busy || closed) return Promise.reject(new Error('请等当前操作结束。'));
      busy = true; ready = false; var ticket = ++epoch;
      return Promise.resolve().then(function () { alive(ticket); return storage.get('scorelibrary_preferences_v1'); }).then(function (value) {
        alive(ticket); raw = value; var next = value == null ? model.empty() : model.parse(value);
        state = next; ready = true; pending = null; conflict = false; return state;
      }).then(function (r) { busy = false; return r; }, function (e) { busy = false; throw e; });
    }
    function write() {
      if (!ready || busy || !pending || conflict || closed) return Promise.reject(new Error('暂时不能保存，请先读取记录。'));
      busy = true; var ticket = epoch, job = pending;
      return Promise.resolve().then(function () { alive(ticket); return storage.get('scorelibrary_preferences_v1'); }).then(function (value) {
        alive(ticket);
        // A timed-out write may already have reached disk. Retry adopts only this exact candidate.
        if (value === job.encoded) return;
        if (value !== job.base) { conflict = true; error('已保存的记录有变化。请先另存当前记录，再重新读取。'); }
        return storage.set('scorelibrary_preferences_v1', job.encoded).then(function (r) {
          alive(ticket); if (!r || r.ok !== true) error('记录未能保存，请重试。');
        });
      }).then(function () { alive(ticket); return storage.get('scorelibrary_preferences_v1'); }).then(function (value) {
        alive(ticket); if (value !== job.encoded) error('保存后核对没有通过。原画面仍保留，请重试保存。');
        raw = value; state = job.next; pending = null; return state;
      }).then(function (r) { busy = false; return r; }, function (e) { busy = false; throw e; });
    }
    function commit(next) {
      if (!ready || busy || pending || conflict || closed) return Promise.reject(new Error('请先处理尚未保存的操作。'));
      var checked = model.validate(next); pending = {base: raw, next: checked, encoded: model.encode(checked)}; return write();
    }
    return {load: load, commit: commit, retry: write, snapshot: function () { return model.validate(state); }, candidate: function () { return pending ? model.validate(pending.next) : null; }, raw: function () { return raw; }, status: function () { return {ready: ready, busy: busy, pending: !!pending, conflict: conflict}; }, cancel: function () { closed = true; epoch++; }};
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = create; else root.ScoreLibraryStore = create;
}(typeof window !== 'undefined' ? window : this));
