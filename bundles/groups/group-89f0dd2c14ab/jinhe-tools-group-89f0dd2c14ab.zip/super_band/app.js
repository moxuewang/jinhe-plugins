/* ============================================================
   超级乐器 · 页面逻辑
   ------------------------------------------------------------
   一句话:把几件乐器摆在同一屏上,让一个人同时把它们弹出来。

   三件事分得很清楚:
     audio.js  只管发声;
     presets.js 只放内置的几套合奏配置;
     这一份管"手指落在哪儿、台上摆哪几件、那四层录了什么"。

   四条自己守的规矩:
   ① **每一次桥调用都有 catch,并且把 e.message 说给用户听** —— 后台推送(小组件那种)
      只在第一次出错时出声,不然一次意外会刷出一屏提示;用户自己点的动作每次都出声。
   ② 台面上的每一个音格,宽高都不小于 44 —— 手指的尺子,不是眼睛的。
   ③ 录进去的音一定对到八分音符上,圈长一定是整小节:叠第二层时前面那层才对得齐。
   ④ 面板只画在能算准的地方:窗口宽度算不出来就先不画,免得画出点不着的格子。
   ============================================================ */
(function () {
  'use strict';

  var A = window.JH_BOX_AUDIO;
  var PRESETS = window.JH_BAND_PRESETS || [];

  var K_BAND = 'band.v1';       /* 台上摆了什么、哪几个旋钮在哪 */
  var K_TAKE = 'band.take.v1';  /* 录到一半没收尾的那一遍(页面被收走也能捡回来) */
  var K_PRE = 'preset.v1';      /* 自己存下来的合奏配置 */
  var K_RECENT = 'recent.v1';   /* 最近用过的乐器 */

  var MAX_SLOT = 8, MAX_LAYER = 4, MAX_BARS = 8, MAX_EV = 480;
  var HDR = 44;                 /* 面板抬头那一行 */
  var GAPX = 6, GAPY = 6, PAD = 4;
  var MIN_CELL = 45.5;          /* 音格的最小边(44 是硬线,留半像素给取整) */
  var MIN_PANEL = 98;           /* 面板最矮:抬头 44 + 音格 46 + 上下留白 */

  var S = {
    slots: [],                  /* [{id, at}] at = 这一段音区的第一个音(MIDI) */
    layers: [],                 /* [{inst, by, evs, vol, mute, bars}] */
    loopBars: 0,                /* 这一圈几小节(第一层录完就定下来) */
    barsSet: false,             /* 圈长定下来了没有 */
    bpm: 92, click: false, prep: true, snap: true,
    vol: 0.9, wet: 0.18,
    sel: 0,                     /* 正在录的那一层 */
    playing: false, rec: false, armed: false,
    timer: 0, nextT: 0, loopT0: 0, loopSec: 0,
    countTimer: 0, recT0: 0, recList: [], recHold: {}, takeTimer: 0,
    warmKey: '', warmT: 0,
    recent: [], howDone: false, warned: {},
    touchN: 0, pinRaf: 0, pinTop: 0, page: 0, pageSize: 4,
    fam: null, scale: 'name'
  };
  var active = {};              /* pointerId → {p, key, voice, midi, y0} */
  var $ = function (id) { return document.getElementById(id); };

  function jh() { return window.JH || null; }
  function say(m) {
    if (jh() && JH.toast) { var p = JH.toast(m); if (p && p.catch) p.catch(jc('toast')); }
    else if (window.console) console.log('[超级乐器] ' + m);
  }
  function ping() { if (jh() && JH.sfx) { var p = JH.sfx('ok'); if (p && p.catch) p.catch(jc('sfx')); } }
  function fail(e) { say((e && e.message) || '这一步没做成'); }
  /* 后台推送的 catch:第一次出错说人话,之后只在控制台留一句(不然会刷屏) */
  function jc(api) {
    return function (e) {
      var m = (e && e.message) || '这一步没做成';
      if (!S.warned[api]) { S.warned[api] = 1; say(m); }
      else if (window.console) console.log('[' + api + '] ' + m);
    };
  }
  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt != null) e.textContent = txt;
    return e;
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function round(v, n) { var p = Math.pow(10, n || 0); return Math.round(v * p) / p; }

  function instById(id) {
    var L = A.instruments;
    for (var i = 0; i < L.length; i++) if (L[i].id === id) return L[i];
    return null;
  }

  /* ============================================================
     一、音位表:每一件乐器"能点着的音"有哪些
     ------------------------------------------------------------
     取的还是乐器盒那份乐器表里的音位(strings / padsLo+padsScale / keysLo-keysHi),
     **取不到的音用户根本点不着** —— 这里一个音都不自己编。
     ============================================================ */

  function pscale(lo, count, steps) {
    steps = steps || [0, 2, 4, 7, 9];
    var out = [];
    for (var i = 0; i < count; i++) out.push(lo + 12 * Math.floor(i / steps.length) + steps[i % steps.length]);
    return out;
  }
  function isBlack(m) { var p = ((m % 12) + 12) % 12; return p === 1 || p === 3 || p === 6 || p === 8 || p === 10; }
  /* 唱名(简谱数字):音孔与编钟本来就是照音阶排的,那一格是第几级一目了然 */
  var DIGIT = { 0: '1', 2: '2', 4: '3', 5: '4', 7: '5', 9: '6', 11: '7' };
  function digitOf(I, idx) {
    var steps = I.padsScale || [0, 2, 4, 5, 7, 9, 11];
    return DIGIT[steps[idx % steps.length]] || '';
  }
  /** 两根弦的中国弓子:低的叫内弦、高的叫外弦(与乐器盒同一套说法) */
  function bowTag(I, si) {
    if (I.strings.length !== 2) return '第' + (si + 1) + '弦';
    var lo = Math.min(I.strings[0], I.strings[1]);
    return I.strings[si] === lo ? '内弦' : '外弦';
  }

  /** 一件乐器的全部音位(算一次记住,乐器表是死的) */
  function poolOf(I) {
    if (I.__pool) return I.__pool;
    var out = [], i, k, m, ui = I.ui;
    if (ui === 'zither') {
      for (i = 0; i < I.strings.length; i++) out.push({ midi: I.strings[i], sub: '第' + (i + 1) + '弦' });
    } else if (ui === 'fret') {
      /* 有品的:从最低那根弦的空弦,一直排到最高那根弦的最高一品。
         同一个音在几根弦上都能按出来时,取**品数最小**的那个(空弦优先)—— 这就是谱子上写的位置。 */
      var frets = I.frets || 12;
      var lo0 = Math.min.apply(null, I.strings), hi0 = Math.max.apply(null, I.strings) + frets;
      for (m = lo0; m <= hi0; m++) {
        var bf = -1;
        for (k = 0; k < I.strings.length; k++) {
          var f = m - I.strings[k];
          if (f >= 0 && f <= frets && (bf < 0 || f < bf)) bf = f;
        }
        if (bf < 0) continue;
        out.push({ midi: m, sub: bf === 0 ? '空弦' : bf + '品' });
      }
    } else if (ui === 'bow') {
      /* 拉弦:每一根弦从空弦往上 span 个半音;同一个音取"离琴枕最近"的那根弦 */
      var span = I.span || 24, cand = [];
      for (k = 0; k < I.strings.length; k++) {
        for (i = 0; i <= span; i++) cand.push({ midi: I.strings[k] + i, off: i, si: k });
      }
      cand.sort(function (a, b) { return a.midi - b.midi || a.off - b.off; });
      var seen = {};
      for (i = 0; i < cand.length; i++) {
        if (seen[cand[i].midi] === 1) continue;
        seen[cand[i].midi] = 1;
        out.push({ midi: cand[i].midi, sub: bowTag(I, cand[i].si) });
      }
    } else if (ui === 'pads' || ui === 'bells') {
      var list = pscale(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9, 11]);
      for (i = 0; i < list.length; i++) {
        if (ui === 'bells') {
          /* 一钟双音:一口钟敲正鼓一个音、敲侧鼓高一个大三度 —— 两格都摆出来,谁都点得着 */
          out.push({ midi: list[i], sub: '正鼓' });
          out.push({ midi: list[i] + (I.padDual || 4), sub: '侧鼓' });
        } else {
          out.push({ midi: list[i], sub: digitOf(I, i) });
        }
      }
    } else if (ui === 'keys') {
      for (m = I.keysLo; m <= I.keysHi; m++) out.push({ midi: m, sub: '', black: isBlack(m) });
    } else if (ui === 'drum') {
      for (i = 0; i < I.pads.length; i++) out.push({ pad: i, name: I.pads[i].name, sub: '', metal: /锣|镲|钹|铃|三角/.test(I.pads[i].name) });
    }
    I.__pool = out;
    return out;
  }

  /* ============================================================
     二、排版:一屏摆几块、每块留几个音格
     ------------------------------------------------------------
     判据只有一条:**音格的宽与高都不小于 44**。在这条线以上的排法里,
     优先要"音多"(最多 12),同样多的时候要"格子形状好看"(高约是宽的 1.5 倍)。
     ============================================================ */

  function chooseGrid(sw, sh, poolLen) {
    var best = null, c, r;
    var cellW = Math.max(MIN_CELL, 44 * (parseFloat(getComputedStyle($('btnPlay')).fontSize) / 16));
    var maxCols = Math.max(2, Math.min(7, Math.floor((sw + GAPX) / (cellW + GAPX))));
    for (c = maxCols; c >= 2; c--) {
      var cw = (sw - GAPX * (c - 1)) / c;
      if (cw < cellW) continue;
      for (r = 1; r <= 3; r++) {
        var ch = (sh - GAPX * (r - 1)) / r;
        if (ch < MIN_CELL) continue;
        var notes = Math.min(c * r, 12, Math.max(poolLen, 1));
        var rows = Math.ceil(notes / c);
        var realH = (sh - GAPX * (rows - 1)) / rows;      /* 实际用几行,就得按几行验 */
        if (realH < MIN_CELL) continue;
        var score = -notes * 100 + Math.abs(realH / cw - 1.5) * 10;
        if (!best || score < best.score) best = { cols: c, rows: rows, notes: notes, score: score };
      }
    }
    if (!best) best = { cols: 2, rows: 1, notes: Math.min(2, poolLen), score: 0 };
    return best;
  }

  /** 这一屏上摆哪几个音:以音高(at)为锚,窗口在音位表上按"半屏一步"挪 */
  function windowOf(slot, pool, cap) {
    var n = pool.length;
    if (!n) return { items: [], lo: 0, total: 0, pos: 1, of: 1, canShift: false };
    if (n <= cap) return { items: pool.slice(), lo: 0, total: n, pos: 1, of: 1, canShift: false };
    var step = Math.max(1, Math.floor(cap / 2));
    var maxLo = n - cap;
    var stops = [0];
    while (stops[stops.length - 1] + step <= maxLo) stops.push(stops[stops.length - 1] + step);
    if (stops[stops.length - 1] !== maxLo) stops.push(maxLo);
    var lo = 0;
    if (slot.at != null && pool[0] && pool[0].midi != null) {
      var bi = 0, bd = 1e9;
      for (var i = 0; i < stops.length; i++) {
        var d = Math.abs(pool[stops[i]].midi - slot.at);
        if (d < bd) { bd = d; bi = i; }
      }
      lo = stops[bi];
    }
    return { items: pool.slice(lo, lo + cap), lo: lo, total: n, pos: stops.indexOf(lo) + 1, of: stops.length, canShift: true, stops: stops };
  }

  /* ============================================================
     三、把台面画出来
     ============================================================ */

  function renderBand() {
    var band = $('band'), wrap = $('wrap'), top = $('topCard'), nav = $('bandNav');
    if (!A) return;
    releaseTouches();
    var N = S.slots.length;
    clear(band);
    nav.hidden = N <= 4;
    if (!N) {
      var e = el('div', 'card');
      e.appendChild(el('div', 'empty', '点「乐器」添加，或点「合奏」选一套。'));
      band.appendChild(e);
      return;
    }
    var cs = window.getComputedStyle(wrap);
    var padY = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
    var avail = wrap.clientHeight - top.offsetHeight - padY - 8 - (nav.hidden ? 0 : nav.offsetHeight + 8);
    var largeText = parseFloat(getComputedStyle($('btnPlay')).fontSize) > 20;
    S.pageSize = avail >= 256 ? (largeText ? (N <= 3 ? 3 : 2) : 4) : (avail >= 204 ? 2 : 1);
    nav.hidden = N <= S.pageSize;
    if (!nav.hidden && N <= 4) avail -= nav.offsetHeight + 8;
    S.page = clamp(S.page, 0, Math.ceil(N / S.pageSize) - 1);
    var start = S.page * S.pageSize, count = Math.min(S.pageSize, N - start);
    var cols = count === 4 ? 2 : 1, rows = Math.ceil(count / cols);
    // 四件使用两列；保住乐器名、音区控制和音格的尺寸，更多乐器单独翻组。
    band.className = cols === 2 ? 'four' : '';
    band.style.gridTemplateColumns = 'repeat(' + cols + ',minmax(0,1fr))';
    var panelH = Math.floor((avail - GAPY * (rows - 1)) / rows);
    panelH = Math.max(cols === 2 ? 124 : MIN_PANEL, panelH);
    var shells = [];
    for (var i = start; i < start + count; i++) shells.push(buildPanel(i, panelH, 0));
    for (i = 0; i < shells.length; i++) paintPanel(shells[i], start + i);
    $('pageTxt').textContent = '第 ' + (S.page + 1) + ' / ' + Math.ceil(N / S.pageSize) + ' 组';
    $('pagePrev').disabled = S.page === 0;
    $('pageNext').disabled = start + count >= N;
    updateDock();
  }
  function changePage(dir) {
    var next = clamp(S.page + dir, 0, Math.ceil(S.slots.length / S.pageSize) - 1);
    if (next === S.page) return;
    S.page = next;
    renderBand();
  }

  function buildPanel(i, h, mode) {
    var slot = S.slots[i], I = instById(slot.id);
    var p = el('div', 'panel t-' + ((I && I.tint) || 'wood') + (mode ? (mode === 2 ? ' slim slim2' : ' slim') : ''));
    p.style.height = h + 'px';
    p.setAttribute('data-slot', i);
    var head = el('div', 'phead');
    head.appendChild(el('span', 'pname', (I && I.name) || slot.id));
    var rng = el('span', 'rng', '');
    head.appendChild(rng);
    var lo = null, hi = null;
    if (!mode) {
      lo = el('button', 'arb low', '低');
      lo.setAttribute('aria-label', '这一段音区往低音挪');
      lo.onclick = function () { shiftRange(i, -1); };
      hi = el('button', 'arb high', '高');
      hi.setAttribute('aria-label', '这一段音区往高音挪');
      hi.onclick = function () { shiftRange(i, 1); };
      head.appendChild(lo); head.appendChild(hi);
    }
    p.appendChild(head);
    var surf = el('div', 'surf');
    p.appendChild(surf);
    $('band').appendChild(p);
    return { el: p, surf: surf, head: head, rng: rng, lo: lo, hi: hi, h: h };
  }

  function paintPanel(sh, i) {
    var slot = S.slots[i], I = instById(slot.id);
    if (!I) return;
    var pool = poolOf(I);
    var sw = sh.surf.clientWidth - PAD * 2, shh = sh.surf.clientHeight - PAD * 2;
    if (sw < 80 || shh < 30) { sw = Math.max(sw, 80); shh = Math.max(shh, 30); }
    var g = chooseGrid(sw, shh, pool.length);
    /* 拉弦是**一条**按弦带(不折行):一条上摆得下几个半音就摆几个 */
    if (I.ui === 'bow') {
      g = { cols: Math.max(2, Math.min(7, Math.floor((sw + GAPX) / Math.max(48, 44 * parseFloat(getComputedStyle($('btnPlay')).fontSize) / 16 + GAPX)))), rows: 1, notes: 0 };
      g.notes = Math.min(g.cols, Math.max(pool.length, 1));
    }
    var w = windowOf(slot, pool, g.notes);
    slot.at = (pool[w.lo] && pool[w.lo].midi != null) ? pool[w.lo].midi : null;
    sh.rng.textContent = w.canShift ? ('音区 ' + w.pos + '/' + w.of) : '全部音';
    if (sh.lo) sh.lo.disabled = !w.canShift;
    if (sh.hi) sh.hi.disabled = !w.canShift;
    clear(sh.surf);
    sh.el.__items = w.items;

    if (I.ui === 'keys' || I.ui === 'zither' || I.ui === 'fret' || I.ui === 'pads' || I.ui === 'bells' || I.ui === 'drum') {
      var cells = el('div', 'cells');
      cells.style.gridTemplateColumns = 'repeat(' + g.cols + ',1fr)';
      cells.style.gridTemplateRows = 'repeat(' + g.rows + ',1fr)';
      sh.surf.appendChild(cells);
      for (var k = 0; k < w.items.length; k++) cells.appendChild(makeCell(I, w.items[k], k));
    } else {
      /* 拉弦:一整条按弦带(格格之间只有刻度线,手指一路拖过去就是滑音) */
      var band = el('div', 'band1');
      sh.surf.appendChild(band);
      for (k = 0; k < w.items.length; k++) band.appendChild(makeCell(I, w.items[k], k));
    }
    sh.surf.setAttribute('data-cells', String(w.items.length));
  }

  function makeCell(I, it, k) {
    var ui = I.ui, b = el('button', 'nt');
    b.setAttribute('data-k', String(k));
    if (ui === 'zither') {
      b.className = 'nt st' + (I.id === 'guzheng' || I.id === 'kalimba' ? ' metal' : '');
      b.appendChild(el('span', 'sub', it.sub));
      b.appendChild(el('span', 'wire'));
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      b.setAttribute('aria-label', I.name + ' ' + it.sub + ' ' + A.midiName(it.midi));
    } else if (ui === 'fret') {
      b.className = 'nt frt';
      b.appendChild(el('span', 'fl'));
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      b.appendChild(el('span', 'sub', it.sub));
      b.setAttribute('aria-label', I.name + ' ' + A.midiName(it.midi) + (it.sub === '空弦' ? ' 空弦' : ' ' + it.sub));
    } else if (ui === 'pads') {
      b.className = 'nt ' + (I.padShape === 'hole' ? 'pd' : 'frt');
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      if (it.sub) b.appendChild(el('span', 'sub', it.sub));
      b.setAttribute('aria-label', I.name + ' ' + A.midiName(it.midi));
    } else if (ui === 'bells') {
      b.className = 'nt bl';
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      b.appendChild(el('span', 'sub', it.sub));
      b.setAttribute('aria-label', I.name + ' ' + A.midiName(it.midi) + ' ' + it.sub);
    } else if (ui === 'keys') {
      b.className = 'nt ' + (it.black ? 'bk2' : 'wk2');
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      b.setAttribute('aria-label', (it.black ? '黑键 ' : '白键 ') + A.midiName(it.midi));
    } else if (ui === 'drum') {
      b.className = 'nt dr' + (it.metal ? ' metal' : '');
      b.appendChild(el('span', 'nm', it.name));
      b.setAttribute('aria-label', it.name);
    } else {
      b.className = 'nt bw';
      b.appendChild(el('span', 'tick'));
      b.appendChild(el('span', 'nm', A.midiName(it.midi)));
      b.appendChild(el('span', 'sub', it.sub || ''));
      b.setAttribute('aria-label', I.name + ' ' + A.midiName(it.midi) + (it.sub ? ' ' + it.sub : ''));
    }
    return b;
  }

  function shiftRange(i, dir) {
    var I = instById(S.slots[i].id);
    var pool = poolOf(I);
    var sh = panelShell(i);
    if (!sh) return;
    var g = chooseGrid(sh.surf.clientWidth - PAD * 2, sh.surf.clientHeight - PAD * 2, pool.length);
    var w = windowOf(S.slots[i], pool, g.notes);
    if (!w.canShift || !w.stops) return;
    var cur = w.stops.indexOf(w.lo), nxt = (cur + dir + w.stops.length) % w.stops.length;
    S.slots[i].at = pool[w.stops[nxt]].midi;
    releaseTouches();
    paintPanel(sh, i);
    saveBand();
    say(I.name + ' 换到第 ' + (nxt + 1) + ' / ' + w.stops.length + ' 段音区');
  }
  function panelShell(i) {
    var p = $('band').querySelector('[data-slot="' + i + '"]');
    if (!p) return null;
    return { el: p, surf: p.querySelector('.surf'), head: p.querySelector('.phead'),
      rng: p.querySelector('.rng'), lo: p.querySelector('.low'), hi: p.querySelector('.high'), h: p.offsetHeight };
  }

  /* ============================================================
     四、手指落在哪儿
     ============================================================ */

  function bindSurface() {
    var band = $('band');
    band.addEventListener('pointerdown', onDown);
    band.addEventListener('pointermove', onMove);
    band.addEventListener('pointerup', onUp);
    band.addEventListener('pointercancel', onUp);
    band.addEventListener('lostpointercapture', onUp);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    window.addEventListener('blur', suspend);
    window.addEventListener('pagehide', suspend);
    document.addEventListener('visibilitychange', function () { if (document.hidden) suspend(); });
    var drag = null, nav = $('bandNav');
    nav.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;
      drag = { id: e.pointerId, x: e.clientX, y: e.clientY };
      try { nav.setPointerCapture(e.pointerId); } catch (ex) { }
    });
    nav.addEventListener('pointerup', function (e) {
      if (!drag || drag.id !== e.pointerId) return;
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      drag = null;
      if (Math.abs(dx) >= 32 && Math.abs(dx) > Math.abs(dy)) changePage(dx < 0 ? 1 : -1);
    });
    nav.addEventListener('pointercancel', function () { drag = null; });
    nav.addEventListener('lostpointercapture', function () { drag = null; });
    var rt = 0;
    window.addEventListener('resize', function () {
      if (rt) clearTimeout(rt);
      rt = setTimeout(function () { rt = 0; renderBand(); }, 180);
    });
  }

  function cellOf(ev) {
    var node = document.elementFromPoint(ev.clientX, ev.clientY);
    if (!node || !node.closest) return null;
    var nt = node.closest('.nt');
    if (!nt) return null;
    var panel = nt.closest('.panel');
    if (!panel) return null;
    return { p: parseInt(panel.getAttribute('data-slot'), 10), k: parseInt(nt.getAttribute('data-k'), 10), el: nt };
  }

  /** 手指按在台面上的这几百毫秒里,页面不许自己滑走(与乐器盒同一手:被挪动就拉回来) */
  function pinPage() {
    var sc = $('wrap');
    if (!sc || S.pinRaf) return;
    S.pinTop = sc.scrollTop;
    S.pinRaf = requestAnimationFrame(pinStep);
  }
  function pinStep() {
    S.pinRaf = 0;
    var sc = $('wrap');
    if (!sc || S.touchN <= 0) return;
    if (sc.scrollTop !== S.pinTop) sc.scrollTop = S.pinTop;
    S.pinRaf = requestAnimationFrame(pinStep);
  }

  function onDown(ev) {
    var hit = cellOf(ev);
    if (!hit || sheetOpen() || active[ev.pointerId] || (ev.pointerType === 'mouse' && ev.button !== 0)) return;
    A.unlock();
    try { hit.el.closest('.surf').setPointerCapture(ev.pointerId); } catch (e) { }

    ev.preventDefault();
    var here = itemsOf(hit.p);
    if (!here || !here[hit.k]) return;
    var it = here[hit.k], I = instById(S.slots[hit.p].id);
    if (!I) return;
    S.touchN++;
    pinPage();
    var vel = 0.9;
    var voice = null;
    if (it.pad != null) A.hit(I, it.pad, vel);
    else voice = A.noteOn(I, it.midi, vel);
    hit.el.classList.add('lit');
    active[ev.pointerId] = { p: hit.p, k: hit.k, el: hit.el, voice: voice, midi: it.midi, y0: ev.clientY, capture: hit.el.closest('.surf') };
    recOn(hit.p, hit.k, it, ev.pointerId);
  }

  function onMove(ev) {
    var a = active[ev.pointerId];
    if (!a) return;
    ev.preventDefault();
    var hit = cellOf(ev);
    if (!hit) return;
    var I = instById(S.slots[a.p].id);
    if (!I) return;
    if (I.ui === 'bow') {
      var here = itemsOf(a.p);
      if (!here || !here[a.k]) return;
      if (hit.p !== a.p) return;                        /* 一条带子上拖,不跨乐器 */
      if (stateSnap() && hit.k !== a.k && here[hit.k]) {
        /* 音阶档:按半音一格一格走 —— 上一个音收掉、新的音响起来 */
        if (a.voice) { try { a.voice.release(); } catch (e) { } }
        recOff(a.p, a.k, ev.pointerId);
        var nv = A.noteOn(I, here[hit.k].midi, 0.9);
        a.voice = nv; a.k = hit.k; a.midi = here[hit.k].midi;
        var oldEl = a.el; a.el = hit.el; unlight(oldEl); a.el.classList.add('lit');
        recOn(a.p, a.k, here[hit.k], ev.pointerId);
      } else if (!stateSnap()) {
        /* 滑音档:手指拖到哪儿滑到哪儿(频率连续的,不做半音对齐) */
        var bandEl = hit.el.closest('.band1');
        if (bandEl && a.voice && a.voice.glide) {
          var r = (ev.clientX - bandEl.getBoundingClientRect().left) / bandEl.getBoundingClientRect().width;
          var items = itemsOf(a.p);
          var m0 = items[0].midi, m1 = items[items.length - 1].midi;
          a.voice.glide(m0 + clamp(r, 0, 1) * (m1 - m0));
        }
      }
      /* 音高没动、手指上下抖 —— 那就是揉弦(左手的事) */
      var dy = ev.clientY - a.y0;
      if (a.voice && a.voice.vib && Math.abs(dy) > 8) a.voice.vib(clamp(Math.abs(dy) / 55, 0, 1) * 40);
      return;
    }
    if (hit.p !== a.p || hit.k === a.k) return;
    /* 弦与格子:手指划过去 = 一串音(刮奏 / 扫弦) */
    var list = itemsOf(a.p);
    if (!list || !list[hit.k]) return;
    if (a.voice) { try { a.voice.release(); } catch (e) { } }
    recOff(a.p, a.k, ev.pointerId);
    var it = list[hit.k];
    var v = null;
    if (it.pad != null) A.hit(I, it.pad, 0.8);
    else v = A.noteOn(I, it.midi, 0.8);
    a.voice = v; a.k = hit.k; a.midi = it.midi;
    var oldEl = a.el; a.el = hit.el; unlight(oldEl); a.el.classList.add('lit');
    recOn(a.p, hit.k, it, ev.pointerId);
  }

  function onUp(ev) {
    var a = active[ev.pointerId];
    if (!a) return;
    if (ev.type === 'pointerup') A.unlock();
    delete active[ev.pointerId];
    try { if (a.capture && a.capture.hasPointerCapture(Number(ev.pointerId))) a.capture.releasePointerCapture(Number(ev.pointerId)); } catch (ex) { }
    S.touchN = Object.keys(active).length;
    if (a.voice) { try { a.voice.release(); } catch (e) { } }
    recOff(a.p, a.k, ev.pointerId);
    unlight(a.el);
    if (!S.touchN && S.pinRaf) { cancelAnimationFrame(S.pinRaf); S.pinRaf = 0; }
  }
  function unlight(node) {
    for (var id in active) if (active[id].el === node) return;
    if (node) node.classList.remove('lit');
  }
  function releaseTouches() {
    Object.keys(active).forEach(function (id) { onUp({ pointerId: id }); });
  }
  function suspend() {
    releaseTouches();
    if (S.rec) stopRec();
    stopLoop();
    if (S.warmT) { clearTimeout(S.warmT); S.warmT = 0; S.warmKey = ''; }
  }
  function itemsOf(p) {
    var sh = panelShell(p);
    return sh ? sh.el.__items : null;
  }
  function flash(node) {
    if (!node) return;
    node.classList.add('lit');
    setTimeout(function () { node.classList.remove('lit'); }, 220);
  }
  function stateSnap() { return S.snap; }

  /* ============================================================
     五、录音与回放(一层一层往上叠)
     ============================================================ */

  function barSec() { return 60 / S.bpm * 4; }
  function quantSec() { return 60 / S.bpm / 2; }        /* 八分音符 */

  function recOn(p, k, it, pointerId) {
    if (!S.rec || !S.armed) return;
    var t = A.now() - S.recT0;
    if (t < 0) return;                                  /* 还在预备拍里 */
    var key = String(pointerId);
    if (S.recHold[key]) recOff(p, k, pointerId);
    var ev = { t: t, inst: S.slots[p].id, vol: 0.9, dur: 0 };
    if (it.pad != null) ev.pad = it.pad; else ev.midi = it.midi;
    if (!S.recFrom) S.recFrom = S.slots[p].id;      /* 这一层主要录的是哪一件 */
    S.recHold[key] = ev;
    S.recList.push(ev);
    if (S.recList.length > MAX_EV) { S.recList.length = MAX_EV; }
  }
  function recOff(p, k, pointerId) {
    var key = String(pointerId), ev = S.recHold[key];
    if (!ev) return;
    ev.dur = Math.max(0, A.now() - S.recT0 - ev.t);
    delete S.recHold[key];
  }

  function toggleRec() {
    A.unlock();
    if (S.rec) { stopRec(); return; }
    if (!S.slots.length) { say('先往台上放一件乐器'); return; }
    var L = S.layers[S.sel];
    if (L && L.evs.length) {
      if (!window.confirm('第 ' + (S.sel + 1) + ' 层已经有 ' + L.evs.length + ' 个音了,重录会盖掉这一层。接着录?')) return;
    }
    S.rec = true; S.armed = false; S.recList = []; S.recHold = {};
    if (!S.playing) startLoop();
    /* 录进哪一层:这一遍主要弹的是哪一件,那一层就记它 */
    S.recFrom = null;
    var beat = 60 / S.bpm, bar = barSec();
    var el0 = A.now() - S.loopT0;
    var k = Math.ceil((el0 + (S.prep ? 4 * beat : 0)) / bar);      /* 保证数拍都落在将来 */
    var nextBar = S.loopT0 + Math.max(1, k) * bar;
    var startAt;
    if (!S.prep) {
      /* 不数拍:下一个拍头就开录(录完之后这一段会按相位对回圈里) */
      startAt = S.loopT0 + (Math.floor(el0 / beat) + 1) * beat;
      if (startAt < A.now() - 0.02) startAt = A.now() + 0.03;
    } else {
      startAt = nextBar;
      S.countTicks = [];
      for (var i = 4; i >= 1; i--) {
        var tt = nextBar - i * beat;
        if (tt >= A.now() - 0.005) S.countTicks.push(A.tick(i === 4, Math.max(0.001, tt)));
      }
    }
    S.recT0 = startAt;
    if (S.takeTimer) clearInterval(S.takeTimer);
    S.takeTimer = setInterval(saveTakeSnap, 1500);
    var wait = Math.max(0, (startAt - A.now()) * 1000);
    S.countTimer = setTimeout(function () {
      S.countTimer = 0;
      S.armed = true;
      say(S.prep ? '开始录第 ' + (S.sel + 1) + ' 层' : '录着呢');
    }, wait);
    if (S.prep) say('听四下打拍,第四下之后开始弹');
    updateDock();
  }

  /* 把一遍录音按相位对回圈里、量化到八分音符 —— 收录用它,捡回没收尾的那一遍也用它 */
  function quantizeTake(raw, phase, bpm, loopSec) {
    var q = 60 / bpm / 2;
    var evs = raw.slice().sort(function (a, b) { return a.t - b.t; });
    var out = [], maxT = 0, i;
    var ph = phase - Math.floor(phase / loopSec) * loopSec;
    for (i = 0; i < evs.length; i++) {
      var e = evs[i];
      var st = round(Math.round(e.t / q) * q + ph, 4);
      var dur = Math.max(q, Math.round(Math.max(e.dur, q / 2) / q) * q);
      if (st >= loopSec) st = round(st - loopSec, 4);          /* 跨过圈尾的音回到圈头,该响的时候还是会响 */
      var o = { t: st, inst: e.inst, vel: 0.9, dur: round(dur, 4) };
      if (e.pad != null) o.pad = e.pad; else o.midi = e.midi;
      out.push(o);
      if (st + dur > maxT) maxT = st + dur;
    }
    return { evs: out, maxT: maxT };
  }

  function stopRec() {
    S.rec = false; S.armed = false;
    if (S.countTimer) { clearTimeout(S.countTimer); S.countTimer = 0; }
    if (S.takeTimer) { clearInterval(S.takeTimer); S.takeTimer = 0; }
    /* 还没响的那几下预备拍,收掉 —— 都停录了还嗒嗒响三下就不像话了 */
    if (S.countTicks) {
      for (var ci = 0; ci < S.countTicks.length; ci++) {
        if (S.countTicks[ci] && S.countTicks[ci].stop) { try { S.countTicks[ci].stop(); } catch (e) { } }
      }
      S.countTicks = null;
    }
    for (var key in S.recHold) if (S.recHold.hasOwnProperty(key)) {
      recOff(0, 0, key);
    }
    updateDock();
    if (!S.recList.length) { say('这一遍没录到音'); clearTakeSnap(); return; }
    var bar = barSec();
    var firstTake = !S.barsSet;
    var loopSec = (firstTake ? MAX_BARS : Math.max(1, S.loopBars)) * bar;
    /* 开录那一下不一定落在小节头上(不数四拍时就是随便一拍),所以录完把它按相位对回圈里:
       这样第二层、第三层永远和第一层的拍子对得齐。 */
    var qd = quantizeTake(S.recList, firstTake ? 0 : S.recT0 - S.loopT0, S.bpm, loopSec);
    var i;
    if (!S.barsSet) { S.loopBars = clamp(Math.ceil(qd.maxT / bar), 1, MAX_BARS); S.barsSet = true; }
    var limit = S.loopBars * bar, cut = 0, keep = [];
    for (i = 0; i < qd.evs.length; i++) {
      if (qd.evs[i].t >= limit - 0.001) { cut++; continue; }
      keep.push(qd.evs[i]);
    }
    if (!keep.length) { say('这一遍没录到音'); clearTakeSnap(); return; }
    var L = { inst: (S.recFrom || keep[0].inst), evs: keep, vol: 1, mute: false, bars: S.loopBars };
    S.layers[S.sel] = L;
    if (firstTake && S.playing) { stopLoop(); startLoop(); }
    else kickWarm();
    clearTakeSnap();
    saveBand();
    renderDockLayers();
    ping();
    say('第 ' + (S.sel + 1) + ' 层录好了:' + keep.length + ' 个音' + (cut ? '(圈长 ' + S.loopBars + ' 小节,超出的 ' + cut + ' 个音被切了)' : ''));
    /* 录完自动跳到下一个空层,免得连录音时又盖同一层 */
    for (i = 0; i < MAX_LAYER; i++) {
      var j = (S.sel + 1 + i) % MAX_LAYER;
      if (!S.layers[j] || !S.layers[j].evs.length) { S.sel = j; break; }
    }
    renderDockLayers();
  }

  function startLoop() {
    A.unlock();
    if (!S.playing) {
      S.playing = true;
      S.loopT0 = A.now() + 0.12;
      S.nextT = S.loopT0;
      S.loopSec = Math.max(1, S.loopBars) * barSec();
      /* 记下这一遍排音时"已经乘进力度的"那一份(轨上的目标要按它折算) */
      S.layers.forEach(function (L) { if (L) L.schedVol = layerWanted(L); });
      kickWarm();                      /* 还没算完的话,趁这一下接着算(不挡起播) */
      if (S.timer) clearInterval(S.timer);
      S.timer = setInterval(pump, 40);
      pump();
      updateDock();
    }
  }

  /* ---------- 预算音色:把这几层里要用的拨弦缓冲先算出来 ----------
     拨弦是按物理弦模型**现算**缓冲的(一颗 3 秒的弦要跑十几万格采样,手机上要几毫秒)。
     八件乐器一起回放时,这一串会挤在起播那一下 —— 主线程被堵住,音频欠载,
     听感是一串"沙拉沙拉"。所以分片先算完(每片 12ms,不挡界面)。
     没算到的音退回现算现响,只是老样子 —— 算不完不影响能用。 */
  function kickWarm() {
    if (!A || !A.warm || !S.layers) return;
    var jobs = [], sig = [], seen = {}, i, j;
    for (i = 0; i < S.layers.length; i++) {
      var L = S.layers[i];
      if (!L || !L.evs.length) continue;
      var inst = instById(L.inst);
      for (j = 0; j < L.evs.length; j++) {
        var ev = L.evs[j];
        if (ev.pad != null) continue;                   /* 打击不走缓冲 */
        var I2 = instById(ev.inst);
        if (!I2) continue;
        var id = ev.inst + ":" + ev.midi + ":" + ev.dur;
        if (seen[id]) continue;
        seen[id] = true; sig.push(id);
        jobs.push([I2, ev.midi, ev.dur, 0.9]);
      }

    }
    var key = sig.join(',');
    if (!jobs.length || S.warmKey === key) return;
    S.warmKey = key;
    if (S.warmT) { clearTimeout(S.warmT); S.warmT = 0; }
    var idx = 0;
    function slice() {
      S.warmT = 0;
      if (S.warmKey !== key) return;                    /* 层变了,这一趟作废 */
      var t0 = Date.now();
      while (idx < jobs.length && Date.now() - t0 < 12) {
        var j2 = jobs[idx++];
        try { A.warm(j2[0], j2[1], j2[2], j2[3], null); } catch (e) { return; }
      }
      if (idx < jobs.length) S.warmT = setTimeout(slice, 0);
    }
    S.warmT = setTimeout(slice, 0);
  }
  function stopLoop() {
    releaseTouches();
    S.playing = false;
    if (S.timer) { clearInterval(S.timer); S.timer = 0; }
    A.stopAll();
    updateDock();
  }
  /* 每层一条自己的增益轨 —— 但**轨的底子是 1**,音量在排音那一趟乘进力度。
     理由与乐谱播放里那一段同一份(引擎按力度分档改激励亮度与阻尼,力度抬一档音色就变硬):
     1.0.0 是 `0.9 * L.vol`;2.0.0 一度改成"音量上轨、力度原样 0.9",于是音色变亮变炸。
     现在两边都留:排音照旧乘进去(音色与旧版一致),轨只做运行中调音量/静音的振幅变化。 */
  function layerWanted(L) { return L.mute ? 0 : clamp(L.vol == null ? 1 : L.vol, 0, 1); }
  function layerBusGain(L) { return layerWanted(L); }
  function layerBus(L) {
    if (!L || !A || !A.bus) return null;
    if (!L.bus) {
      try { L.bus = A.bus(layerBusGain(L)); } catch (e) { L.bus = null; }
    }
    return L.bus;
  }
  /** v = 期望的总增益(0~1);轨上乘的是它**除掉排音时已经乘进力度的**那一份 */
  function layerVolTo(L, v) {
    var b = layerBus(L), g = clamp(v, 0, 4);
    if (b) { try { b.gain.setTargetAtTime(g, A.now(), 0.05); } catch (e) { b.gain.value = g; } }
  }
  function pump() {
    if (!S.playing) return;
    var now = A.now(), ahead = now + 0.35;
    var from = Math.max(S.nextT, now - 0.005);
    if (from >= ahead) return;
    // 只排前方350ms里的音；长圈与多层不再在同一拍生成整圈节点。
    var first = Math.max(0, Math.floor((from - S.loopT0) / S.loopSec));
    var last = Math.max(first, Math.floor((ahead - S.loopT0) / S.loopSec));
    for (var cycle = first; cycle <= last; cycle++) {
      var base = S.loopT0 + cycle * S.loopSec;
      for (var i = 0; i < S.layers.length; i++) {
        var L = S.layers[i];
        if (!L || !L.evs.length) continue;
        if (L.mute) { layerVolTo(L, 0); continue; }
        var dst = layerBus(L);
        for (var j = 0; j < L.evs.length; j++) {
          var ev = L.evs[j], t = base + ev.t;
          if (t < from || t >= ahead) continue;
          var inst = instById(ev.inst);
          if (!inst) continue;
          if (ev.pad != null) A.hit(inst, ev.pad, 0.9, t, dst);
          else A.noteOn(inst, ev.midi, 0.9, t, ev.dur, null, dst);
        }
      }
      if (S.click) {
        var beat = 60 / S.bpm;
        for (i = 0; i < Math.max(1, S.loopBars) * 4; i++) {
          var tt = base + i * beat;
          if (tt >= from && tt < ahead) A.tick(i % 4 === 0, tt);
        }
      }
    }
    S.nextT = ahead;
  }
  function setBpm(v) {
    v = clamp(Math.round(v), 40, 180);
    if (v === S.bpm) return;
    var wasPlaying = S.playing, ratio = S.bpm / v;
    releaseTouches();
    if (S.rec) stopRec();
    if (wasPlaying) stopLoop();
    S.layers.forEach(function (L) {
      if (L) L.evs.forEach(function (e) { e.t *= ratio; e.dur *= ratio; });
    });
    S.bpm = v;
    if ($('bpm')) $('bpm').value = S.bpm;
    paintRange($('bpm'));
    if ($('bpmTxt')) $('bpmTxt').textContent = S.bpm + ' BPM';
    if ($('bpmTxt2')) $('bpmTxt2').textContent = S.bpm + ' BPM';
    if (wasPlaying) startLoop();
    saveBand();
  }
  function paintRange(e) {
    if (!e) return;
    var lo = parseFloat(e.min || '0'), hi = parseFloat(e.max || '100'), v = parseFloat(e.value || '0');
    e.style.setProperty('--p', hi > lo ? Math.round((v - lo) / (hi - lo) * 100) : 0);
  }

  /* ============================================================
     六、下边那条工具条
     ============================================================ */

  function updateDock() {
    var b = $('btnPlay'), r = $('btnRec');
    b.textContent = S.playing ? '停止' : '播放';
    b.className = 'dbtn' + (S.playing ? ' on' : '');
    b.setAttribute('aria-label', S.playing ? '停止各层回放' : '开始回放各层');
    r.textContent = S.rec ? '停止' : '录制';
    r.className = 'dbtn rec' + (S.rec ? ' on' : '');
    r.setAttribute('aria-label', S.rec ? '停止录音' : '录一层');
    $('btnClick').className = 'dbtn' + (S.click ? ' on' : '');
    $('btnClick').setAttribute('aria-label', '打拍开关,现在是' + (S.click ? '开' : '关'));
    if ($('bpmTxt')) $('bpmTxt').textContent = S.bpm + ' BPM';
  }

  function renderDockLayers() {
    var box = $('layerRow');
    clear(box);
    for (var i = 0; i < MAX_LAYER; i++) {
      (function (i) {
        var L = S.layers[i];
        var has = !!(L && L.evs.length);
        var name = has ? (instById(L.inst) ? instById(L.inst).name : '有音') : '空';
        if (has && L.mute) name = '静音';
        var b = el('button', 'lchip' + (has ? ' has' : '') + (S.sel === i ? ' on' : ''));
        b.appendChild(el('span', 'n', String(i + 1)));
        b.appendChild(el('span', null, name));
        b.setAttribute('aria-label', '第 ' + (i + 1) + ' 层,现在' + name + (S.sel === i ? ',录进来的音进这一层' : ''));
        b.onclick = function () { openLayer(i); };
        box.appendChild(b);
      })(i);
    }
  }

  function openLayer(i) {
    releaseTouches();
    if (S.rec) stopRec();
    S.sel = i;
    renderDockLayers();
    var L = S.layers[i];
    var box = $('layInfo');
    clear(box);
    $('layTitle').textContent = '第 ' + (i + 1) + ' 层';
    function row(t1, t2) {
      var r = el('div', 'row'), g = el('div', 'grow');
      g.appendChild(el('div', 't1', t1));
      if (t2) g.appendChild(el('div', 't2', t2));
      r.appendChild(g);
      box.appendChild(r);
    }
    if (!L || !L.evs.length) {
      row('这一层还是空的', '关掉这个面板,点「录制」就录进这一层。');
    } else {
      row('乐器:' + (instById(L.inst) ? instById(L.inst).name : '已不在台上'),
        L.evs.length + ' 个音 · 圈长 ' + (S.loopBars || L.bars) + ' 小节 · ' + S.bpm + ' BPM');
      row('这一次录进来就进这一层', '点「录制」,听四下打拍就可以弹了。');
    }
    var vol = L && L.vol != null ? Math.round(L.vol * 100) : 100;
    $('layVol').value = vol;
    $('layVolTxt').textContent = vol + '%';
    paintRange($('layVol'));
    $('layMute').className = (L && L.mute) ? 'on' : '';
    $('layMute').textContent = (L && L.mute) ? '已静音' : '静音';
    $('layVol').disabled = !(L && L.evs.length);
    openSheet('sheetLay', '第 ' + (i + 1) + ' 层');
  }

  /* ============================================================
     七、抽屉:预设 / 合奏 / 换乐器 / 高级 / 这样玩
     ============================================================ */

  function openSheet(id, title) {
    releaseTouches();
    closeSheets();
    $('mask').className = 'mask on';
    $(id).className = 'sheet on';
    if (jh() && JH.setTitle) JH.setTitle(title).catch(jc('setTitle'));
  }
  var SHEETS = ['sheetHow', 'sheetBand', 'sheetPick', 'sheetLay', 'sheetAdv'];
  function closeSheets() {
    $('mask').className = 'mask';
    for (var i = 0; i < SHEETS.length; i++) $(SHEETS[i]).className = 'sheet';
    if (jh() && JH.setTitle) JH.setTitle('超级乐器').catch(jc('setTitle'));
  }
  function sheetOpen() { return $('mask').className.indexOf('on') >= 0; }

  /* ---- 预设 ---- */
  function renderPresets() {
    var box = $('preChips');
    clear(box);
    PRESETS.forEach(function (p, i) {
      var b = el('button', 'pc' + (sameAs(p) ? ' on' : ''), p.name);
      b.setAttribute('aria-label', '用「' + p.name + '」这套合奏');
      b.onclick = function () { applyPreset(p.slots, p.name); };
      box.appendChild(b);
    });
    var list = $('preList');
    clear(list);
    if (!S.userPresets || !S.userPresets.length) {
      list.appendChild(el('div', 'empty', '还没有自己存的。台上摆好之后点右上「存下现在这一套」。'));
      return;
    }
    S.userPresets.forEach(function (p, i) {
      var r = el('div', 'row'), g = el('div', 'grow');
      g.appendChild(el('div', 't1', p.name));
      g.appendChild(el('div', 't2', (p.slots || []).map(function (s) {
        var I = instById(s.id);
        return I ? I.name : s.id;
      }).join(' + ') || '空的'));
      var acts = el('div', 'acts');
      var bu = el('button', 'w', '用');
      bu.setAttribute('aria-label', '用「' + p.name + '」这套');
      bu.onclick = function () { applyPreset(p.slots, p.name); };
      var bd = el('button', 'danger', '删');
      bd.setAttribute('aria-label', '删掉「' + p.name + '」');
      bd.onclick = function () {
        if (!window.confirm('删掉「' + p.name + '」这一套?')) return;
        S.userPresets.splice(i, 1);
        savePresets();
        renderPresets();
        say('删掉了');
      };
      acts.appendChild(bu); acts.appendChild(bd);
      r.appendChild(g); r.appendChild(acts);
      list.appendChild(r);
    });
  }
  function sameAs(p) {
    if (!p.slots || p.slots.length !== S.slots.length) return false;
    for (var i = 0; i < p.slots.length; i++) {
      if (p.slots[i].id !== S.slots[i].id) return false;
      if ((p.slots[i].at == null) !== (S.slots[i].at == null)) return false;
      if (p.slots[i].at != null && Math.abs(p.slots[i].at - S.slots[i].at) > 6) return false;
    }
    return true;
  }
  function applyPreset(slots, name) {
    var out = [];
    for (var i = 0; i < slots.length && out.length < MAX_SLOT; i++) {
      if (!instById(slots[i].id)) continue;
      out.push({ id: slots[i].id, at: slots[i].at == null ? null : slots[i].at });
    }
    if (!out.length) { say('这一套里的乐器都不认识了'); return; }
    releaseTouches();
    stopRecIfAny();
    S.page = 0;
    S.slots = out;
    saveBand();
    renderBand();
    renderBandSheet();
    closeSheets();
    say('换到「' + name + '」了:' + out.length + ' 件乐器');
  }
  function savePresets() {
    if (!jh() || !JH.storage) return;
    JH.storage.set(K_PRE, JSON.stringify(S.userPresets || [])).catch(jc('storage.set'));
  }

  /* ---- 合奏(台上这几件) ---- */
  function renderBandSheet() {
    renderPresets();
    var box = $('bandList');
    clear(box);
    if (!S.slots.length) {
      box.appendChild(el('div', 'empty', '台上还没有乐器。点「换乐器」挑一件。'));
    }
    S.slots.forEach(function (s, i) {
      var I = instById(s.id);
      var r = el('div', 'row'), g = el('div', 'grow');
      g.appendChild(el('div', 't1', (I ? I.name : s.id) + (i === 0 ? '(最上面)' : '')));
      var sh = panelShell(i);
      var info = '';
      if (sh) {
        var pool = poolOf(I);
        var gr = chooseGrid(sh.surf.clientWidth - PAD * 2, sh.surf.clientHeight - PAD * 2, pool.length);
        var w = windowOf(s, pool, gr.notes);
        info = '这一屏 ' + w.items.length + ' 个音';
        if (w.canShift) info += ' · 音区 ' + w.pos + '/' + w.of;
      }
      g.appendChild(el('div', 't2', info));
      var acts = el('div', 'acts');
      if (info.indexOf('音区') >= 0) {
        /* 音区也能在这里挪 —— 台上挤到七件以上时,面板抬头收窄,那两颗钮就在这儿 */
        var rl = el('button', null, '‹');
        rl.setAttribute('aria-label', '把' + (I ? I.name : '这一件') + '的音区往低音挪一段');
        rl.onclick = function (i) { return function () { shiftFromSheet(i, -1); }; }(i);
        var rr = el('button', null, '›');
        rr.setAttribute('aria-label', '把' + (I ? I.name : '这一件') + '的音区往高音挪一段');
        rr.onclick = function (i) { return function () { shiftFromSheet(i, 1); }; }(i);
        acts.appendChild(rl); acts.appendChild(rr);
      }
      var up = el('button', null, '↑');
      up.setAttribute('aria-label', '把' + (I ? I.name : '') + '往上挪一位');
      up.onclick = function () { moveSlot(i, -1); };
      var dn = el('button', null, '↓');
      dn.setAttribute('aria-label', '把' + (I ? I.name : '') + '往下挪一位');
      dn.onclick = function () { moveSlot(i, 1); };
      var del = el('button', 'danger', '−');
      del.setAttribute('aria-label', '把' + (I ? I.name : '') + '从台上拿下来');
      del.onclick = function () { removeSlot(i); };
      acts.appendChild(up); acts.appendChild(dn); acts.appendChild(del);
      r.appendChild(g); r.appendChild(acts);
      box.appendChild(r);
    });
    $('bandNote').textContent = S.slots.length >= MAX_SLOT
      ? '已经八件了,台上最多就八件。想再加,先拿下一件。'
      : '台上现在 ' + S.slots.length + ' 件,还能再加 ' + (MAX_SLOT - S.slots.length) + ' 件。';
  }
  function moveSlot(i, d) {
    var j = i + d;
    if (j < 0 || j >= S.slots.length) return;
    releaseTouches(); stopRecIfAny();
    var t = S.slots[i]; S.slots[i] = S.slots[j]; S.slots[j] = t;
    saveBand(); renderBand(); renderBandSheet();
  }
  /** 在「合奏」里挪音区:挪完把那一页的读数也刷新一遍 */
  function shiftFromSheet(i, d) {
    shiftRange(i, d);
    renderBandSheet();
  }
  function removeSlot(i) {
    releaseTouches(); stopRecIfAny();
    var I = instById(S.slots[i].id);
    S.slots.splice(i, 1);
    if (!S.slots.length) { stopLoop(); stopRecIfAny(); }
    saveBand(); renderBand(); renderBandSheet();
    say('把' + (I ? I.name : '这一件') + '拿下来了');
  }
  function addSlot(id) {
    if (S.slots.length >= MAX_SLOT) { say('台上最多八件,先拿下一件再加'); return false; }
    var I = instById(id);
    if (!I) return false;
    releaseTouches(); stopRecIfAny();
    S.slots.push({ id: id, at: null });
    S.page = Math.floor((S.slots.length - 1) / S.pageSize);
    touchRecent(id);
    saveBand();
    renderBand();
    renderBandSheet();
    if (sheetOf('sheetPick')) renderPicker();
    say('加上' + I.name + '了');
    return true;
  }
  function stopRecIfAny() { if (S.rec) stopRec(); }

  /* ---- 换乐器 ---- */
  var TILE_SVG = {
    '弹拨': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="11" y="6" width="26" height="36" rx="9" fill="rgba(255,255,255,.16)"/>' +
      '<path d="M18 9v30M24 9v30M30 9v30" stroke="rgba(255,255,255,.95)" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M14 30l20-7" stroke="rgba(255,255,255,.75)" stroke-width="2" stroke-linecap="round"/></svg>',
    '拉弦': '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 8v32" stroke="rgba(255,255,255,.95)" stroke-width="3" stroke-linecap="round"/>' +
      '<path d="M21 10v28M27 10v28" stroke="rgba(255,255,255,.6)" stroke-width="1.2"/>' +
      '<path d="M12 34c6-10 18-14 26-16" stroke="rgba(255,255,255,.9)" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>',
    '吹管': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="20" y="6" width="8" height="36" rx="4" fill="rgba(255,255,255,.22)" stroke="rgba(255,255,255,.75)" stroke-width="1.4"/>' +
      '<circle cx="24" cy="16" r="2.2" fill="#fff"/><circle cx="24" cy="24" r="2.2" fill="#fff"/>' +
      '<circle cx="24" cy="32" r="2.2" fill="#fff"/></svg>',
    '键盘': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="7" y="14" width="34" height="20" rx="3" fill="#fff"/>' +
      '<rect x="15" y="14" width="5" height="12" rx="1.4" fill="#26262C"/><rect x="25" y="14" width="5" height="12" rx="1.4" fill="#26262C"/>' +
      '<rect x="35" y="14" width="5" height="12" rx="1.4" fill="#26262C"/></svg>',
    '打击': '<svg viewBox="0 0 48 48" aria-hidden="true"><ellipse cx="24" cy="22" rx="15" ry="13" fill="#fff"/>' +
      '<path d="M11 30c8 5 18 5 26 0" stroke="rgba(0,0,0,.28)" stroke-width="2" fill="none"/>' +
      '<path d="M30 8l9-5" stroke="rgba(255,255,255,.9)" stroke-width="2.2" stroke-linecap="round"/></svg>'
  };
  function sheetOf(id) { return $(id).className.indexOf('on') >= 0; }

  function renderPicker() {
    var seg = $('famSeg');
    clear(seg);
    var fams = A.families;
    if (!S.fam) S.fam = fams[0];
    fams.forEach(function (f) {
      var b = el('button', S.fam === f ? 'on' : '', f);
      b.setAttribute('aria-label', '看' + f + '这一族');
      b.onclick = function () { S.fam = f; renderPicker(); };
      seg.appendChild(b);
    });
    var counts = {};
    S.slots.forEach(function (s) { counts[s.id] = (counts[s.id] || 0) + 1; });
    var rec = $('recentRow');
    clear(rec);
    var shown = 0;
    var seen = {};
    (S.recent || []).forEach(function (id) {
      if (shown >= 4 || seen[id]) return;
      var I = instById(id);
      if (!I) return;
      seen[id] = 1; shown++;
      rec.appendChild(tile(I, counts[id] || 0));
    });
    rec.hidden = shown === 0;
    var grid = $('instGrid');
    clear(grid);
    A.instruments.forEach(function (I) {
      if (I.fam !== S.fam) return;
      grid.appendChild(tile(I, counts[I.id] || 0));
    });
  }
  function tile(I, n) {
    var t = el('button', 'tile');
    var ico = el('div', 'ico i-' + (I.tint || 'wood'));
    ico.innerHTML = TILE_SVG[I.fam] || TILE_SVG['弹拨'];
    if (n) ico.appendChild(el('span', 'num', '×' + n));
    t.appendChild(ico);
    t.appendChild(el('div', 'nm', I.name));
    t.setAttribute('aria-label', (n ? '再加一件' : '加上') + I.name + (n ? '(台上已有 ' + n + ' 件)' : ''));
    t.onclick = function () { addSlot(I.id); };
    return t;
  }
  function touchRecent(id) {
    var a = (S.recent || []).filter(function (x) { return x !== id; });
    a.unshift(id);
    S.recent = a.slice(0, 4);
    if (jh() && JH.storage) JH.storage.set(K_RECENT, JSON.stringify(S.recent)).catch(jc('storage.set'));
  }

  /* ---- 高级 ---- */
  function renderAdv() {
    $('vol').value = Math.round(S.vol * 100);
    $('volTxt').textContent = Math.round(S.vol * 100) + '%';
    paintRange($('vol'));
    $('wet').value = Math.round(S.wet * 100);
    $('wetTxt').textContent = S.wet < 0.08 ? '关' : S.wet < 0.22 ? '少' : S.wet < 0.4 ? '中' : '多';
    paintRange($('wet'));
    $('bpm').value = S.bpm;
    $('bpmTxt2').textContent = S.bpm + ' BPM';
    paintRange($('bpm'));
    $('click2').className = S.click ? 'on' : '';
    $('click2').textContent = '打拍:' + (S.click ? '开' : '关');
    $('prepBtn').className = S.prep ? 'on' : '';
    $('prepBtn').textContent = '录音前先数四拍:' + (S.prep ? '开' : '关');
    $('snapOn').className = S.snap ? 'on' : '';
    $('snapOff').className = S.snap ? '' : 'on';
    $('snapTxt').textContent = S.snap ? '音阶' : '滑音';
    var box = $('advLayers');
    clear(box);
    var any = false;
    for (var i = 0; i < MAX_LAYER; i++) {
      var L = S.layers[i];
      var r = el('div', 'row'), g = el('div', 'grow');
      var has = !!(L && L.evs.length);
      if (has) any = true;
      g.appendChild(el('div', 't1', '第 ' + (i + 1) + ' 层:' + (has ? (instById(L.inst) ? instById(L.inst).name : '有音') : '空')));
      g.appendChild(el('div', 't2', has ? (L.evs.length + ' 个音' + (L.mute ? ' · 静音' : '')) : '点下面工具条上的第 ' + (i + 1) + ' 格,录进去的音就进这一层'));
      var acts = el('div', 'acts');
      if (has) {
        var bm = el('button', null, L.mute ? '响' : '静');
        bm.setAttribute('aria-label', '第 ' + (i + 1) + ' 层' + (L.mute ? '取消静音' : '静音'));
        bm.onclick = function (i, L) {
          return function () { L.mute = !L.mute; saveBand(); renderAdv(); renderDockLayers(); say(L.mute ? '这一层不响了' : '这一层又响了'); };
        }(i, L);
        var bd = el('button', 'danger', '清');
        bd.setAttribute('aria-label', '清空第 ' + (i + 1) + ' 层');
        bd.onclick = function (i) {
          return function () { clearLayer(i); };
        }(i);
        acts.appendChild(bm); acts.appendChild(bd);
      }
      r.appendChild(g); r.appendChild(acts);
      box.appendChild(r);
    }
    if (!any) box.appendChild(el('div', 'empty', '四层都还空着。点「录制」弹一遍,第一层就有了。'));
    $('clearAll').hidden = !any;
  }
  function clearLayer(i) {
    if (!S.layers[i]) return;
    if (!window.confirm('清空第 ' + (i + 1) + ' 层?')) return;
    try { if (S.layers[i].bus) S.layers[i].bus.disconnect(); } catch (e) { }
    S.layers[i] = null;
    var any = false;
    for (var k = 0; k < MAX_LAYER; k++) if (S.layers[k] && S.layers[k].evs.length) any = true;
    if (!any) { S.loopBars = 0; S.barsSet = false; stopLoop(); }
    saveBand(); renderAdv(); renderDockLayers();
    say('第 ' + (i + 1) + ' 层清空了');
  }

  /* ---- 这样玩 ---- */
  function renderHow() {
    var box = $('howList');
    clear(box);
    [['点格发声', '横划刮奏。'],
     ['多人同弹', '多指同时弹；录制可叠四层。'],
     ['静音浏览', '点低/高换音区；更多乐器在顶部翻组。']]
      .forEach(function (r) {
        var row = el('div', 'row'), g = el('div', 'grow');
        g.appendChild(el('div', 't1', r[0]));
        g.appendChild(el('div', 't2', r[1]));
        row.appendChild(g);
        box.appendChild(row);
      });
  }

  /* ============================================================
     八、存档
     ============================================================ */

  function sget(k) {
    /* 读不出来就当没有:但要说一句,不然用户以为存的还在 */
    if (jh() && JH.storage) return JH.storage.get(k).catch(function (e) { jc('storage.get')(e); return null; });
    try { return Promise.resolve(localStorage.getItem('band:' + k)); } catch (e) { return Promise.resolve(null); }
  }
  function sset(k, v) {
    if (jh() && JH.storage) return JH.storage.set(k, v).catch(jc('storage.set'));
    try { localStorage.setItem('band:' + k, v); } catch (e) { }
    return Promise.resolve({ ok: true });
  }
  var saveTimer = 0;
  function saveBand() {
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      saveTimer = 0;
      var slim = S.layers.slice(0, MAX_LAYER).map(function (L) {
        if (!L || !L.evs.length) return null;
        return { inst: L.inst, evs: L.evs, vol: L.vol, mute: !!L.mute, bars: L.bars };
      });
      var d = {
        slots: S.slots, bpm: S.bpm, click: S.click, prep: S.prep, snap: S.snap,
        vol: S.vol, wet: S.wet, sel: S.sel, layers: slim, loopBars: S.loopBars,
        barsSet: S.barsSet, howDone: S.howDone
      };
      sset(K_BAND, JSON.stringify(d));
      pushWidget();
    }, 220);
  }

  /* ---- 录到一半页面被系统收走,那遍也不能白弹:每 1.5 秒把半成品落一次盘 ---- */
  function saveTakeSnap() {
    if (!S.rec || !S.recList.length) return;
    var d = {
      list: S.recList.slice(-MAX_EV), bpm: S.bpm, loopBars: S.loopBars,
      phase: S.recT0 - S.loopT0, sel: S.sel, recFrom: S.recFrom, barsSet: S.barsSet
    };
    sset(K_TAKE, JSON.stringify(d));
  }
  function clearTakeSnap() { sset(K_TAKE, ''); }
  function recoverTake() {
    return sget(K_TAKE).then(function (raw) {
      if (!raw) return;
      var d = null;
      try { d = JSON.parse(raw); } catch (e) { d = null; }
      if (!d || !d.list || !d.list.length) return;
      var list = [], i;
      for (i = 0; i < d.list.length && list.length < MAX_EV; i++) {
        var e = d.list[i];
        if (!e || typeof e.t !== 'number' || !instById(e.inst)) continue;
        if (e.pad == null && typeof e.midi !== 'number') continue;
        list.push(e);
      }
      if (!list.length) { clearTakeSnap(); return; }
      var bpm = clamp(d.bpm || S.bpm, 40, 180);
      var bar = 60 / bpm * 4;
      var loopSec = (d.barsSet ? Math.max(1, d.loopBars || 1) : MAX_BARS) * bar;
      var qd = quantizeTake(list, d.barsSet ? (d.phase || 0) : 0, bpm, loopSec);
      var useBars = d.barsSet ? Math.max(1, d.loopBars || 1) : clamp(Math.ceil(qd.maxT / bar), 1, MAX_BARS);
      var limit = useBars * bar, keep = [];
      for (i = 0; i < qd.evs.length; i++) if (qd.evs[i].t < limit - 0.001) keep.push(qd.evs[i]);
      if (!keep.length) { clearTakeSnap(); return; }
      /* 放进哪一层:优先原来那一层;被占了就找第一个空层;四层都满就先留着,不丢 */
      var slot = -1, sel0 = clamp(d.sel || 0, 0, MAX_LAYER - 1);
      if (!S.layers[sel0] || !S.layers[sel0].evs.length) slot = sel0;
      else for (i = 0; i < MAX_LAYER; i++) if (!S.layers[i] || !S.layers[i].evs.length) { slot = i; break; }
      if (slot < 0) { say('上次有一遍没收尾的录音,台上四层满了 —— 清掉一层,下次进来就捡回来'); return; }
      S.layers[slot] = { inst: (d.recFrom || keep[0].inst), evs: keep, vol: 1, mute: false, bars: useBars };
      if (!S.barsSet) { S.loopBars = useBars; S.barsSet = true; }
      clearTakeSnap();
      saveBand();
      renderDockLayers();
      say('帮你捡回了上次没收尾的那一遍:' + keep.length + ' 个音,进第 ' + (slot + 1) + ' 层了');
    });
  }
  function loadBand() {
    return sget(K_BAND).then(function (raw) {
      if (!raw) return;
      var d = null;
      try { d = JSON.parse(raw); } catch (e) { d = null; }
      if (!d || typeof d !== 'object') return;
      if (d.slots && d.slots.length) {
        var out = [];
        for (var i = 0; i < d.slots.length && out.length < MAX_SLOT; i++) {
          if (!d.slots[i] || !instById(d.slots[i].id)) continue;
          out.push({ id: d.slots[i].id, at: d.slots[i].at == null ? null : d.slots[i].at });
        }
        if (out.length) S.slots = out;
      }
      if (d.bpm) S.bpm = clamp(d.bpm, 40, 180);
      S.click = !!d.click;
      S.prep = d.prep !== false;
      S.snap = d.snap !== false;
      if (typeof d.vol === 'number') S.vol = clamp(d.vol, 0, 1);
      if (typeof d.wet === 'number') S.wet = clamp(d.wet, 0, 0.6);
      if (typeof d.sel === 'number') S.sel = clamp(d.sel, 0, MAX_LAYER - 1);
      S.howDone = !!d.howDone;
      if (typeof d.loopBars === 'number') S.loopBars = clamp(d.loopBars, 0, MAX_BARS);
      S.barsSet = !!d.barsSet;
      if (d.layers && d.layers.length) {
        for (i = 0; i < MAX_LAYER; i++) {
          var L = d.layers[i];
          if (!L || !L.evs || !L.evs.length || !instById(L.inst)) { S.layers[i] = null; continue; }
          S.layers[i] = {
            inst: L.inst, evs: L.evs.slice(0, MAX_EV), bars: L.bars || S.loopBars || 1,
            vol: typeof L.vol === 'number' ? clamp(L.vol, 0.2, 1) : 1, mute: !!L.mute
          };
          S.barsSet = true;
        }
      }
    });
  }

  function pushWidget() {
    if (!jh() || !JH.widget || !JH.widget.set) return;
    var n = 0, i;
    for (i = 0; i < MAX_LAYER; i++) if (S.layers[i] && S.layers[i].evs.length) n++;
    JH.widget.set({
      title: '超级乐器',
      lines: [
        { t: '台上', d: S.slots.length + ' 件乐器' },
        { t: '已录', d: n ? n + ' 层 / ' + (S.loopBars || 1) + ' 小节' : '还没录' }
      ],
      accent: '#8D42B4',
      tap: 'plugin:super_band'
    }).catch(jc('widget.set'));
  }

  /* ============================================================
     九、启动
     ============================================================ */

  function bind() {
    $('pagePrev').onclick = function () { changePage(-1); };
    $('pageNext').onclick = function () { changePage(1); };
    $('btnHow').onclick = function () { renderHow(); openSheet('sheetHow', '这样玩'); };
    $('btnBand').onclick = function () { renderBandSheet(); openSheet('sheetBand', '台上这几件'); };
    $('btnPick').onclick = function () { renderPicker(); openSheet('sheetPick', '加一件乐器'); };
    $('btnAdv').onclick = function () { renderAdv(); openSheet('sheetAdv', '音量与设置'); };
    $('bandClose').onclick = closeSheets;
    $('pickClose').onclick = closeSheets;
    $('layClose').onclick = closeSheets;
    $('advClose').onclick = closeSheets;
    $('howClose').onclick = function () { S.howDone = true; saveBand(); closeSheets(); };
    $('mask').onclick = closeSheets;
    $('preSave').onclick = function () {
      var name = window.prompt('给这一套起个名字', '我的合奏');
      if (name === null) return;
      name = (name || '').trim() || '我的合奏';
      if (!S.slots.length) { say('台上还没有乐器'); return; }
      if (!S.userPresets) S.userPresets = [];
      S.userPresets.unshift({
        name: name,
        slots: S.slots.map(function (s) { return { id: s.id, at: s.at == null ? null : Math.round(s.at) }; })
      });
      S.userPresets = S.userPresets.slice(0, 30);
      savePresets();
      renderPresets();
      ping();
      say('存下「' + name + '」了');
    };

    $('btnPlay').onclick = function () {
      if (S.rec) stopRec();
      if (S.playing) { stopLoop(); say('停下了'); }
      else { startLoop(); say(S.loopBars ? '这一圈 ' + S.loopBars + ' 小节,一直循环' : '开始走一圈 1 小节'); }
    };
    $('btnRec').onclick = toggleRec;
    $('btnClick').onclick = function () {
      S.click = !S.click;
      updateDock(); renderAdv(); saveBand();
      say(S.click ? '打拍开了' : '打拍关了');
    };

    $('bpm').value = S.bpm;
    $('bpm').oninput = function () { paintRange(this); $('bpmTxt2').textContent = this.value + ' BPM'; };
    $('bpm').onchange = function () { setBpm(parseInt(this.value, 10)); };
    $('vol').oninput = function () {
      paintRange(this);
      S.vol = parseInt(this.value, 10) / 100;
      A.setVolume(S.vol);
      $('volTxt').textContent = Math.round(S.vol * 100) + '%';
    };
    $('vol').onchange = function () { saveBand(); };
    $('wet').oninput = function () {
      paintRange(this);
      S.wet = parseInt(this.value, 10) / 100;
      A.setWet(S.wet);
      $('wetTxt').textContent = S.wet < 0.08 ? '关' : S.wet < 0.22 ? '少' : S.wet < 0.4 ? '中' : '多';
    };
    $('wet').onchange = function () { saveBand(); };
    $('click2').onclick = function () { $('btnClick').onclick(); };
    $('prepBtn').onclick = function () {
      S.prep = !S.prep;
      $('prepBtn').className = S.prep ? 'on' : '';
      $('prepBtn').textContent = '录音前先数四拍:' + (S.prep ? '开' : '关');
      saveBand();
      say(S.prep ? '录音前先数四拍' : '不数了,点一下就开录');
    };
    $('snapOn').onclick = function () { S.snap = true; renderAdv(); saveBand(); say('拉弦按半音一格一格走'); };
    $('snapOff').onclick = function () { S.snap = false; renderAdv(); saveBand(); say('拉弦拖到哪儿滑到哪儿'); };
    $('clearAll').onclick = function () {
      if (!window.confirm('四层全清掉?')) return;
      for (var ci = 0; ci < S.layers.length; ci++) {
        try { if (S.layers[ci] && S.layers[ci].bus) S.layers[ci].bus.disconnect(); } catch (e) { }
      }
      releaseTouches(); stopRecIfAny();
      S.layers = [];
      S.loopBars = 0;
      S.barsSet = false;
      stopLoop();
      saveBand(); renderAdv(); renderDockLayers();
      say('四层都清空了');
    };
    $('layVol').oninput = function () {
      paintRange(this);
      var L = S.layers[S.sel];
      if (!L) return;
      L.vol = parseInt(this.value, 10) / 100;
      layerVolTo(L, L.mute ? 0 : L.vol);
      $('layVolTxt').textContent = Math.round(L.vol * 100) + '%';
    };
    $('layVol').onchange = function () { saveBand(); };
    $('layMute').onclick = function () {
      var L = S.layers[S.sel];
      if (!L) { say('这一层还是空的'); return; }
      L.mute = !L.mute;
      layerVolTo(L, L.mute ? 0 : (L.vol == null ? 1 : L.vol));
      saveBand();
      openLayer(S.sel);
      renderDockLayers();
      say(L.mute ? '这一层不响了' : '这一层又响了');
    };
    $('layClear').onclick = function () {
      var L = S.layers[S.sel];
      if (!L) { say('这一层还是空的'); return; }
      clearLayer(S.sel);
      openLayer(S.sel);
    };

    if (jh() && JH.onBack) {
      JH.onBack(function () {
        releaseTouches();
        if (sheetOpen()) { closeSheets(); return true; }
        if (S.rec) { stopRec(); return true; }
        if (S.playing) { stopLoop(); return true; }
        return false;
      });
    }
  }

  function boot() {
    if (!A) { say('声音引擎没加载起来'); return; }
    bind();
    bindSurface();
    A.setVolume(S.vol);
    A.setWet(S.wet);
    /* 先按内置的第一套摆上,存档回来之后再按存档摆 —— 首屏永远是"能弹的",不是空的 */
    if (!S.slots.length && PRESETS.length) {
      S.slots = PRESETS[0].slots.map(function (s) { return { id: s.id, at: s.at == null ? null : s.at }; });
    }
    return Promise.all([loadBand(), sget(K_RECENT), sget(K_PRE)]).then(function (r) {
      var recent = null, pre = null;
      try { recent = r[1] ? JSON.parse(r[1]) : null; } catch (e) { recent = null; }
      try { pre = r[2] ? JSON.parse(r[2]) : null; } catch (e) { pre = null; }
      if (recent && recent.length) S.recent = recent.slice(0, 4);
      if (pre && pre.length) S.userPresets = pre;
      if (!S.slots.length && PRESETS.length) {
        S.slots = PRESETS[0].slots.map(function (s) { return { id: s.id, at: s.at == null ? null : s.at }; });
      }
      updateDock();
      renderDockLayers();
      renderBand();
      pushWidget();
      renderHow();
      recoverTake();
      // 台面直接可弹，说明由用户按需打开。
    }).catch(function (e) { say('打开时出了一点岔子:' + ((e && e.message) || e)); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { requestAnimationFrame(boot); });
  else requestAnimationFrame(boot);
})();
