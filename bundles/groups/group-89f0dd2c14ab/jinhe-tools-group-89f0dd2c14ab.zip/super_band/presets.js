/* ============================================================
   超级乐器 · 内置的合奏配置
   ------------------------------------------------------------
   一份配置就是「台上有哪几件、每一件的音区从哪个音起」。
   音区记的是**音高**(MIDI),不是第几个格子 —— 换上别的手机、面板高矮变了,
   同一份配置落在的还是同一段音,不会因为屏幕宽一点就整段挪走。
   (打击那一族没有音高,不写 at。)
   ============================================================ */
(function (root) {
  'use strict';

  /* 一件乐器一份:{ id 乐器 id, at 这一段音区的第一个音(MIDI,可省) } */
  var PRESETS = [
    {
      name: '一人乐队',
      tip: '筝铺底、笛吹旋律、鼓打拍子',
      slots: [
        { id: 'guzheng', at: 38 },
        { id: 'dizi', at: 62 },
        { id: 'drumset' }
      ]
    },
    {
      name: '弦乐三重',
      tip: '两把小提琴分高低,大提琴托底',
      slots: [
        { id: 'violin', at: 55 },
        { id: 'violin', at: 76 },
        { id: 'cello', at: 36 }
      ]
    },
    {
      name: '键盘三重',
      tip: '三台键盘一起按,和弦最厚',
      slots: [
        { id: 'piano', at: 48 },
        { id: 'epiano', at: 48 },
        { id: 'glocken', at: 60 }
      ]
    },
    {
      name: '民乐小合奏',
      tip: '琵琶、二胡、笛子、木鱼',
      slots: [
        { id: 'pipa', at: 45 },
        { id: 'erhu', at: 62 },
        { id: 'dizi', at: 62 },
        { id: 'muyu' }
      ]
    }
  ];

  root.JH_BAND_PRESETS = PRESETS;
})(typeof window !== 'undefined' ? window : this);
