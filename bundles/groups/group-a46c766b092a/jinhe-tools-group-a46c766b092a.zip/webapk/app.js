/* 网页打包 —— 插件逻辑
 * webapk.* 是 v1.4.0 新增的原生 API;jinhe_bridge.js 还没收录它们,
 * 所以这里包了一层 JHNative 直调(等桥更新后会自动优先走 JH.webapk.*)。
 */
(function () {
  "use strict";

  /* ---------- 桥 shim ---------- */
  var myPending = {};
  var seq = 0;

  function myCall(api, args) {
    return new Promise(function (resolve, reject) {
      var cbId = "wcb" + (++seq) + "_" + Date.now();
      myPending[cbId] = { resolve: resolve, reject: reject };
      JHNative.call(api, JSON.stringify(args || {}), cbId);
    });
  }

  function hookBridge() {
    if (!window.JH) return false;
    if (window.__JH_CB && !window.__JH_CB.__webapkWrapped) {
      var orig = window.__JH_CB;
      var wrapped = function (cbId, json) {
        var p = myPending[cbId];
        if (!p) { orig(cbId, json); return; }
        delete myPending[cbId];
        var obj = null;
        try { obj = JSON.parse(json); } catch (e) { obj = { error: String(e) }; }
        if (obj && obj.error) p.reject(new Error(obj.error)); else p.resolve(obj);
      };
      wrapped.__webapkWrapped = true;
      window.__JH_CB = wrapped;
    }
    return true;
  }
  var hookTimer = setInterval(function () { if (hookBridge()) clearInterval(hookTimer); }, 50);

  function apiBuild(args) {
    if (window.JH && JH.webapk && JH.webapk.build) return JH.webapk.build(args);
    return myCall("webapk.build", args);
  }
  function apiInstall(apkPath) {
    if (window.JH && JH.webapk && JH.webapk.install) return JH.webapk.install(apkPath);
    return myCall("webapk.install", { apkPath: apkPath });
  }
  function apiSave(apkPath, name) {
    if (window.JH && JH.webapk && JH.webapk.save) return JH.webapk.save(apkPath, name);
    return myCall("webapk.save", { apkPath: apkPath, name: name });
  }

  /* ---------- DOM ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var urlInput = $("url"), nameInput = $("name"), nameCount = $("nameCount");
  var urlHint = $("urlHint"), nameHint = $("nameHint");
  var iconPreview = $("iconPreview"), iconPick = $("iconPick");
  var buildBtn = $("buildBtn");
  var buildCard = $("buildCard"), phaseText = $("phaseText");
  var doneCard = $("doneCard"), doneTitle = $("doneTitle"), doneMeta = $("doneMeta"), doneIcon = $("doneIcon");
  var failCard = $("failCard"), failText = $("failText");
  var installBtn = $("installBtn"), exportBtn = $("exportBtn");

  var iconBase64 = null;   // data-url 形式
  var lastApkPath = null;
  var lastName = "";
  var building = false;
  var installing = false;  // 「立即安装」那一趟正在进行中(连点两次会拉起两次安装器)

  function sfx(n) { if (window.JH && JH.sfx) JH.sfx(n); }
  function toast(m) { if (window.JH && JH.toast) JH.toast(m); }

  function ulen(s) { return Array.from(s).length; }   // 按码点数,和原生侧 codePointCount 一致

  /* ---------- 表单校验 ---------- */
  function validateUrl(show) {
    var v = urlInput.value.trim();
    if (!v) { if (show) { urlHint.textContent = ""; urlHint.className = "hint"; } return false; }
    if (!/^https?:\/\//i.test(v)) {
      urlHint.textContent = "网址需要以 http:// 或 https:// 开头";
      urlHint.className = "hint err";
      return false;
    }
    if (/\s/.test(v)) {
      urlHint.textContent = "网址里不能有空格";
      urlHint.className = "hint err";
      return false;
    }
    urlHint.textContent = "格式正确";
    urlHint.className = "hint ok";
    return true;
  }

  function validateName() {
    var v = nameInput.value.trim();
    var n = ulen(v);
    nameCount.textContent = n + "/15";
    nameCount.className = "tail" + (n > 15 ? " warn" : "");
    if (n > 15) {
      nameHint.textContent = "名字太长了,最多 15 个字";
      nameHint.className = "hint err";
      return false;
    }
    nameHint.textContent = "";
    nameHint.className = "hint";
    return n >= 1;
  }

  function refreshBtn() {
    buildBtn.disabled = building || !validateUrl(false) || !validateName();
  }

  urlInput.addEventListener("input", function () { validateUrl(true); refreshBtn(); });
  nameInput.addEventListener("input", function () { validateName(); refreshBtn(); });

  /* ---------- 图标 ---------- */
  iconPick.addEventListener("click", function () {
    if (!window.JH || !JH.pickFile) { toast("当前版本不支持选图"); return; }
    JH.pickFile("image/*").then(function (r) {
      if (!r) return;
      iconBase64 = "data:" + (r.mime || "image/png") + ";base64," + r.base64;
      iconPreview.src = iconBase64;
      iconPreview.classList.add("has");
      iconPick.textContent = "换一张 / 已选";
      sfx("click");
    }).catch(function (e) { toast(e.message || "选图失败"); });
  });
  iconPreview.addEventListener("click", function () {
    iconBase64 = null;
    iconPreview.src = "";
    iconPreview.classList.remove("has");
    iconPick.textContent = "选择图片…";
  });

  /* ---------- 进度推送(原生侧 evaluateJavascript 触发) ---------- */
  window.__webapkProgress = function (text) {
    phaseText.textContent = text + "…";
  };

  /* ---------- 构建 ---------- */
  buildBtn.addEventListener("click", function () {
    var url = urlInput.value.trim();
    var name = nameInput.value.trim();
    if (!validateUrl(true) || !validateName()) return;
    building = true;
    refreshBtn();
    buildBtn.textContent = "打包中…";
    buildCard.classList.remove("hidden");
    doneCard.classList.add("hidden");
    failCard.classList.add("hidden");
    phaseText.textContent = "正在准备…";
    sfx("click");

    var args = { name: name, url: url };
    if (iconBase64) args.iconBase64 = iconBase64;

    apiBuild(args).then(function (r) {
      building = false;
      buildBtn.textContent = "重新打包";
      buildCard.classList.add("hidden");
      lastApkPath = r.apkPath;
      lastName = name;
      var size = r.size;
      var sizeText = size >= 1048576 ? (size / 1048576).toFixed(1) + " MB" : Math.round(size / 1024) + " KB";
      doneTitle.textContent = "「" + name + "」打包完成";
      doneMeta.textContent = sizeText + " · " + (r.pkg || "");
      if (iconBase64) {
        doneIcon.style.backgroundImage = "url(" + iconBase64 + ")";
        doneIcon.style.backgroundSize = "cover";
        doneIcon.textContent = "";
      } else {
        doneIcon.style.backgroundImage = "";
        doneIcon.textContent = "✓";
      }
      doneCard.classList.remove("hidden");
      failCard.classList.add("hidden");
      sfx("ok");
      saveDraft();
      refreshBtn();
    }).catch(function (e) {
      building = false;
      buildBtn.textContent = "开始打包";
      buildCard.classList.add("hidden");
      failText.textContent = "打包失败:" + (e.message || e);
      failCard.classList.remove("hidden");
      doneCard.classList.add("hidden");
      sfx("err");
      refreshBtn();
    });
  });

  installBtn.addEventListener("click", function () {
    if (!lastApkPath) return;
    // 拉起安装器是一趟异步的事,连点两次会拉起两次 —— 走一趟上锁
    if (installing) { toast("正在拉起安装器,稍等一下"); return; }
    installing = true;
    installBtn.disabled = true;
    installBtn.textContent = "正在拉起安装器…";
    sfx("click");
    apiInstall(lastApkPath).catch(function (e) {
      toast(e.message || "无法拉起安装器");
    }).then(function () {
      // 成功与失败两条路都要解锁,不然第二次就再也点不动了
      installing = false;
      installBtn.disabled = false;
      installBtn.textContent = "立即安装";
    });
  });

  exportBtn.addEventListener("click", function () {
    if (!lastApkPath) return;
    sfx("click");
    apiSave(lastApkPath, lastName || "网页应用").then(function (r) {
      if (r && r.saved) toast("已导出");
    }).catch(function (e) {
      toast(e.message || "导出失败");
    });
  });

  /* ---------- 草稿记忆 ---------- */
  function saveDraft() {
    if (!window.JH || !JH.storage) return;
    JH.storage.set("draftUrl", urlInput.value.trim());
    JH.storage.set("draftName", nameInput.value.trim());
  }
  function restoreDraft() {
    if (!window.JH || !JH.storage) return;
    Promise.all([JH.storage.get("draftUrl"), JH.storage.get("draftName")]).then(function (rs) {
      if (rs[0]) urlInput.value = rs[0];
      if (rs[1]) nameInput.value = rs[1];
      validateUrl(false); validateName(); refreshBtn();
    }).catch(function () {});
  }

  /* ---------- 启动 ---------- */
  function boot() {
    if (window.JH && JH.setTitle) JH.setTitle("网页打包");
    restoreDraft();
    validateName();
    refreshBtn();
  }
  var bootTimer = setInterval(function () {
    if (window.JH) { clearInterval(bootTimer); clearTimeout(bootFallback); boot(); }
  }, 60);
  var bootFallback = setTimeout(function () { clearInterval(bootTimer); boot(); }, 3000);
})();
