/* ============================================================================
   app.js —— 「PDF 转 TXT」的界面与流程

   这一页的流程是死的(与原生 `ocr.*` 那三个口一一对应):

     ① 选一个 PDF(`JH.file.grab` 流式拷进插件目录 —— 多大的书都不吃内存);
     ② 让原生一页页渲染 + 识字(`JH.ocr.pdf` 起任务,`JH.ocr.status` 轮询进度);
     ③ 把认出来的**行**读回来(`JH.file.readChunk` 分块读),交给 `clean.js` 整理;
     ④ 交给用户:`JH.saveFile` 存 TXT / `JH.workbench.put` 放上工作台。

   两条设计决定,写在这里免得下一个人重新想一遍:

     · **认字与整理是两件事。** 认出来的原始件(一页一行 JSON,带每行的位置)落在插件目录里,
       认一次就够了;用户改「重排段落 / 段首缩进」时只重跑整理(毫秒级),不再去认一遍字。
       一本书认一遍要十几分钟,而整理要不了一毫秒 —— 这两件事混在一起就是灾难。

     · **半路停下来不丢东西。** 原始件是**边认边追加**的,所以「停下来」之后能接着从下一页认
       (`from` 传 `已认到的页号 + 1`、`out` 传同一个文件名就是追加)。手机在半路被系统收掉、
       或者用户退出去又回来,这一页都能从 `JH.storage` 里把上一趟的档读回来接着做。
   ========================================================================== */
(function () {
  'use strict';

  var K_PREF = 'prefs';     /* {dpi, clean, para, indent} */
  var K_LAST = 'last';      /* {out, src, name, pages, done, chars, at} —— 上一趟认到哪儿了 */
  var CHUNK = 4 * 1024 * 1024;   /* readChunk 单次上限就是 4MB */
  var PREVIEW_CHARS = 900;

  var S = {
    file: null,      /* {path,name,size} —— 选中的那个 PDF */
    pages: 0,        /* 总页数(起了任务才知道) */
    done: 0,         /* 已认到第几页(绝对页号;0 = 还没开始) */
    out: '',         /* 原始件在插件目录里的相对路径 */
    job: '',         /* 原生那一头的任务 id */
    state: 'idle',   /* idle / running / done / stopped */
    dpi: 2600,
    clean: true, para: true, indent: true,
    raw: '',         /* 原始件全文 */
    tidied: null,
    text: '',        /* 整理之后的 TXT 全文 */
    title: '',
    timer: 0,
    booted: 0
  };

  function $(id) { return document.getElementById(id); }
  function jh() { return window.JH || null; }
  function hasOcr() { return !!(window.JH && window.JH.ocr); }
  function say(m) { if (jh() && JH.toast) JH.toast(m); else console.log('[pdf2txt] ' + m); }
  function ping() { try { JH.sfx('ok'); JH.vibrate(12); } catch (e) { } }
  function fail(e) { say((e && e.message) || '这一步没做成'); }

  function mb(n) {
    n = +n || 0;
    if (n >= 1073741824) return (n / 1073741824).toFixed(2) + ' GB';
    if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
    if (n >= 1024) return Math.round(n / 1024) + ' KB';
    return n + ' B';
  }
  /* 「还剩 + 这一句」拼起来要读得顺:「还剩约 4 分钟」/「还剩不到一分钟」——
     所以"约"与"不到"都长在这一句里,调用方只加一个"还剩"(2026-10-12 实测踩过:
     拼成「还剩约 不到一分钟」,一眼就看出来是两段话硬接的) */
  function mins(ms) {
    var m = Math.round((+ms || 0) / 60000);
    if (m <= 0) return '不到一分钟';
    if (m >= 60) return '约 ' + Math.floor(m / 60) + ' 小时 ' + (m % 60) + ' 分';
    return '约 ' + m + ' 分钟';
  }
  function safeName(s, fallback) {
    var t = String(s == null ? '' : s).replace(/[\\/:*?"<>|\r\n\t]/g, '_').replace(/\s+/g, ' ').trim();
    return t.slice(0, 60) || fallback;
  }
  function titleOf(name) { return safeName(String(name || '').replace(/\.[A-Za-z0-9]{1,5}$/, ''), '识别结果'); }

  /* ============================ 偏好与档案 ============================ */

  function paintPrefs() {
    var bs = $('dpiSeg').getElementsByTagName('button');
    for (var i = 0; i < bs.length; i++) {
      var on = (+bs[i].getAttribute('data-v')) === S.dpi;
      bs[i].className = on ? 'on' : '';
      bs[i].setAttribute('aria-selected', on ? 'true' : 'false');
    }
    $('swClean').setAttribute('aria-checked', S.clean ? 'true' : 'false');
    $('swPara').setAttribute('aria-checked', S.para ? 'true' : 'false');
    $('swIndent').setAttribute('aria-checked', S.indent ? 'true' : 'false');
    $('dpiNote').textContent = S.dpi >= 3400
      ? '极致:每页按长边 3400 像素认,小字最稳,也最慢。'
      : (S.dpi >= 2600 ? '清晰够用;印刷字小的书选「极致」,慢一些也准一些。'
        : '标准:最快。字大而清楚的书够用。');
  }

  function loadPrefs() {
    if (!jh() || !JH.storage) return;
    JH.storage.get(K_PREF).then(function (v) {
      if (!v) return;
      var p = null;
      try { p = JSON.parse(v); } catch (e) { p = null; }
      if (!p) return;
      if (p.dpi) S.dpi = Math.max(2000, Math.min(3400, +p.dpi || 2600));
      if (typeof p.clean === 'boolean') S.clean = p.clean;
      if (typeof p.para === 'boolean') S.para = p.para;
      if (typeof p.indent === 'boolean') S.indent = p.indent;
      paintPrefs();
    }).catch(function () { });
  }

  function savePrefs() {
    if (!jh() || !JH.storage) return;
    JH.storage.set(K_PREF, JSON.stringify({ dpi: S.dpi, clean: S.clean, para: S.para, indent: S.indent }))
      .catch(function () { });
  }

  function saveLast() {
    if (!jh() || !JH.storage || !S.out) return;
    JH.storage.set(K_LAST, JSON.stringify({
      out: S.out,
      src: (S.file && S.file.path) || '',
      name: (S.file && S.file.name) || S.title,
      pages: S.pages, done: S.done,
      chars: (S.tidied && S.tidied.stats.chars) || 0,
      at: Date.now()
    })).catch(function () { });
  }

  function forgetLast() {
    S.out = ''; S.done = 0;
    if (jh() && JH.storage) JH.storage.remove(K_LAST).catch(function () { });
  }

  /* ============================ 选文件 ============================ */

  function pick() {
    if (!hasOcr()) { say('这一版锦盒还没有 PDF 识字接口,先更新锦盒'); return; }
    if (S.state === 'running') { say('还在认字。要换书先点「停下来」'); return; }
    JH.file.grab('*/*').then(function (f) {
      if (!f) return;                                     /* 用户取消了 —— 静默收场 */
      var oldOut = S.out;
      S.file = f;
      S.pages = 0; S.done = 0; S.out = ''; S.raw = ''; S.text = ''; S.tidied = null;
      S.state = 'idle'; S.job = '';
      S.title = titleOf(f.name);
      $('fileName').textContent = f.name || 'PDF';
      $('fileMeta').textContent = mb(f.size) + ' · 还没认字';
      $('fileAct').textContent = '换一个';
      $('outCard').hidden = true;
      forgetLast();
      if (oldOut) JH.file.delete(oldOut).catch(function () { });
      sweepGrab(S.file.path);
      paintRun();
    }).catch(fail);
  }

  /**
   * 插件目录里的 `grab/` 只留当前这一本。
   *
   * 为什么非要有这一下:每次「换一个」都会拷一份新的进来(`file.grab` 遇到重名会自动改名),
   * 一本 200 MB 的扫描书换三本就 600 MB 躺在 App 私有目录里,用户在设置里都找不着它。
   */
  function sweepGrab(keep) {
    if (!jh() || !JH.dir) return;
    JH.dir.list('grab').then(function (list) {
      list = list || [];
      for (var i = 0; i < list.length; i++) {
        if (keep && list[i] === keep) continue;
        JH.file.delete(list[i]).catch(function () { });
      }
    }).catch(function () { });
  }

  /* ============================ 起任务 / 轮询 ============================ */

  function start(from, fresh) {
    if (!hasOcr()) return;
    if (!S.file || !S.file.path) { say('先选一个 PDF'); return; }
    if (S.state === 'running') return;
    $('go').disabled = true;
    var args = { path: S.file.path, longEdge: S.dpi, from: from || 1 };
    if (!fresh && S.out && (from || 1) > 1) args.out = S.out;   /* 同一个文件 + from>1 = 接着往下写 */
    if (fresh) { S.raw = ''; S.text = ''; S.tidied = null; $('outCard').hidden = true; }

    JH.ocr.pdf(args).then(function (r) {
      S.job = r.jobId;
      S.pages = r.pages || 0;
      S.out = r.out || S.out;
      S.done = (r.from || 1) - 1;
      S.state = 'running';
      S.title = titleOf(r.name || (S.file && S.file.name));
      $('fileName').textContent = r.name || (S.file && S.file.name) || 'PDF';
      $('fileMeta').textContent = (S.file && S.file.size ? mb(S.file.size) + ' · ' : '') + '共 ' + S.pages + ' 页';
      showRunning({ page: S.done, pages: S.pages, chars: 0, etaMs: 0, conf: 0, head: '' });
      tick();
    }).catch(function (e) {
      $('go').disabled = false;
      S.state = 'idle';
      paintRun();
      fail(e);
    });
  }

  function tick() {
    if (S.timer) { clearTimeout(S.timer); S.timer = 0; }
    if (!S.job || !hasOcr()) return;
    JH.ocr.status(S.job).then(function (st) {
      if (!st) return;
      if (st.pages) S.pages = st.pages;
      if (st.page) S.done = st.page;
      if (st.out) S.out = st.out;

      if (st.state === 'done') { S.state = 'done'; endRun(true); return; }
      if (st.state === 'error') {
        S.state = 'stopped';
        saveLast();
        showNotice(st.message || '这一趟没认成');
        loadRaw();
        return;
      }
      if (st.state === 'cancelled') { S.state = 'stopped'; endRun(false); return; }
      showRunning(st);
      S.timer = setTimeout(tick, 600);
    }).catch(function (e) {
      /* not_found = 这个任务不在了(锦盒被系统重启过)。不装作没事,把已有的那一份读回来 */
      if (e && e.code === 'not_found') {
        S.job = ''; S.state = 'stopped';
        showNotice('这一趟不在了(锦盒被系统重启过)。已经认出来的还在,可以接着往下认。');
        loadRaw();
        return;
      }
      S.timer = setTimeout(tick, 2000);
    });
  }

  function showRunning(st) {
    var total = st.pages || S.pages || 0;
    var done = st.page || S.done || 0;
    $('runCard').hidden = false;
    $('go').hidden = true;
    $('redo').hidden = true;
    $('prog').hidden = false;
    setBar(total ? done * 100 / total : 0);
    $('progText').textContent = total
      ? ('第 ' + done + ' / ' + total + ' 页' + (total ? ' · ' + Math.round(done * 100 / total) + '%' : ''))
      : '正在打开这个 PDF…';
    var bits = [];
    if (st.chars) bits.push('已认 ' + PdfClean.humanChars(st.chars) + ' 字');
    if (st.etaMs > 0 && done > 0) bits.push('还剩' + mins(st.etaMs));
    if (st.conf > 0) bits.push('平均可信度 ' + Math.round(st.conf * 100) + '%');
    $('progSub').textContent = bits.join(' · ');
    $('progHead').textContent = st.head ? ('刚认出:「' + st.head + '」') : '';
  }

  function setBar(pct) {
    $('barFill').style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
  }

  /** 一趟收尾(认完 / 被叫停)—— 都把原始件读回来,能读多少读多少 */
  function endRun(doneAll) {
    $('prog').hidden = true;
    $('go').hidden = false;
    $('redo').hidden = true;
    $('go').disabled = false;
    $('runCard').hidden = false;
    saveLast();
    if (doneAll) {
      ping();
      say('认完了,正在整理…');
    }
    loadRaw();
  }

  function showNotice(msg) {
    $('prog').hidden = true;
    $('go').hidden = false;
    $('go').disabled = false;
    $('runCard').hidden = false;
    say(msg);
  }

  /* ============================ 读回原始件 ============================ */

  function loadRaw() {
    if (!S.out) { paintRun(); return; }
    $('runCard').hidden = false;
    $('go').hidden = true;
    $('redo').hidden = true;
    $('prog').hidden = false;
    $('progText').textContent = '正在把认出来的读回来…';
    $('progSub').textContent = '';
    $('progHead').textContent = '';
    setBar(0);

    JH.file.info(S.out).then(function (info) {
      var size = (info && info.size) || 0;
      return readAll(S.out, size, function (got) { setBar(size ? got * 100 / size : 0); });
    }).then(function (text) {
      S.raw = text || '';
      retidy();
      if (!S.tidied || !S.tidied.blocks.length) {
        S.state = 'idle';
        showNotice('这一份里没读出字来 —— 可能是空白页,或者扫得太淡');
        paintRun();
        return;
      }
      if (S.state === 'running' || S.state === 'done') S.state = 'stopped';
      paintRun();
      showResult();
    }).catch(function (e) {
      showNotice('取结果失败:' + ((e && e.message) || '读不到那一份原始件'));
      paintRun();
    });
  }

  function readAll(path, size, onProg) {
    var off = 0, parts = [], total = 0;
    function step() {
      return JH.file.readChunk(path, off, CHUNK).then(function (r) {
        var b64 = (r && r.base64) || '';
        if (!b64) return null;
        var bytes = b64bytes(b64);
        parts.push(bytes);
        off += bytes.length; total += bytes.length;
        onProg(total);
        if ((size && off >= size) || bytes.length < CHUNK) return null;
        return step();
      });
    }
    return step().then(function () { return bytesToUtf8(parts); });
  }

  function b64bytes(s) {
    var bin = window.atob(s), n = bin.length, out = new Uint8Array(n);
    for (var i = 0; i < n; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  /** 分块读回来的是**字节**:拼成一条再解码,别按块各自解(一个汉字可能横跨两块) */
  function bytesToUtf8(parts) {
    var n = 0, i;
    for (i = 0; i < parts.length; i++) n += parts[i].length;
    var all = new Uint8Array(n), at = 0;
    for (i = 0; i < parts.length; i++) { all.set(parts[i], at); at += parts[i].length; }
    if (window.TextDecoder) {
      try { return new TextDecoder('utf-8').decode(all); } catch (e) { }
    }
    var bin = '', CH = 0x8000;
    for (i = 0; i < all.length; i += CH) bin += String.fromCharCode.apply(null, all.subarray(i, i + CH));
    try { return decodeURIComponent(escape(bin)); } catch (e2) { return bin; }
  }

  /* ============================ 整理与呈现 ============================ */

  function retidy() {
    if (!S.raw) return;
    var res = PdfClean.parseRaw(S.raw);
    S.tidied = PdfClean.tidy(res, { clean: S.clean, para: S.para });
    S.text = PdfClean.format(S.tidied, { indent: S.indent });
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function showResult() {
    var st = S.tidied.stats;
    $('outChars').textContent = PdfClean.humanChars(st.chars);
    var bits = [];
    bits.push('正文 ' + st.pages + ' 页');
    if (st.paras) bits.push(st.paras + ' 段');
    if (st.chapters) bits.push(st.chapters + ' 章');
    if (S.pages && S.done > 0 && S.done < S.pages) bits.push('认到第 ' + S.done + ' / ' + S.pages + ' 页');
    var junk = st.droppedHead + st.droppedNoise + st.droppedToc;
    if (junk) bits.push('丢掉 ' + junk + ' 条杂行');
    if (st.conf) bits.push('平均可信度 ' + Math.round(st.conf * 100) + '%');
    var line = bits.join(' · ');
    if (junk && st.samples && st.samples.length) line += '\n丢掉的是「' + st.samples[0] + '」这一类';
    $('outFacts').textContent = line;

    /* 预览:按块铺,标题加粗 —— 只看前 900 字,再多也读不完 */
    var html = '', used = 0;
    for (var i = 0; i < S.tidied.blocks.length && used < PREVIEW_CHARS; i++) {
      var b = S.tidied.blocks[i];
      var t = b.text.length > 360 ? b.text.slice(0, 360) + '…' : b.text;
      html += '<p class="' + (b.type === 'h' ? 'h' : '') + '">' +
        (b.type === 'h' || !S.indent ? '' : '　　') + esc(t) + '</p>';
      used += t.length;
    }
    $('preview').innerHTML = html || '<p>（空）</p>';
    $('outCard').hidden = false;
  }

  function paintRun() {
    if (!S.file && !S.pages) { $('runCard').hidden = true; return; }
    $('runCard').hidden = false;
    $('go').hidden = false;
    $('go').disabled = false;
    $('prog').hidden = true;
    var partial = S.pages > 0 && S.done > 0 && S.done < S.pages;
    $('go').textContent = partial
      ? ('接着认(还剩 ' + (S.pages - S.done) + ' 页)')
      : (S.pages > 0 && S.done >= S.pages ? '重新认一遍' : '开始识别');
    $('redo').hidden = !partial || !S.file;
  }

  /* ============================ 出去 ============================ */

  function onSave() {
    if (!S.text) { say('还没有结果'); return; }
    var nm = (S.title || '识别结果') + '.txt';
    JH.saveFile(nm, 'text/plain', S.text).then(function (ok) {
      if (ok) { ping(); say('已存成 ' + nm); } else { say('没有保存'); }
    }).catch(fail);
  }

  function onHub() {
    if (!S.text) { say('还没有结果'); return; }
    JH.workbench.put({ type: 'text', text: S.text, name: (S.title || '识别结果') + '.txt' })
      .then(function () { ping(); say('已放到工作台'); }).catch(fail);
  }

  function onCopy() {
    if (!S.text) { say('还没有结果'); return; }
    if (S.text.length > 200000) { say('太长了,剪贴板放不下 —— 用「保存 TXT」'); return; }
    JH.clipboard.set(S.text).then(function () { ping(); say('已复制'); }).catch(fail);
  }

  function onStop() {
    if (!S.job) return;
    $('stop').disabled = true;
    JH.ocr.cancel(S.job).then(function () {
      $('stop').disabled = false;
      say('正在停…认出来的那部分会留下');
      S.timer = setTimeout(tick, 400);
    }).catch(function () {
      $('stop').disabled = false;
      say('停不下来 —— 等这一页认完再点一次');
    });
  }

  /* ============================ 接线 ============================ */

  function bind(el, fn) {
    if (!el) return;
    el.onclick = fn;
    el.onkeydown = function (ev) {
      ev = ev || window.event;
      if (ev.key === 'Enter' || ev.key === ' ' || ev.keyCode === 13 || ev.keyCode === 32) {
        if (ev.preventDefault) ev.preventDefault();
        fn();
      }
    };
  }

  function toggle(which) {
    if (which === 'clean') S.clean = !S.clean;
    if (which === 'para') S.para = !S.para;
    if (which === 'indent') S.indent = !S.indent;
    paintPrefs();
    savePrefs();
    if (S.raw && S.tidied) { retidy(); showResult(); }   /* 改了整理方式当场重排,不再去认一遍字 */
  }

  function boot() {
    if (S.booted++) return;
    paintPrefs();

    if (!hasOcr()) {
      $('fileName').textContent = '先更新锦盒';
      $('fileMeta').textContent = '这一版锦盒还没有 PDF 识字接口';
      return;
    }
    loadPrefs();

    bind($('fileRow'), pick);
    bind($('swClean'), function () { toggle('clean'); });
    bind($('swPara'), function () { toggle('para'); });
    bind($('swIndent'), function () { toggle('indent'); });
    bind($('go'), function () {
      var partial = S.pages > 0 && S.done > 0 && S.done < S.pages && S.out;
      start(partial ? S.done + 1 : 1, !partial);
    });
    bind($('redo'), function () {
      if (S.out) JH.file.delete(S.out).catch(function () { });
      forgetLast();
      start(1, true);
    });
    bind($('stop'), onStop);
    bind($('save'), onSave);
    bind($('toHub'), onHub);
    bind($('copy'), onCopy);
    $('dpiSeg').onclick = function (ev) {
      var el = (ev || window.event).target;
      if (!el || el.tagName !== 'BUTTON') return;
      S.dpi = Math.max(2000, Math.min(3400, (+el.getAttribute('data-v')) || 2600));
      paintPrefs();
      savePrefs();
    };

    if (jh() && JH.onBack) {
      JH.onBack(function () {
        if (S.state === 'running') {
          var ok = window.confirm ? window.confirm('还在认字。要停下来吗?认出来的那部分会留下。') : true;
          if (ok) onStop();
          return true;
        }
        return false;
      });
    }

    /* 页面可能是重进过的:先问原生「本插件有没有在跑的活」,有就跟上;没有就看上一趟的档 */
    JH.ocr.status().then(function (st) {
      if (st && st.jobId && (st.state === 'running' || st.state === 'queued')) {
        S.job = st.jobId;
        S.pages = st.pages || 0;
        S.done = st.page || 0;
        S.out = st.out || '';
        S.state = 'running';
        S.file = { path: '', name: st.name || 'PDF', size: 0 };
        if (st.src) S.file.path = st.src;
        $('fileName').textContent = st.name || 'PDF';
        $('fileMeta').textContent = '共 ' + S.pages + ' 页 · 正在认字';
        showRunning(st);
        tick();
        return;
      }
      restoreLast();
    }).catch(function () { restoreLast(); });
  }

  /**
   * 上一趟的档还在不在。
   *
   * 判据是**磁盘上那个原始件真的在**(`file.exists`)—— 存储里的那条记录只是"指针",
   * 指针指着的东西被清掉了就不能照着往下做(否则用户点「接着认」只会得到一句错误)。
   */
  function restoreLast() {
    if (!jh() || !JH.storage) return;
    JH.storage.get(K_LAST).then(function (v) {
      if (!v) return;
      var rec = null;
      try { rec = JSON.parse(v); } catch (e) { rec = null; }
      if (!rec || !rec.out) return;
      JH.file.exists(rec.out).then(function (yes) {
        if (!yes) { forgetLast(); return; }
        S.out = rec.out;
        S.pages = rec.pages || 0;
        S.done = rec.done || 0;
        S.title = titleOf(rec.name);
        S.state = 'stopped';
        S.file = rec.src ? { path: rec.src, name: rec.name || 'PDF', size: 0 } : null;
        $('fileName').textContent = rec.name || '上一次那一本';
        $('fileMeta').textContent = S.file
          ? ('上次认到第 ' + S.done + ' / ' + S.pages + ' 页 · 已 ' + PdfClean.humanChars(rec.chars || 0) + ' 字')
          : ('上次那一本不在插件目录里了 · 已 ' + PdfClean.humanChars(rec.chars || 0) + ' 字');
        $('fileAct').textContent = '换一个';
        paintRun();
        loadRaw();
      }).catch(function () { });
    }).catch(function () { });
  }

  /* 桥可能比脚本晚一拍注入(老容器):等一拍再试一次,只试一次,不为它写轮询 */
  function ready() {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
    window.setTimeout(function () { if (!S.booted && hasOcr()) boot(); }, 500);
  }
  ready();
})();
