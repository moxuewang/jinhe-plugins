/* ============================================================================
   clean.js —— 把「一页页 OCR 出来的行」变成「能读的小说文本」

   为什么要有这一层:原生那一趟给回来的是**行**,而且每行都带着它在页面上的位置。
   一本书直接按行拼起来是没法读的(每一行都成了独立一段),而阅读器里的「一章一章」
   更是全靠标题行认出来的。所以这一层只做三件事:

     ① 把不该在正文里的行删掉 —— 页码、页眉页脚(跨页重复的那几行)、目录页、
        以及识别得很差的碎行;
     ② 把一行行**并回整段** —— 判据是几何,不是字符:段首缩进(左边距比正文多出一格)、
        上一行没顶到右边距、段间的空档比行距大;
     ③ 认出章节标题,在它前面留一个空行 —— 阅读器就是按这些记号切目录的。

   三条纪律:

     · **纯函数,不碰 DOM、不碰 JH、不碰 Date** —— 于是它能在 node 里直接对拍,
       也能在换设置时毫秒级重跑(不必重新识别一遍)。
     · **ES5** —— 老 WebView 里也要跑(不用 let/const/箭头函数/模板串)。
     · **判据失效时退到"安全的那一侧"** —— 一页上要是既量不出缩进、又没有一行顶到右边距
       (没缩进、且左对齐排版的 PDF),就**每行各自成段**,而不是把整章并成一个巨段。
       宁可读起来碎一点,也不能把一整章吞成一段。

   跨文件契约(与 `index.html` / `app.js` 对齐):
     PdfClean.parseRaw(text) → {pages:[{pg,l:[{x,y,w,c,t}]}], bad: 坏行数}
     PdfClean.tidy(res, opt)  → {blocks, stats}    opt = {clean, para}
     PdfClean.format(t, opt)  → string            opt = {indent}
   ========================================================================== */
(function (root) {
  'use strict';

  /* ---------- 字符类判据(与 App 原生 `A11y.meaningful` 同一套"算不算字"的口径)---------- */
  var RE_CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/;
  var RE_ANY = /[0-9A-Za-z\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/;
  /* 汉字之间夹的空格要拿掉;但汉字与拉丁字母之间的空格要留(中英混排的断词) */
  var RE_CJK_SPACE = /([\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff])\s+([\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff])/g;
  /* 中文标点前面不留空格、后面不留空格 */
  var RE_BEFORE_PUNCT = /\s+([,.;:!?)\]}，。、；：？！）】」』…”’])/g;
  var RE_AFTER_PUNCT = /([([{（【「『“‘])\s+/g;
  /* 汉字与紧跟其后的开引号/开括号之间那个空格也不要(「他说 「好」」这种) */
  var RE_CJK_OPEN = /([\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff])\s+([「『（【《〈])/g;

  /* ---------- 页码 / 页眉那一族 ---------- */
  /* 纯数字、带括号或装饰符的数字、「第 N 页」「N / M」「Page N」——它们都不是正文 */
  var RE_PAGE_NUM = new RegExp(
    '^(?:[-—–－·•＊*~～/\\\\|]+\\s*)?' +
    '(?:第\\s*)?[0-9０-９]{1,4}\\s*(?:页|/\\s*[0-9０-９]{1,4})?' +
    '(?:\\s*[-—–－·•＊*~～/\\\\|]+)?$'
  );
  var RE_PAGE_EN = /^(?:page|p\.?)\s*[0-9]{1,4}$/i;

  /* ---------- 章节标题 ---------- */
  /* 强判据:「第 X 章/节/回/卷/部/篇/集」这样的编号,或者「序章/楔子/番外」这种专名 */
  var RE_HEAD_NUM = /^(?:第|卷)\s*[0-9０-９〇零一二三四五六七八九十百千万两]{1,12}\s*[章节回卷部篇集幕折]/;
  var RE_HEAD_WORD = /^(?:序章|序言|序|序幕|引子|楔子|前言|后记|跋|尾声|终章|大结局|番外|附录|致谢|译后记|尾声|Chapter\s+[0-9IVXLC]+|Part\s+[0-9IVXLC]+|Chapter\s+[A-Za-z]+)/i;
  /* 句子尾巴 —— 带这些标点的一定不是标题(「第一章里他就……」这种正文不能被当成标题) */
  var RE_HEAD_TAIL = /[。！？；，、,;.!?…—]$/;
  /* 目录页的行尾:一串点线/省略号 + 页码 */
  var RE_TOC_LINE = /[.．·…⋯]{3,}\s*[0-9０-９]{0,4}\s*$/;

  var num = function (v) { var n = +v; return isFinite(n) ? n : 0; };

  function trim(s) {
    return String(s == null ? '' : s).replace(/^[\s\u3000\u00a0]+|[\s\u3000\u00a0]+$/g, '');
  }

  /** 行内清理:全角空格归一、汉字间空格去掉、中文标点旁的空白去掉 */
  function fixText(t) {
    var s = String(t == null ? '' : t);
    s = s.replace(/[\u00a0\u3000]/g, ' ').replace(/[ \t]{2,}/g, ' ');
    for (var i = 0; i < 3; i++) {
      var before = s;
      s = s.replace(RE_CJK_SPACE, '$1$2');
      if (s === before) break;
    }
    s = s.replace(RE_BEFORE_PUNCT, '$1').replace(RE_AFTER_PUNCT, '$1').replace(RE_CJK_OPEN, '$1$2');
    return trim(s);
  }

  /** 那一行"算不算有字"(整行只有破折号/点点/符号的,是版面上的装饰,不是内容) */
  function meaningful(t) { return RE_ANY.test(t); }

  /**
   * 认人的键:把数字、空白、标点全抹掉,只留字。
   * 页眉页脚靠它跨页比对 —— 「第 12 页」与「第 13 页」在它眼里是同一条(都是空串)。
   */
  function normKey(t) {
    return String(t).replace(/[0-9０-９]/g, '').replace(/[\s\u3000]/g, '')
      .replace(/[^\w\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff]/g, '')
      .toLowerCase();
  }

  function isPageNumberish(t) {
    var s = trim(t);
    if (!s) return false;
    if (RE_PAGE_EN.test(s)) return true;
    if (s.length > 14) return false;
    return RE_PAGE_NUM.test(s);
  }

  function isHeading(t) {
    var s = trim(t);
    if (!s || s.length > 40) return false;
    if (RE_HEAD_TAIL.test(s)) return false;
    if (RE_HEAD_NUM.test(s)) return true;
    if (RE_HEAD_WORD.test(s)) return s.length <= 24;
    return false;
  }

  /* ============================ ① 解析原生给回来的原始件 ============================ */

  function parseRaw(text) {
    var pages = [], bad = 0;
    var raw = String(text == null ? '' : text).split('\n');
    for (var i = 0; i < raw.length; i++) {
      var s = trim(raw[i]);
      if (!s) continue;
      var o = null;
      try { o = JSON.parse(s); } catch (e) { o = null; }
      if (!o || !o.l || typeof o.l.length !== 'number') { bad++; continue; }
      var ls = [];
      for (var j = 0; j < o.l.length; j++) {
        var a = o.l[j];
        if (!a || a.length < 5) continue;
        var t = fixText(a[4]);
        if (!t) continue;
        ls.push({ x: num(a[0]), y: num(a[1]), w: num(a[2]), c: num(a[3]), t: t });
      }
      /* **这一页的行序照单全收,不自己再排一遍** —— 原生那一头已经排过了
         (`ocr/LayoutPost.ReadingOrder.sort`:先找栏间空白、按栏读,单栏退化成按行自上而下),
         在这里再排一次会把两栏页重新串读(实测:以为在"修",其实是在毁)。
         行内 x 从左到右同理,不必再动。 */
      pages.push({ pg: num(o.pg) || (pages.length + 1), l: ls });
    }
    return { pages: pages, bad: bad };
  }

  /* ============================ ② 版面度量 ============================ */

  function median(arr) {
    if (!arr.length) return 0;
    var a = arr.slice().sort(function (p, q) { return p - q; });
    var m = Math.floor(a.length / 2);
    return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
  }

  /** 出现最多的那个值(按 dp 位小数分箱)—— 正文的左边距就是"大多数行都从这儿起" */
  function mode(arr, dp, prefer) {
    if (!arr.length) return 0;
    var box = {}, best = null, bestN = 0;
    for (var i = 0; i < arr.length; i++) {
      var k = arr[i].toFixed(dp);
      box[k] = (box[k] || 0) + 1;
      if (best === null) { best = +k; bestN = 1; continue; }
      var n = box[k];
      /* 同票时按 prefer 取:左边距取小的(版心的左缘),右边距取大的(右缘) */
      if (n > bestN || (n === bestN && prefer === 'min' && +k < best) ||
        (n === bestN && prefer === 'max' && +k > best)) {
        best = +k; bestN = n;
      }
    }
    return best == null ? 0 : best;
  }

  /**
   * 量一页的版心:左边距、右边距、一个字大约多宽、行距。
   *
   * 两条规矩都是从实测的坑里来的:
   *
   *  ① **只用版心那一带的行**(`y` 在 0.07~0.93)。页眉页脚也在页面上,而且往往是长句子
   *     (书名 + 篇章名),把它们算进来会把"版心左缘"量到页眉那个 x 上 —— 于是整页的段首缩进
   *     全部认不出来,一整页会被并成一段(合成数据实测就是这样翻的车);
   *  ② 左边距取"同票靠左"的那个 x:正文所有行都从同一个 x 起,页眉页脚/插图说明是零星的
   *     别的 x,同票时取小的那个才落在版心上。
   */
  function measure(page) {
    var all = page.l;
    var body = [];
    for (var a = 0; a < all.length; a++) {
      if (all[a].y >= 0.07 && all[a].y <= 0.93) body.push(all[a]);
    }
    if (body.length < 3) body = all;              /* 整页就那么几行时别把判据也丢了 */
    var longX = [], rightEdge = [], charW = [], gaps = [];
    for (var i = 0; i < body.length; i++) {
      var t = body[i].t;
      if (t.length >= 6) longX.push(body[i].x);
      rightEdge.push(body[i].x + body[i].w);
      charW.push(body[i].w / Math.max(1, t.length));
    }
    for (var j = 1; j < body.length; j++) {
      var d = body[j].y - body[j - 1].y;
      if (d > 0.0005) gaps.push(d);
    }
    var xs = body.map(function (e) { return e.x; });
    var m = {
      left: mode(longX.length ? longX : xs, 2, 'min'),
      right: mode(rightEdge, 2, 'max'),
      charW: median(charW),
      pitch: median(gaps),
      count: body.length
    };
    if (!m.charW) m.charW = 0.02;
    if (!m.pitch) m.pitch = 0.03;

    /* 缩进率:有多少行的左边距明显比版心多出大半格 */
    var indented = 0;
    for (var k = 0; k < body.length; k++) if (body[k].x - m.left > m.charW * 0.75) indented++;
    m.indentRatio = body.length ? indented / body.length : 0;
    /* 顶到右边距的比例:「上一行没写完」这个判据只有在这一栏为真时才有意义 */
    var full = 0;
    for (var q = 0; q < body.length; q++) if (body[q].x + body[q].w > m.right - m.charW) full++;
    m.fullRatio = body.length ? full / body.length : 0;
    /* **两栏页**:有一批行明显坐在版心右半(离左边距三格半以上)。
       两栏页上"段首缩进 / 上一行没写到右边距"这两条判据全都失效(右栏每一行看着都像缩进、
       左栏每一行看着都没写满),硬按单栏那一套走会把两栏黏成一团。
       行序本身是对的 —— 原生那一层按栏读(`LayoutPost.ReadingOrder`)—— 所以这里退到
       "每行一段":读起来碎,但顺序对、字一个不少。多栏页不在这一页的目标里(见台账)。
       门槛取 0.2:两栏页里右栏的正文行能占到三成以上;单栏页里只有零星几行会跑到右边
       (插图说明、居中的标题),够不到这一档。 */
    var farRight = 0;
    for (var f2 = 0; f2 < body.length; f2++) if (body[f2].x - m.left > m.charW * 3.5) farRight++;
    m.twoCol = body.length >= 4 && farRight / body.length >= 0.2;
    return m;
  }

  /* ============================ ③ 该删的行 ============================ */

  /**
   * 决定这一行留不留。返回 null = 留;返回一句"为什么删" = 删。
   *
   * 页眉页脚不是靠"在上边就是页眉"删的:书页最上面那一行也可能是正文的第一行
   * (一章正好从这页起)。所以真正的判据是**跨页重复** —— 同一句话在不同页的同一个位置
   * 反复出现,那只能是版面上的固定件(书名、篇章名、出版社),不是内容。
   */
  function whyDrop(line, page, m, ctx) {
    var t = line.t;

    if (isPageNumberish(t)) return '页码';

    /* 整行没有一个"字":只有破折号、点点、星号的装饰行 */
    if (!meaningful(t)) return '装饰行';

    /* 识别得很差的碎行:一两个字、而且置信度低(整页都低时不删,那是这一页本身糊) */
    if (t.length <= 2 && line.c > 0 && line.c < 0.6 && ctx.pageConf > 0.7) return '碎行';

    if (ctx.opt.clean) {
      var key = normKey(t);
      var hit = key ? (ctx.freq[key] || 0) : 0;
      var top = line.y <= 0.09, bottom = line.y + 0.02 >= 0.92;

      /* 跨页反复出现:页眉页脚(书名、篇章名) */
      if (hit >= 3 && hit >= ctx.pageCount * 0.25 && t.length <= 40) return '页眉页脚';
      /* 一页顶部/底部的居中短行:版面上那一格放的就是页眉页脚,正文不长这样 */
      if ((top || bottom) && m.count >= 8 && t.length <= 20) {
        var c = line.x + line.w / 2;
        if (c > 0.36 && c < 0.64 && (t.length <= 12 || hit >= 2) && !isHeading(t)) return '页眉页脚';
      }
    }
    return null;
  }

  /** 目录页:一页上大半的行都是「第 X 章」或者「…… 12」这种点线行,那它就是目录 */
  function looksToc(page) {
    var ls = page.l;
    if (ls.length < 5) return false;
    var hit = 0;
    for (var i = 0; i < ls.length; i++) {
      if (isHeading(ls[i].t) || RE_TOC_LINE.test(ls[i].t)) hit++;
    }
    return hit / ls.length >= 0.5 && hit >= 4;
  }

  /* ============================ ④ 并段 ============================ */

  /* 上一行末尾 + 这一行开头怎么接:汉字直接接,拉丁词之间补一个空格,连字符断词要去掉连字符 */
  function join(a, b) {
    if (!a) return b;
    if (!b) return a;
    if (/[A-Za-z]-$/.test(a) && /^[a-z]/.test(b)) return a.slice(0, -1) + b;
    if (/[A-Za-z0-9]$/.test(a) && /^[A-Za-z0-9]/.test(b)) return a + ' ' + b;
    return a + b;
  }

  /**
   * 一页该按哪种判据分段落。
   *
   *   'indent' —— 段首有缩进(中文书的主流):看左边距。
   *   'short'  —— 没有缩进,但行是两端对齐的:看上一行有没有顶到右边距。
   *   'none'   —— 两者都量不出来(没缩进 + 左对齐)。**退到每行一段** ——
   *               宁可碎,也不能把一整章并成一个巨段(那是这一层最坏的失败方式)。
   */
  function pageMode(m) {
    if (m.twoCol) return 'none';      /* 两栏页:两条判据全失效,退到每行一段(见 measure 末尾) */
    if (m.indentRatio >= 0.2 && m.count >= 4) return 'indent';
    if (m.fullRatio >= 0.5 && m.count >= 4) return 'short';
    return 'none';
  }

  /* ============================ ⑤ 主流程 ============================ */

  /**
   * @param res  parseRaw 的结果
   * @param opt  {clean: 删页眉页脚/目录/碎行, para: 并段}
   */
  function tidy(res, opt) {
    opt = opt || {};
    var pages = res.pages || [];
    var stats = {
      pages: 0, pagesSkipped: 0, lines: 0, dropped: 0, droppedHead: 0, droppedNoise: 0,
      droppedToc: 0, droppedTocPages: 0, chapters: 0, paras: 0, chars: 0,
      conf: 0, samples: [], bad: res.bad || 0
    };

    /* --- 跨页频率(页眉页脚认人用)+ 全页置信度 --- */
    var freq = {}, confSum = 0, confN = 0;
    for (var p = 0; p < pages.length; p++) {
      var seen = {}, ls = pages[p].l;
      for (var i = 0; i < ls.length; i++) {
        confSum += ls[i].c; confN++;
        var k = normKey(ls[i].t);
        if (k && !seen[k]) { seen[k] = 1; freq[k] = (freq[k] || 0) + 1; }
      }
    }
    stats.conf = confN ? Math.round(confSum / confN * 100) / 100 : 0;
    var ctx = {
      opt: { clean: opt.clean !== false, para: opt.para !== false },
      freq: freq,
      pageCount: pages.length,
      pageConf: 0
    };

    /* --- 逐页:先删该删的,再并段 --- */
    var blocks = [];
    var cur = '';            /* 正在攒的那一段 */
    var prev = null;         /* 上一行的几何(并段要用) */
    var prevWasHead = false;

    function flush() {
      var s = trim(cur);
      if (s) blocks.push({ type: 'p', text: s });
      cur = '';
    }

    for (var pi = 0; pi < pages.length; pi++) {
      var page = pages[pi];
      var avg = 0, n = 0;
      for (var q = 0; q < page.l.length; q++) { avg += page.l[q].c; n++; }
      ctx.pageConf = n ? avg / n : 0;

      if (ctx.opt.clean && looksToc(page)) {
        stats.droppedTocPages++;
        stats.droppedToc += page.l.length;
        stats.dropped += page.l.length;
        continue;
      }

      var m = measure(page);
      var mode_ = pageMode(m);
      var used = 0;

      for (var li = 0; li < page.l.length; li++) {
        var line = page.l[li];
        var why = whyDrop(line, page, m, ctx);
        if (why) {
          stats.dropped++;
          if (why === '页眉页脚') stats.droppedHead++; else stats.droppedNoise++;
          if (stats.samples.length < 3 && why !== '装饰行') stats.samples.push(line.t);
          continue;
        }
        stats.lines++;

        /* 章节标题:自己占一段,并与前面断开 */
        var centered = m.count >= 4 && Math.abs(line.x + line.w / 2 - 0.5) < 0.06 &&
          line.w < 0.6 && line.t.length <= 16;
        var gap = prev ? (line.y - prev.y) : 1;
        var head = isHeading(line.t) ||
          (ctx.opt.clean && centered && !RE_HEAD_TAIL.test(line.t) && !isPageNumberish(line.t) &&
            (used === 0 || gap > m.pitch * 1.5));
        if (head) {
          flush();
          blocks.push({ type: 'h', text: line.t });
          stats.chapters++;
          prev = line; prevWasHead = true; used++;
          continue;
        }

        var newPara;
        if (!ctx.opt.para || !cur) {
          newPara = true;                       /* 不并段 = 每行一段 */
        } else if (prevWasHead) {
          newPara = true;                       /* 标题下面是新段的开头 */
        } else if (mode_ === 'none') {
          newPara = true;                       /* 量不出判据:退到每行一段 */
        } else if (mode_ === 'indent' && line.x - m.left > m.charW * 0.75) {
          newPara = true;                       /* 段首缩进 */
        } else if (mode_ === 'short' && prev && (prev.x + prev.w) < (m.right - m.charW * 1.5)) {
          newPara = true;                       /* 上一行没写到右边距 = 那一段完了 */
        } else if (prev && used > 0 && (line.y - prev.y) > m.pitch * 1.8) {
          newPara = true;                       /* 段间空档比行距大 */
        } else {
          newPara = false;
        }

        if (newPara) { flush(); cur = line.t; }
        else { cur = join(cur, line.t); }

        prev = line; prevWasHead = false; used++;
      }
      stats.pages++;
    }
    flush();

    /* --- 收尾:掐头去尾的空、相邻的重复段(跨页重复识别的同一段)--- */
    var out = [], dup = null;
    for (var b = 0; b < blocks.length; b++) {
      var blk = blocks[b];
      if (blk.type === 'p' && !meaningful(blk.text)) continue;
      if (dup && blk.text === dup) continue;
      out.push(blk);
      dup = blk.text;
    }
    while (out.length && out[0].type === 'p' && out[0].text.length <= 1) out.shift();

    var chars = 0, paras = 0, chapters = 0;
    for (var c = 0; c < out.length; c++) {
      if (out[c].type === 'h') chapters++;
      else { paras++; chars += out[c].text.replace(/\s/g, '').length; }
    }
    stats.chapters = chapters;
    stats.paras = paras;
    stats.chars = chars;
    stats.kept = out.length;
    return { blocks: out, stats: stats };
  }

  /** 排成最后那串文本:每个标题前面留一个空行(阅读器就是按这个切目录的) */
  function format(tidied, opt) {
    opt = opt || {};
    var blocks = (tidied && tidied.blocks) || [];
    var parts = [];
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      if (b.type === 'h') {
        if (parts.length) parts.push('');
        parts.push(b.text);
      } else {
        parts.push((opt.indent === false ? '' : '\u3000\u3000') + b.text);
      }
    }
    return parts.length ? parts.join('\n') + '\n' : '';
  }

  /* 给人看的字数:186432 → 18.6 万 */
  function humanChars(n) {
    if (n >= 100000) return (n / 10000).toFixed(1) + ' 万';
    if (n >= 10000) return (n / 10000).toFixed(2) + ' 万';
    return String(n);
  }

  root.PdfClean = {
    parseRaw: parseRaw,
    tidy: tidy,
    format: format,
    fixText: fixText,
    isHeading: isHeading,
    humanChars: humanChars
  };
})(typeof window !== 'undefined' ? window : this);
