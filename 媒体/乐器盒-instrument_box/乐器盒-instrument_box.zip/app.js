/* ============================================================
   乐器盒 · 页面逻辑
   ============================================================
   分工:audio.js 只管发声、scoreio.js 只管谱面进出、scores.js 只放数据,
   这一份管"手指落在哪儿、谱子走到哪儿、简谱画成什么样子"。

   四条自己定的规矩:
   ① **每一次桥调用都要有 catch,并且把 e.message 说给用户听** ——
      静默失败是最容易被骂的一种"没反应"。
   ② 界面上任何"替用户做决定"的事(换乐器、换曲)都不许偷偷做,只给一颗胶囊让他点。
   ③ 存档只存字符串与谱面文本,不存任何字节(mediaUrl 那种地址更不存)。
   ④ 演奏区点按立即发声、拖动滑音/刮奏;浏览只归独立的静音音域栏。
   ============================================================ */
(function () {
  'use strict';

  var A = window.JH_BOX_AUDIO;
  var IO = window.JH_PIANO_IO;
  var BUILTIN = window.JH_BOX_SCORES || [];

  var KEY_SONGS = 'box.songs.v1';     /* 与 1.0 同一把键:用户的谱子不能因为升级就没了 */
  var KEY_PREF = 'box.pref.v1';

  var state = {
    instId: 'guzheng',
    wide: false,       /* 默认可准确点弦;全景保留给整段刮奏 */
    snap: true,        /* 拉弦:音阶(按半音对齐)/ 滑音(按手指连续走) */
    label: 'jianpu',   /* 键上的字:简谱 / 音名 */
    song: null,        /* {song, notes, bars} */
    songId: null,      /* 上次在练哪一首(下次进来接着练) */
    speed: 1, transpose: 0,
    loop: false, fit: true, follow: false, click: false,
    playing: false, idx: 0,
    voices: [], times: [], endAt: 0, raf: 0, clicks: [],
    pl: null, t0: 0, schedIdx: 0, refillT: 0, clickT: 0, clickI: 0,
    rec: false, recList: [], recT0: 0, recHold: {}, recClick: 0, recNext: 0, recRaf: 0,
    vol: 0.9, wet: 0.18,
    tech: { trem: false, harm: false, mute: false },   /* 摇指/泛音/闷音:三档开关,按乐器给 */
    recent: [],                                        /* 最近弹过的乐器(换乐器一颗胶囊搞定) */
    tremRaf: 0, clickRaf: 0, clickNext: 0, clickBeat: 0, howDone: false,
    touchN: 0, pinRaf: 0, adv: false,
    userSongs: [],
    libTab: 'builtin', libLv: 'all', fam: null,
    warmKey: '', warmT: 0
  };

  var refs = { strs: [], cells: [], pads: [], whites: [], blacks: [], bands: [], bells: [] };
  var active = {};        /* pointerId → {voice, midi, target, band, mode} */
  var $ = function (id) { return document.getElementById(id); };
  function jh() { return window.JH || null; }
  function say(m) { if (jh() && JH.toast) JH.toast(m); else console.log('[乐器盒] ' + m); }
  function ping() { if (jh() && JH.sfx) JH.sfx('ok'); }
  function fail(e) { say((e && e.message) || '这一步没做成'); }
  function inst() {
    var list = A.instruments;
    for (var i = 0; i < list.length; i++) if (list[i].id === state.instId) return list[i];
    return list[0];
  }
  /** 滑杆走过的那一段上色:轨道只有 4px,靠 background 里切一刀(见 CSS 的 --p) */
  function paintRange(e) {
    if (!e) return;
    var lo = parseFloat(e.min || '0'), hi = parseFloat(e.max || '100'), v = parseFloat(e.value || '0');
    e.style.setProperty('--p', hi > lo ? Math.round((v - lo) / (hi - lo) * 100) : 0);
  }
  function paintRanges() { paintRange($('bpm')); paintRange($('vol')); paintRange($('wet')); }

  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt != null) e.textContent = txt;
    return e;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  /* ---------------- 存档(没有桥的时候退回 localStorage,方便在电脑上看) ---------------- */
  function sget(k) {
    if (jh() && JH.storage) return JH.storage.get(k);
    try { return Promise.resolve(localStorage.getItem('jhbox:' + k)); } catch (e) { return Promise.resolve(null); }
  }
  function sset(k, v) {
    if (jh() && JH.storage) return JH.storage.set(k, v);
    try { localStorage.setItem('jhbox:' + k, v); } catch (e) { return Promise.reject(e); }
    return Promise.resolve({ ok: true });
  }
  function savePrefs() {
    sset(KEY_PREF, JSON.stringify({
      instId: state.instId, wide: state.wide, snap: state.snap, label: state.label,
      speed: state.speed, vol: state.vol, wet: state.wet,
      loop: state.loop, fit: state.fit, songId: state.songId,
      tech: state.tech, recent: state.recent, howDone: state.howDone, adv: state.adv
    })).catch(function () { });
  }
  function saveSongs() {
    return sset(KEY_SONGS, JSON.stringify(state.userSongs)).then(function () { return true; }).catch(function (e) {
      if (e && e.code === 'too_large') say('本地谱子太多存不下了,先删掉几首'); else fail(e);
      say('谱子尚未保存,可先在「我的谱子」导出');
      return false;
    });
  }

  /* ---------------- 音名 / 简谱 ---------------- */
  function jpLabel(midi, key, base) {
    if (!IO) return A.midiName(midi);
    var d = IO.digits(midi, key || 'C', base == null ? 4 : base);
    var s = d.digit, i;
    for (i = 0; i < Math.min(3, d.up); i++) s += "'";
    for (i = 0; i < Math.min(3, d.low); i++) s += ',';
    return s;
  }
  function noteLabel(midi, key, base) {
    return state.label === 'jianpu' ? jpLabel(midi, key, base) : A.midiName(midi);
  }
  function noteLabelSmall(midi, key, base) {
    return state.label === 'jianpu' ? A.midiName(midi) : jpLabel(midi, key, base);
  }
  var KEYNAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  /**
   * **实际发声那一套调**。移调与音域适配都会把音挪走,而简谱记号是"相对主音"的:
   * 曲子从 C 移到 D 之后,同一个音高在 D 调里的简谱记号与在 C 调里是一样的(都是 1'),
   * 可**键上的字**要是还按 C 调算,它就会写成 2' —— 用户照着谱面按那颗写着 2' 的键,
   * 出来的正是 D 调里该写 1' 的那个音。所以:键上的字、谱面的字、读数上的字,
   * 一律按"发声这一套调"算(key2/base2)。
   */
  function songKey2() {
    var f = fitParts();
    if (!f.t && !f.k) return songKey();
    var i = KEYNAMES.indexOf(songKey());
    if (i < 0) return songKey();
    return KEYNAMES[((i + f.t + f.k) % 12 + 12) % 12];
  }
  /* 八度那一部分才是 base;调上的挪法去 key 那边(fitShift 里两样都在,得拆开算) */
  function songBase2() { return songBase() + Math.round(fitParts().o / 12); }

  function scaleList(lo, count, steps) {
    var out = [];
    for (var i = 0; i < count; i++) out.push(lo + 12 * Math.floor(i / steps.length) + steps[i % steps.length]);
    return out;
  }
  function isBlack(m) { var p = ((m % 12) + 12) % 12; return p === 1 || p === 3 || p === 6 || p === 8 || p === 10; }

  /* ============================================================
     一、把一件乐器画出来
     ------------------------------------------------------------
     六种形状,一种形状一个函数。每个函数都只做两件事:往 #surface 里摆 DOM、
     把"手指坐标能算出哪个音"需要的东西记进 refs(hit() 要用)。
     ============================================================ */
  var H_ZITHER = 178, ROW_FRET = 44, H_BOW = 54;

  function renderSurface() {
    releaseHands();
    var I = inst(), box = $('surface');
    $('stage').className = 'card stage t-' + (I.tint || 'wood');
    clear(box);
    refs = { strs: [], cells: [], pads: [], whites: [], blacks: [], bands: [], bells: [] };
    refs.wrap = null;

    if (I.ui === 'zither') renderZither(box, I);
    else if (I.ui === 'fret') renderFret(box, I);
    else if (I.ui === 'bow') renderBow(box, I);
    else if (I.ui === 'bells') renderBells(box, I);
    else if (I.ui === 'keys') renderKeys(box, I);
    else if (I.ui === 'drum') renderDrums(box, I);
    else renderPads(box, I);

    $('curName').textContent = I.name;
    $('curDesc').textContent = I.desc;
    /* 表头上那枚徽标 = 换乐器面板里那一格的小号版(同一张图、同一套底色),
       点它就能换 —— 也让"手上这件"在视觉上和别处说得上是同一件东西。 */
    var bd = $('instBadge');
    if (bd) {
      bd.className = 'badge i-' + (I.tint || 'wood');
      bd.setAttribute('aria-label', '换一件乐器(现在是' + I.name + ')');
      bd.innerHTML = TILE_SVG[I.fam] || TILE_SVG['弹拨'];
    }
    updateStageBtn();
    showNow(null, '');
    if (refs.wrap) refs.wrap.addEventListener('scroll', updateBrowse);
    updateBrowse();
    if (state.song) { renderScore(); lightNote(state.idx); }
  }

  /** 演奏台右上那一颗:每件乐器只有一件事值得切换(见 §4.4「一屏只有一颗主按钮」的同一条道理) */
  function updateStageBtn() {
    var I = inst(), b = $('sbA');
    b.hidden = false;
    if (I.ui === 'zither') { b.textContent = state.wide ? '全景' : '触弦'; b.className = 'sb' + (state.wide ? ' on' : ''); }
    else if (I.ui === 'bow') { b.textContent = state.snap ? '音阶' : '滑音'; b.className = 'sb' + (state.snap ? ' on' : ''); }
    else if (I.ui === 'pads' || I.ui === 'keys' || I.ui === 'bells') {
      b.textContent = state.label === 'jianpu' ? '简谱' : '音名'; b.className = 'sb on';
    } else { b.hidden = true; }
  }

  /** 演奏台那一句话:这一件乐器"手指该怎么动" */
  function stageTipFor(I) {
    if (I.ui === 'zither') return '点弦发声 · 横划刮奏';
    if (I.ui === 'fret') return '点品格 · 拖动滑音 / 扫弦';
    if (I.ui === 'bow') return '按住发声 · 左右滑音';
    if (I.ui === 'keys') return '点键发声 · 横划刮奏';
    if (I.ui === 'bells') return '左敲正鼓 · 右敲侧鼓';
    if (I.ui === 'drum') return '点一下响一声';
    if (I.id === 'yangqin') return '点按击弦';
    return '按住发声 · 滑动换音';
  }

  /** 乐器那一块的可用宽度:surface 在卡里 → 视口 − 页面左右 32 − 卡内边距 24 */
  function surfaceW(box) {
    var w = box.clientWidth;
    if (!w || w < 80) w = (window.innerWidth || 360) - 56;
    return Math.max(160, Math.round(w));
  }

  /* ---------- 一排弦:古筝/古琴/竖琴/卡林巴 ---------- */
  function renderZither(box, I) {
    var n = I.strings.length, W = surfaceW(box);
    /* 全景:21 根弦也要塞进一屏(窄是代价,换来的是"横着一划就是刮奏");
       触弦:每根弦 46px,好点,要横着滑着看。 */
    var w = state.wide ? Math.max(13, Math.floor((W - 4) / n)) : 46;
    if (!state.wide) w = Math.max(28, Math.min(52, Math.round(w)));
    var wrap = el('div', 'zither t-' + (I.tint || 'wood')), bed = el('div', 'bed');
    bed.style.width = (n * w) + 'px';
    bed.appendChild(el('div', 'grain'));
    bed.appendChild(el('div', 'rail top'));
    bed.appendChild(el('div', 'rail bot'));

    var deco = I.deco || 'none', i;
    var over = [];
    if (deco === 'bridge') {
      /* 雁柱:21 枚排成一道斜线 —— 筝的样子全在这道线上。
         斜的方向不是随便挑的:**低音弦的柱要离演奏端远**(柱到下岳山那一段才是拨响的弦长,
         粗弦长、细弦短),反过来画就把物理画反了。柱在弦之后画,弦才像压在柱上。 */
      for (i = 0; i < n; i++) {
        var t = i / Math.max(1, n - 1);
        var br = el('div', 'deco brg');
        br.style.left = (i * w + w / 2) + 'px';
        br.style.top = Math.round(H_ZITHER * (0.28 + 0.46 * t)) + 'px';
        over.push(br);
      }
    } else if (deco === 'hui') {
      /* 徽位:十三个泛音点。**它量的是弦长的比例**(1/8 1/6 … 7/8),所以是沿着弦排的
         —— 上一版把它们横着铺成一行,那不是徽,那是琴桥。
         真琴上徽镶在琴面外侧(七弦那一边),这里就贴着最外面一根弦摆一列。 */
      var fr = [1 / 8, 1 / 6, 1 / 5, 1 / 4, 1 / 3, 2 / 5, 1 / 2, 3 / 5, 2 / 3, 3 / 4, 4 / 5, 5 / 6, 7 / 8];
      for (i = 0; i < fr.length; i++) {
        var h = el('div', 'deco hui');
        h.style.left = '7px';
        h.style.top = Math.round(H_ZITHER * (0.06 + fr[i] * 0.88)) + 'px';
        bed.appendChild(h);
      }
    } else if (deco === 'tine') {
      var ho = el('div', 'deco hole');
      ho.style.left = '50%'; ho.style.top = '50%';
      bed.appendChild(ho);
    }

    for (i = 0; i < n; i++) {
      var m = I.strings[i];
      var cls = 'str' + (deco === 'stringcolor' ? (m % 12 === 0 ? ' strC' : (m % 12 === 5 ? ' strF' : ''))
        : (I.id === 'guzheng' || I.id === 'kalimba' ? ' metal' : ''));
      var s = el('div', cls);
      s.style.left = (i * w) + 'px';
      s.style.width = w + 'px';
      var wire = el('div', 'wire');
      /* 低音弦粗、高音弦细 —— 一根一根一样粗的弦,看着就是画出来的 */
      wire.style.height = 'auto';
      var d = (I.synth && I.synth.kind === 'ks') ? 1.0 : 1.0;
      s.style.setProperty('--wirew', (d * (0.9 + 1.5 * (1 - i / Math.max(1, n - 1)))).toFixed(2) + 'px');
      wire.style.width = 'var(--wirew)';
      wire.style.marginLeft = 'calc(var(--wirew) / -2)';
      s.appendChild(wire);
      var full = A.midiName(m), pc = m % 12;
      var lab = deco === 'stringcolor'
        ? ((pc === 0 || pc === 5) ? full.replace(/[0-9-]/g, '') : '')     /* 竖琴:红 C、蓝 F 才写字 */
        : (w >= 30 ? full : (w >= 13 ? full.replace(/[0-9-]/g, '') : ''));
      s.appendChild(el('div', 'lb', lab));
      bed.appendChild(s);
      refs.strs.push(s);
    }
    /* 雁柱后画:它要把弦"抬"起来,(画在弦底下就成了贴纸) */
    for (i = 0; i < over.length; i++) bed.appendChild(over[i]);
    wrap.appendChild(bed);
    box.appendChild(wrap);
    box.style.height = H_ZITHER + 'px';
    refs.bed = bed; refs.wrap = wrap; refs.w = w;
    $('stageTip').textContent = stageTipFor(I);
  }

  /* ---------- 有品的指板:品距是量出来的,不是均分的 ---------- */
  /**
   * 真实弦乐器上,第 n 品的柱到琴码的距离是弦长的 2^(-n/12) ——
   * 所以品格越往琴身走越密。均分的话第一品宽得像一条马路、第十二品挤成一条缝。
   * 这里把"空弦到第十二品"正好铺满一屏(第十二品落在正中,因为它的距离正好是弦长的一半),
   * 于是最低音那几品最好按,高把位自然变窄 —— 与真琴一致。
   */
  function fretX(k, pad, span) { return pad + span * (1 - Math.pow(2, -k / 12)); }

  function renderFret(box, I) {
    var rows = I.strings.length, frets = I.frets || 12;
    var pad = 6, W = Math.max(560, surfaceW(box) * 2.2);      /* 一屏放不下 12 品,能滑着看 */
    /* 第十二品到琴码的距离正好是弦长的一半 → span 取 2 倍,第十二品就落在 W 上 */
    var span = 2 * (W - pad);
    var wrap = el('div', 'fret'), bed = el('div', 'bed');
    bed.style.width = (W + 6) + 'px';
    bed.style.height = (rows * ROW_FRET) + 'px';

    var nut = el('div', 'nut'); nut.style.left = (pad - 5) + 'px'; bed.appendChild(nut);
    var f, r;
    for (f = 1; f <= frets; f++) {
      var fl = el('div', 'fline');
      fl.style.left = (fretX(f, pad, span) - 1) + 'px';
      bed.appendChild(fl);
    }
    /* 品位记号:3 / 5 / 7 / 9 / 12(第十二品就在正中间,看得见自己到哪儿了) */
    var dots = [3, 5, 7, 9, 12];
    for (var di = 0; di < dots.length; di++) {
      f = dots[di];
      var x0 = f === 1 ? pad : fretX(f - 1, pad, span), x1 = fretX(f, pad, span);
      var mk = el('div', 'mark');
      mk.style.left = ((x0 + x1) / 2) + 'px';
      mk.style.top = Math.round(rows * ROW_FRET / 2) + 'px';
      bed.appendChild(mk);
    }
    for (r = 0; r < rows; r++) {
      var row = el('div', 'srow');
      row.style.top = (r * ROW_FRET) + 'px';
      var wire = el('div', 'swire');
      var th = Math.max(1, Math.round((3.6 - r * 0.36) * 10) / 10);
      wire.style.height = th + 'px';
      wire.style.marginTop = (-th / 2) + 'px';
      wire.style.top = '50%';
      row.appendChild(wire);
      bed.appendChild(row);
      for (f = 0; f <= frets; f++) {
        var a = f === 0 ? pad - 6 : fretX(f, pad, span);
        var b = f >= frets ? (W + 6) : fretX(f + 1, pad, span);
        if (b < a + 40) b = a + 40;
        var c = el('button', 'cell');
        c.style.left = a + 'px';
        c.style.width = (b - a) + 'px';
        c.style.top = (r * ROW_FRET) + 'px';
        c.setAttribute('aria-label', '第' + (r + 1) + '弦' + (f ? '第' + f + '品' : '空弦'));
        if (f === 3 || f === 5 || f === 7 || f === 12) c.appendChild(el('span', 'dot'));
        bed.appendChild(c);
        refs.cells.push({ el: c, midi: I.strings[r] + f, row: r, fret: f, x0: a, x1: b });
      }
    }
    wrap.appendChild(bed);
    box.appendChild(wrap);
    box.style.height = (rows * ROW_FRET) + 'px';
    refs.bed = bed; refs.wrap = wrap;
    $('stageTip').textContent = stageTipFor(I);
  }

  /** 两根弦的中国弓子:低的叫内弦、高的叫外弦;四根弦的直接报音名 */
  function bowName(I, open) {
    var nm = A.midiName(open);
    if (I.strings.length !== 2) return nm;
    var lo = Math.min(I.strings[0], I.strings[1]);
    return (open === lo ? '内弦 ' : '外弦 ') + nm;
  }
  function renderBow(box, I) {
    var wrap = el('div', 'bow'), span = I.span || 24, r, k;
    for (r = 0; r < I.strings.length; r++) {
      var band = el('div', 'band');
      band.appendChild(el('div', 'tietou'));
      band.appendChild(el('div', 'swire'));
      band.appendChild(el('div', 'oname', bowName(I, I.strings[r])));
      for (k = 0; k <= span; k++) {
        var t = el('div', 'tick' + (k % 12 === 0 ? ' maj' : ''));
        t.style.left = (k / span * 100) + '%';
        band.appendChild(t);
      }
      /* 每十二个半音标一次音名:手指在哪儿、是哪个音,一眼能对上 */
      for (k = 12; k <= span; k += 12) {
        var lb = el('div', 'tlab', A.midiName(I.strings[r] + k));
        lb.style.left = (k / span * 100) + '%';
        if (k >= span) { lb.style.transform = 'translateX(-100%)'; lb.style.right = '2px'; lb.style.left = 'auto'; }
        band.appendChild(lb);
      }
      var sled = el('div', 'sled');
      band.appendChild(sled);
      wrap.appendChild(band);
      refs.bands.push({ el: band, open: I.strings[r], sled: sled });
    }
    box.appendChild(wrap);
    box.style.height = (I.strings.length * (H_BOW + 8) - 8) + 'px';
    refs.wrap = wrap; refs.span = span;
    $('stageTip').textContent = stageTipFor(I);
  }

  /* ---------- 音键方块:吹管与扬琴 ---------- */
  function renderPads(box, I) {
    var key = songKey2(), base = songBase2();
    var list = scaleList(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9, 11]);
    var wrap = el('div', 'pads ' + (list.length > 15 ? 'p6' : 'p5') + (I.padShape === 'hole' ? ' round' : ''));
    for (var i = 0; i < list.length; i++) {
      var p = el('button', 'pad');
      p.appendChild(el('span', null, noteLabel(list[i], key, base)));
      p.appendChild(el('span', 'sm', noteLabelSmall(list[i], key, base)));
      p.setAttribute('aria-label', A.midiName(list[i]));
      wrap.appendChild(p);
      refs.pads.push({ el: p, midi: list[i] });
    }
    box.appendChild(wrap);
    box.style.height = '';
    refs.wrap = null;
    $('stageTip').textContent = stageTipFor(I);
  }

  /* ---------- 编钟:一钟双音 ---------- */
  function renderBells(box, I) {
    var key = songKey2(), base = songBase2();
    var list = scaleList(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9]);
    var wrap = el('div', 'bells');
    for (var i = 0; i < list.length; i++) {
      var b = el('button', 'bell');
      var body = el('div', 'body');
      body.appendChild(el('span', null, noteLabel(list[i], key, base)));
      body.appendChild(el('span', 'seam'));
      b.appendChild(body);
      b.setAttribute('aria-label', A.midiName(list[i]) + ',敲右半边是' + A.midiName(list[i] + (I.padDual || 3)));
      wrap.appendChild(b);
      refs.pads.push({ el: b, midi: list[i], dual: I.padDual || 3 });
      refs.bells.push({ el: b, body: body });
    }
    box.appendChild(wrap);
    box.style.height = '';
    refs.wrap = null;
    $('stageTip').textContent = stageTipFor(I);
  }

  /* ---------- 钢琴键盘 ---------- */
  function renderKeys(box, I) {
    var key = songKey2(), base = songBase2();
    var ww = 45, bw = 30, H = 172, i, m;
    var whites = [], blacks = [];
    for (m = I.keysLo; m <= I.keysHi; m++) { if (isBlack(m)) blacks.push(m); else whites.push(m); }
    var wrap = el('div', 'keys'), bed = el('div', 'bed');
    bed.style.width = (whites.length * ww) + 'px';
    bed.style.height = H + 'px';
    for (i = 0; i < whites.length; i++) {
      var w = el('button', 'wk', noteLabel(whites[i], key, base));
      w.style.left = (i * ww) + 'px';
      w.style.width = (ww - 1) + 'px';
      w.setAttribute('aria-label', A.midiName(whites[i]));
      bed.appendChild(w);
      refs.whites.push({ el: w, midi: whites[i] });
    }
    for (i = 0; i < blacks.length; i++) {
      var at = -1;
      for (var j = 0; j < whites.length; j++) if (whites[j] === blacks[i] - 1) at = j;
      if (at < 0) continue;
      var b = el('button', 'bk');
      b.style.left = ((at + 1) * ww - bw / 2) + 'px';
      b.style.width = bw + 'px';
      b.setAttribute('aria-label', A.midiName(blacks[i]));
      bed.appendChild(b);
      refs.blacks.push({ el: b, midi: blacks[i], left: (at + 1) * ww - bw / 2, w: bw });
    }
    wrap.appendChild(bed);
    box.appendChild(wrap);
    box.style.height = H + 'px';
    refs.bed = bed; refs.wrap = wrap; refs.ww = ww;
    $('stageTip').textContent = stageTipFor(I);
  }

  /* ---------- 打击垫 ---------- */
  function renderDrums(box, I) {
    var cols = I.pads.length <= 3 ? I.pads.length : (I.pads.length === 4 ? 4 : 3);
    var wrap = el('div', 'drums');
    wrap.style.gridTemplateColumns = 'repeat(' + cols + ',1fr)';
    for (var i = 0; i < I.pads.length; i++) {
      var p = el('button', 'drum' + (/锣|镲|钹|铃|三角/.test(I.pads[i].name) ? ' metal' : ''));
      p.appendChild(el('div', 'head', I.pads[i].name));
      p.setAttribute('aria-label', I.pads[i].name);
      wrap.appendChild(p);
      refs.pads.push({ el: p, idx: i });
    }
    box.appendChild(wrap);
    box.style.height = '';
    refs.wrap = null;
    $('stageTip').textContent = stageTipFor(I);
  }

  /** 当前这一族此刻生效的"发声花样":泛音 / 闷音 / 都不用 */
  function techKind(I) {
    var u = I.ui;
    if (state.tech.harm && (u === 'zither' || u === 'fret' || u === 'keys')) return 'harm';
    if (state.tech.mute && u === 'fret') return 'mute';
    return null;
  }
  /** 这一件乐器有哪些技法(技法抽屉照这个列) */
  function techList(I) {
    var u = I.ui, L = [];
    if (u === 'zither') {
      L.push({ k: 'trem', name: '摇指', tip: '按住一根弦别松手,停一下就自己来回拨 —— 筝的摇指、琵琶的轮指都是它' });
      L.push({ k: 'harm', name: '泛音', tip: '出来的是高一个八度、薄而亮的那一层(轻触弦长一半处)' });
      L.push({ g: '按音', tip: '按住弦上下拖 —— 往下拖把音推高,最多两个半音,就是左手的按弦' });
      L.push({ g: '刮奏', tip: '横着划过去,一划一串' });
    } else if (u === 'fret') {
      L.push({ g: '扫弦', tip: '竖着拖过几根弦 —— 拖多快就是多快' });
      L.push({ g: '击弦 / 勾弦', tip: '拖过去时新出来的音会轻一点,正合 hammer-on 的味道' });
      L.push({ g: '滑音', tip: '按住横向拖到别的品,一路点着滑过去' });
      L.push({ k: 'mute', name: '闷音', tip: '掌根压住弦:剩一百来毫秒的"哒",专门拿来打节奏' });
    } else if (u === 'bow') {
      L.push({ g: '揉弦', tip: '按住之后手指在原处上下抖 —— 抖得越大揉得越深' });
      L.push({ g: '滑音', tip: '横向拖到哪儿滑到哪儿(「音阶」档按半音对齐,「滑音」档连着走)' });
      L.push({ g: '双音', tip: '两根手指同时按两根弦就是双音' });
    } else if (u === 'pads') {
      L.push({ g: '颤音 / 花舌', tip: '按住来回蹭相邻两个音,就是打音与花舌' });
      L.push({ g: '一口气', tip: '按住不松一直响;松手就是断气' });
    } else if (u === 'keys') {
      L.push({ k: 'harm', name: '泛音', tip: '键盘上也给一层泛音(钢片琴那种清亮)' });
      L.push({ g: '刮奏', tip: '横着划过去' });
      L.push({ g: '和弦', tip: '几根手指同时按就是几个音' });
    } else if (u === 'bells') {
      L.push({ g: '一钟双音', tip: '敲左半边是正鼓、右半边是侧鼓(高大三度)' });
    } else {
      L.push({ k: 'trem', name: '滚奏', tip: '点住不放就是鼓的滚奏' });
    }
    return L;
  }

  /* ============================================================
     二、手指落在哪儿
     ============================================================ */
  function bindSurface() {
    var box = $('surface');
    box.addEventListener('pointerdown', onDown);
    box.addEventListener('pointermove', onMove);
    box.addEventListener('pointerup', onUp);
    box.addEventListener('pointercancel', onUp);
    box.addEventListener('lostpointercapture', onUp);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    window.addEventListener('blur', suspend);
    window.addEventListener('pagehide', suspend);
    document.addEventListener('visibilitychange', function () { if (document.hidden) suspend(); });
    /* 换向 / 换屏宽之后,弦距与品距都得重算 —— 不然横过来用就成了另一个乐器 */
    var rt = 0;
    window.addEventListener('resize', function () {
      if (rt) clearTimeout(rt);
      rt = setTimeout(function () { rt = 0; renderSurface(); }, 180);
    });
  }

  function hit(ev) {
    /* 手指位置 → {midi, el, target, …}。画不出目标就回 null */
    var I = inst(), r, x, y;
    var edge = $('surface').getBoundingClientRect();
    if (ev.clientX < edge.left || ev.clientX >= edge.right || ev.clientY < edge.top || ev.clientY >= edge.bottom) return null;
    if (I.ui === 'zither') {
      r = refs.bed.getBoundingClientRect();
      var i = Math.floor((ev.clientX - r.left) / refs.w);
      if (i < 0 || i >= I.strings.length) return null;
      var yv = (ev.clientY - r.top) / r.height;
      return { midi: I.strings[i], el: refs.strs[i], target: i, vel: velFromY(yv) };
    }
    if (I.ui === 'fret') {
      r = refs.bed.getBoundingClientRect();
      x = ev.clientX - r.left; y = ev.clientY - r.top;
      var row = Math.floor(y / ROW_FRET);
      if (row < 0 || row >= I.strings.length) return null;
      var f = -1;
      for (var k = 0; k < I.frets + 1; k++) {
        var c = refs.cells[row * (I.frets + 1) + k];
        if (c && x >= c.x0 && x < c.x1) { f = k; break; }
      }
      var cc = f >= 0 ? refs.cells[row * (I.frets + 1) + f] : null;
      return cc ? { midi: cc.midi, el: cc.el, target: row * 1000 + f, vel: 0.9 } : null;
    }
    if (I.ui === 'bow') {
      var bi = Math.floor((ev.clientY - refs.wrap.getBoundingClientRect().top) / (H_BOW + 8));
      if (bi < 0 || bi >= refs.bands.length) return null;
      var band = refs.bands[bi];
      var br = band.el.getBoundingClientRect();
      if (ev.clientY < br.top || ev.clientY >= br.bottom) return null;
      var ratio = clamp((ev.clientX - br.left) / br.width, 0, 1);
      return { midi: band.open + Math.round(ratio * refs.span), el: band.el,
        target: bi, band: band, ratio: ratio, vel: 0.9 };
    }
    if (I.ui === 'keys') {
      r = refs.bed.getBoundingClientRect();
      x = ev.clientX - r.left; y = ev.clientY - r.top;
      var o;
      for (k = 0; k < refs.blacks.length; k++) {
        o = refs.blacks[k];
        if (y < 106 && x >= o.left && x <= o.left + o.w) {
          return { midi: o.midi, el: o.el, target: 'b' + k, vel: clamp(0.55 + 0.45 * (y / 106), 0.4, 1) };
        }
      }
      var wi = Math.floor(x / refs.ww);
      if (wi < 0 || wi >= refs.whites.length) return null;
      return { midi: refs.whites[wi].midi, el: refs.whites[wi].el, target: 'w' + wi,
        vel: clamp(0.5 + 0.5 * (y / 172), 0.35, 1) };
    }
    /* pads / bells / drums:直接问是谁 */
    var node = document.elementFromPoint(ev.clientX, ev.clientY);
    if (!node || !node.closest) return null;
    var pe = node.closest('.pad') || node.closest('.drum') || node.closest('.bell');
    if (!pe) return null;
    for (var p = 0; p < refs.pads.length; p++) {
      if (refs.pads[p].el !== pe) continue;
      var it = refs.pads[p];
      if (it.dual) {
        var br2 = pe.getBoundingClientRect();
        var right = ev.clientX > br2.left + br2.width / 2;
        return { midi: it.midi + (right ? it.dual : 0), el: pe, target: p, side: right ? '侧鼓' : '正鼓', vel: 0.95 };
      }
      return it.midi != null
        ? { midi: it.midi, el: pe, target: p, vel: 0.9 }
        : { idx: it.idx, el: pe, target: p };
    }
    return null;
  }
  /** 弦上按的位置越靠下(离雁柱越远)越"实" —— 力度不该每一下都一样 */
  function velFromY(t) { return clamp(0.72 + 0.3 * clamp(t, 0, 1), 0.6, 1); }

  /* ---------- 手指按在乐器上的这段时间,页面的滚动位置钉住 ----------
     为什么还要这一层:touch-action 只是"告诉浏览器该如何判定",而各家的 WebView 在
     "横向滚动容器 + 竖向扒拉"这件事上并不一致(桌面 Chromium 会把这一串手势吃掉,
     安卓 WebView 会链给页面)。用户要的是"扒拉乐器的时候页面别动" ——
     那就别指望别人,手指按着的这几百毫秒里,滚动位置被人动过就拉回来。 */
  function pinPage() {
    var sc = $('scroll');
    if (!sc || state.pinRaf) return;
    state.pinTop = sc.scrollTop;
    state.pinRaf = requestAnimationFrame(pinStep);
  }
  function pinStep() {
    state.pinRaf = 0;
    var sc = $('scroll');
    if (!sc || state.touchN <= 0) return;
    if (sc.scrollTop !== state.pinTop) sc.scrollTop = state.pinTop;   /* 被动过就拉回来 */
    state.pinRaf = requestAnimationFrame(pinStep);
  }

  function onDown(ev) {
    if ((ev.pointerType === 'mouse' && ev.button !== 0) || active[ev.pointerId]) return;
    if (sheetOpen()) return;
    A.unlock();
    /* **落在乐器上的手指一律不交给浏览器** —— 命中也好、落在弦之间的空处也好:
       不然它会去选中文字、弹长按菜单,或者(某些 WebView 上)把这串手势判给页面翻页。
       原来这一句写在 hit() 后面 —— 落空的时候连它都没调,那正是"有的时候页面自己滑走"的来源。 */
    ev.preventDefault();
    var h = hit(ev);
    if (!h) return;
    state.touchN++;
    pinPage();
    try { $('surface').setPointerCapture(ev.pointerId); } catch (e) { }
    var I = inst();
    if (I.ui === 'drum' || (I.synth && I.synth.kind === 'drum')) {
      if (h.idx == null) return;
      A.hit(I, h.idx, 0.95);
      flash(h.el);
      showNow(I.pads[h.idx].name, '');
      checkFollow(-1, h.idx);
      active[ev.pointerId] = { idx: h.idx, el: h.el, mode: 'play', vel: 0.95,
        startX: ev.clientX, startY: ev.clientY, t0: Date.now(), scroll: 0, tremNext: Date.now() + 220 };
      tremStart();
      recOn(36 + h.idx);
      return;
    }
    var v = A.noteOn(I, h.midi, h.vel || 0.9, 0, null, techKind(I));
    active[ev.pointerId] = { voice: v, midi: h.midi, base: h.midi, target: h.target, band: h.band, mode: 'play',
      startX: ev.clientX, startY: ev.clientY, t0: Date.now(), scroll: 0, bend: 0, tremNext: Date.now() + 220 };
    tremStart();
    flash(h.el);
    if (h.band) moveSled(h.band, h.ratio);
    showNow(h.midi, posText(h, I));
    recOn(h.midi);
    checkFollow(h.midi);
  }

  function onMove(ev) {
    var a = active[ev.pointerId];
    if (!a) return;
    ev.preventDefault();
    var I = inst();
    var h = hit(ev);
    if (!h) { onUp(ev); return; }
    if (a.idx != null) return;
    if (a.band && h.band !== a.band) return;
    if (a.band) {
      /* 拉弦:音阶档按半音对齐,滑音档连着走 */
      var m = state.snap ? h.midi : a.band.open + clamp((ev.clientX - a.band.el.getBoundingClientRect().left) / a.band.el.getBoundingClientRect().width, 0, 1) * refs.span;
      if (Math.abs(m - a.midi) > 0.001) {
        if (state.snap) {
          if (a.voice) { try { a.voice.release(); } catch (e) { } recOff(a.midi); }
          a.voice = A.noteOn(I, m, 0.9);
          recOn(m);
        } else if (a.voice && a.voice.glide) a.voice.glide(m);
        a.midi = m;
        showNow(Math.round(m), posText(h, I));
      } else if (a.voice && a.voice.vib) {
        /* 音高没动、手指在原处上下抖 —— 那就是揉弦(左手的事) */
        var vy = ev.clientY - a.startY;
        var dep = clamp(Math.abs(vy) / 55, 0, 1);
        a.voice.vib(dep * 42);
        $('nowPos').textContent = dep > 0.15 ? '揉弦 ' + Math.round(dep * 100) + '%' : '';
      }
      moveSled(a.band, h.ratio);
      return;
    }
    if (h.target === a.target) {
      /* 还按在同一根弦/同一个音上 —— 那手指的上下动就不是"换音",是左手:
         筝上是按音(把音推高),拉弦上是揉弦(在原处抖)。 */
      if (I.ui === 'zither' && a.voice && a.voice.glide) {
        var dy = ev.clientY - a.startY, dx2 = ev.clientX - a.startX;
        if (Math.abs(dy) > 6 && Math.abs(dy) > Math.abs(dx2)) {
          a.bend = clamp(dy / 90, -1, 1) * (I.bend || 2);
          var mb = a.base + a.bend;
          a.voice.glide(mb);
          a.midi = mb;
          showNow(Math.round(mb), (a.bend > 0.05 ? '按音 +' : '按音 ') + a.bend.toFixed(1) + ' 半音');
        }
      }
      return;
    }
    /* 弦与键盘:手指划过去 = 一串音(刮奏/扫弦)。
       上一版这里用 stop() 把上一根弦掐断 —— 拨响的弦不该被掐,现在是 release(),
       弹拨那一族 release 就是"让它自己响完",刮奏与扫弦才连得成一片。 */
    if (a.voice) { try { a.voice.release(); } catch (e) { } recOff(a.midi); }
    var v = A.noteOn(I, h.midi, (h.vel || 0.85) * 0.9, 0, null, techKind(I));
    a.voice = v; a.midi = h.midi; a.target = h.target;
    flash(h.el);
    showNow(h.midi, posText(h, I));
    recOn(h.midi);
    checkFollow(h.midi);
  }

  function onUp(ev) {
    var a = active[ev.pointerId];
    if (!a) return;
    /* Chromium 的触摸激活落在 pointerup;首次落指时尚未获准,松手再唤醒。 */
    if (ev.type === 'pointerup' && ev.isTrusted) A.unlock();
    state.touchN = Math.max(0, state.touchN - 1);
    if (a.voice) { try { a.voice.release(); } catch (e) { } recOff(a.midi); }
    if (a.idx != null) recOff(36 + a.idx);
    if (a.base != null && a.base !== a.midi) recOff(a.base);
    if (a.band) a.band.el.classList.remove('lit');
    delete active[ev.pointerId];
    try { if ($('surface').hasPointerCapture(ev.pointerId)) $('surface').releasePointerCapture(ev.pointerId); } catch (e) { }
    if (!state.touchN && state.pinRaf) { cancelAnimationFrame(state.pinRaf); state.pinRaf = 0; }
  }

  function releaseHands() {
    Object.keys(active).forEach(function (id) { onUp({ pointerId: +id }); });
    if (state.tremRaf) cancelAnimationFrame(state.tremRaf);
    state.tremRaf = 0;
  }
  function suspend() {
    releaseHands();
    state.click = false;
    $('btnClick').className = 'chip';
    stopPlay();
    if (state.rec) finishRec(true);
  }

  /* 静音音域栏只改变可见位置,不触碰音频引擎。 */
  function updateBrowse() {
    var wrap = refs.wrap, max = wrap ? Math.max(0, wrap.scrollWidth - wrap.clientWidth) : 0;
    $('browseBar').hidden = max <= 2;
    if (max <= 2) return;
    $('browseRange').max = Math.round(max);
    $('browseRange').value = Math.round(wrap.scrollLeft);
    $('browseLow').disabled = wrap.scrollLeft <= 1;
    $('browseHigh').disabled = wrap.scrollLeft >= max - 1;
    var at = Math.max(0, wrap.scrollLeft), end = at + wrap.clientWidth;
    var notes = [];
    if (inst().ui === 'keys') refs.whites.forEach(function (n, i) { if ((i + 1) * refs.ww > at && i * refs.ww < end) notes.push(A.midiName(n.midi)); });
    if (inst().ui === 'zither') inst().strings.forEach(function (m, i) { if ((i + 1) * refs.w > at && i * refs.w < end) notes.push(A.midiName(m)); });
    if (inst().ui === 'fret') {
      refs.cells.filter(function (c) { return c.row === 0 && c.x1 > at && c.x0 < end; }).forEach(function (c) { notes.push(c.fret); });
    }
    $('browseLabel').textContent = '静音浏览 ' + (notes.length ? notes[0] + '–' + notes[notes.length - 1] + (inst().ui === 'fret' ? '品' : '') : '音域');
  }
  function browseBy(dir) {
    if (!refs.wrap) return;
    releaseHands();
    var step = inst().ui === 'keys' ? refs.ww * 7 : refs.wrap.clientWidth * 0.8;
    refs.wrap.scrollLeft += step * dir;
    updateBrowse();
  }

  /* ---------- 摇指 / 轮指 / 滚奏:按住不放,自己来回 ----------
     真乐器上这是手腕的事:筝叫摇指、琵琶叫轮指、鼓叫滚奏,说的都是同一件事 ——
     同一个音在几十毫秒的间隔上被反复激发。所以这里就是一个 rAF 循环,
     间隔 70ms 上下抖一点(不抖的话听着像电子节拍器,不像手)。 */
  function tremStart() {
    if (!state.tech.trem || state.tremRaf) return;
    state.tremRaf = requestAnimationFrame(tremStep);
  }
  function tremStep() {
    state.tremRaf = 0;
    if (!state.tech.trem) return;
    var I = inst(), now = Date.now(), any = false, id, a;
    for (id in active) {
      if (!active.hasOwnProperty(id)) continue;
      a = active[id];
      if (!a || a.mode !== 'play') continue;
      any = true;
      if (now < (a.tremNext || 0)) continue;
      if (I.ui === 'drum') {
        if (a.idx != null) { A.hit(I, a.idx, 0.5 + Math.random() * 0.22); flash(a.el); }
      } else if (a.midi != null) {
        A.noteOn(I, a.base + a.bend, 0.48 + Math.random() * 0.2, 0, null, techKind(I));
      }
      a.tremNext = now + 70 + Math.random() * 22;
    }
    if (any) state.tremRaf = requestAnimationFrame(tremStep);
  }

  /* ---------- 跟弹:把"下一个该按哪儿"指给他 ---------- */
  function markTarget(midi) {
    var box = $('surface'), i, k;
    var old = box.querySelectorAll('.next');
    for (k = 0; k < old.length; k++) old[k].classList.remove('next');
    if (midi == null) return;
    var I = inst();
    if (I.ui === 'zither') {
      for (i = 0; i < I.strings.length; i++) if (I.strings[i] === midi) { refs.strs[i].classList.add('next'); centerX(i * refs.w + refs.w / 2); }
    } else if (I.ui === 'fret') {
      for (i = 0; i < I.strings.length; i++) {
        var f = midi - I.strings[i];
        if (f >= 0 && f <= I.frets) {
          var c = refs.cells[i * (I.frets + 1) + f];
          if (c) { c.el.classList.add('next'); centerX((c.x0 + c.x1) / 2); }
          break;
        }
      }
    } else if (I.ui === 'keys') {
      for (i = 0; i < refs.whites.length; i++) if (refs.whites[i].midi === midi) { refs.whites[i].el.classList.add('next'); centerX(i * refs.ww + refs.ww / 2); }
      for (i = 0; i < refs.blacks.length; i++) if (refs.blacks[i].midi === midi) { refs.blacks[i].el.classList.add('next'); centerX(refs.blacks[i].left + refs.blacks[i].w / 2); }
    } else if (I.ui === 'pads' || I.ui === 'bells') {
      for (i = 0; i < refs.pads.length; i++) if (refs.pads[i].midi === midi) refs.pads[i].el.classList.add('next');
    } else if (I.ui === 'drum') {
      /* 谱面上的音按"第几面鼓"读:圈出该打的那一面 */
      var pd = (I.pads || []).length;
      if (pd) {
        var pi = (((midi - 36) % pd) + pd) % pd;
        for (i = 0; i < refs.pads.length; i++) if (refs.pads[i].idx === pi) { refs.pads[i].el.classList.add('next'); break; }
      }
    } else if (I.ui === 'bow') {
      for (i = 0; i < refs.bands.length; i++) {
        var sc = midi - refs.bands[i].open;
        if (sc >= 0 && sc <= refs.span) moveSled(refs.bands[i], sc / refs.span);
      }
    }
  }
  /** 手指数完一遍之后把还亮着的弦/键关掉 */
  function markRelease() {
    for (var i = 0; i < refs.strs.length; i++) refs.strs[i].classList.remove('lit');
    for (i = 0; i < refs.pads.length; i++) refs.pads[i].el.classList.remove('lit');
  }

  function moveSled(band, ratio) {
    band.el.classList.add('lit');
    band.sled.style.left = (clamp(ratio, 0, 1) * 100) + '%';
  }
  function flash(node) {
    if (!node) return;
    node.classList.add('lit');
    setTimeout(function () { node.classList.remove('lit'); }, 240);
  }
  function posText(h, I) {
    if (I.ui === 'zither') return '第 ' + (h.target + 1) + ' 弦';
    if (I.ui === 'fret') { var f = h.target % 1000; return '第 ' + (Math.floor(h.target / 1000) + 1) + ' 弦 · ' + (f ? '第 ' + f + ' 品' : '空弦'); }
    if (I.ui === 'bow') return '按在 ' + A.midiName(h.midi) + ' 上';
    if (I.ui === 'bells') return h.side || '';
    return '';
  }
  function showNow(midi, pos) {
    var n = $('nowMidi'), nm = $('nowName');
    if (midi == null) { n.textContent = ''; nm.textContent = ''; $('nowPos').textContent = pos || ''; return; }
    if (typeof midi === 'number') {
      n.textContent = jpLabel(midi, songKey2(), songBase2());
      nm.textContent = A.midiName(midi) + (A.midiNameFlat(midi) !== A.midiName(midi) && /#/.test(A.midiName(midi))
        ? ' / ' + A.midiNameFlat(midi) : '');
    } else {
      n.textContent = midi; nm.textContent = '';
    }
    $('nowPos').textContent = pos || '';
  }

  /* ============================================================
     三、谱子:载入、画成简谱、自动演奏、跟弹、录制
     ============================================================ */
  function prepSong(song) {
    if (!IO) return null;
    var lib = IO.buildLibrary([song], []);
    var it = lib.items && lib.items[0];
    if (!it || it.error || !it.notes || !it.notes.length) return null;
    return { song: song, notes: it.notes, bars: it.bars || [] };
  }

  function loadSong(song, keepIdx) {
    var p = prepSong(song);
    if (!p) { say('这段谱子一个音都没读出来'); return; }
    state.song = p;
    state.songId = song.id || null;
    if (!keepIdx) state.idx = 0;
    stopPlay(true);
    renderScore();
    renderSongHead();
    pushWidget();
    savePrefs();
    /* 键上的字跟着调走(简谱的数字是相对主音的) */
    var I = inst();
    if (I.ui === 'pads' || I.ui === 'keys' || I.ui === 'bells') renderSurface();
    lightNote(state.idx);
    kickWarm();
  }

  /* ---------- 预算音色:趁用户还在挑曲子,把这一首要用的拨弦缓冲先算出来 ----------
     拨弦声是按物理弦模型**现算**缓冲的(一颗 3 秒的弦要跑十几万格采样,手机上要几毫秒)。
     开演那一瞬间挤着算几十颗,主线程就被堵住:该响的音迟到、音频欠载,听感是一串
     "沙拉沙拉";更早一版还表现为"开头第一句不响" —— 同一个根子,两种症状。
     所以趁用户挑曲子 / 看谱面的这段空当,分片算完(每片 12ms,不挡界面)。
     算不完也不影响用:没算到的音退回现算现响,只是老样子。 */
  function kickWarm() {
    if (!state.song || !A || !A.warm) return;
    var I = inst(), notes = state.song.notes, pl = state.pl;
    if (!pl) pl = state.pl = planSong(notes, state.song.bars, I);
    var key = I.id + '|' + (state.songId || state.song.title) + '|' + notes.length + '|' + pl.steps.length;
    if (state.warmKey === key) return;
    state.warmKey = key;
    if (state.warmT) { clearTimeout(state.warmT); state.warmT = 0; }
    var jobs = [], i;
    for (i = 0; i < notes.length; i++) {
      if (notes[i].rest) continue;
      var st = pl.steps[i];
      if (!st || st.rest) continue;
      var m = midiOf(notes[i]);
      if (m == null) continue;
      jobs.push([I, m, st.hold, st.vel]);
    }
    if (!jobs.length) return;
    var idx = 0;
    (function slice() {
      state.warmT = 0;
      if (state.warmKey !== key) return;          /* 换谱/换乐器了,这一趟作废 */
      var t0 = Date.now();
      while (idx < jobs.length && Date.now() - t0 < 12) {
        var j = jobs[idx++];
        try { A.warm(j[0], j[1], j[2], j[3], null); } catch (e) { return; }
      }
      if (idx < jobs.length) state.warmT = setTimeout(slice, 0);
    })();
  }

  function songKey() { return (state.song && state.song.song.key) || 'C'; }
  /* 上一版这里写的是 `(state.song && state.song.song.base == null ? 4 : state.song.song.base)` ——
     没有谱子时前半段整个是 null,三元就走到 else 去读 `state.song.song`,当场 TypeError。
     后果不是"少一个八度",是**整个演奏台画不出来**:选中吹管/键盘那一类再打开插件,
     页面就是一片空台面。所以这个字面量必须拆成两步写。 */
  function songBase() {
    if (!state.song || state.song.song.base == null) return 4;
    return state.song.song.base;
  }
  function songBpm() { return (state.song && state.song.song.bpm) || 92; }
  function beatSec() { return 60 / songBpm() / state.speed; }

  function renderSongHead() {
    if (!state.song) {
      $('songTitle').textContent = '还没有谱子';
      $('songMeta').textContent = '点右上「曲库」挑一首,或者自己粘一段简谱';
      clear($('recChips'));
      $('playNote').textContent = '';
      return;
    }
    var s = state.song.song, i;
    $('songTitle').textContent = s.title || '未命名';
    /* 时长也读那张时间表:句尾留白、曲终那半秒都算在里面 —— 与耳朵听到的保持一致 */
    var sec = Math.round(planSong(state.song.notes, state.song.bars, inst()).total);
    $('songMeta').textContent = state.song.notes.length + ' 个音 · 约 ' + sec + ' 秒 · '
      + Math.round(songBpm() * state.speed) + ' BPM';
    /* 推荐乐器:只给一颗胶囊,不替用户换(§ 文件头第 ② 条) */
    var box = $('recChips'); clear(box);
    if (s.inst && s.inst !== state.instId) {
      var want = null, list = A.instruments;
      for (i = 0; i < list.length; i++) if (list[i].id === s.inst) want = list[i];
      if (want) {
        var c = el('button', 'chip', '这首适合' + want.name);
        c.setAttribute('aria-label', '换成' + want.name);
        c.onclick = function () { setInst(want.id); };
        box.appendChild(c);
      }
    }
    updateFitNote();
  }

  /** 音域适配:挪了要说话,不能偷偷整体移一个八度 */
  function updateFitNote() {
    var f = fitParts(), parts = [];
    if (f.k) parts.push('按这件乐器的定弦弹在 ' + songKey2() + ' 调上(筝/箫这类乐器的老规矩)');
    if (f.o > 0) parts.push('谱子偏低,已整体上移 ' + (f.o / 12) + ' 个八度');
    else if (f.o < 0) parts.push('谱子偏高,已整体下移 ' + (-f.o / 12) + ' 个八度');
    if (f.t) parts.push('移调 ' + (f.t > 0 ? '+' : '') + f.t + ' 个半音');
    $('playNote').textContent = parts.join(';');
  }

  /* ---------- 简谱:数字 + 八度点 + 减时线 + 增时线 + 附点 ---------- */
  /**
   * 一节一节地排(小节不许被折行切开),每个音画成它本来的样子:
   *   0.25 拍 → 数字下面两条线(十六分)  0.5 拍 → 一条线(八分)
   *   1 拍    → 光一个数字              1.5 拍 → 右边一个附点
   *   ≥2 拍   → 后面跟 (n−1) 条增时线「—」
   * 数字上下的点就是八度点。点谱面上哪个音,就从哪儿开始弾。
   */
  function scoreNote(n, i) {
    var b = Math.max(0.05, n.beats || 1);
    var main = el('span', 'n' + (n.rest ? ' rest' : ''));
    main.setAttribute('data-i', i);
    if (!n.rest && IO) {
      var dig = el('span', 'dig');
      if (state.label === 'name') {
        /* 不认识简谱的人:整页改成音名。**谱面 / 乐器 / 读数三处说的是同一套字**
           (都是发声那个音高的音名),照着一颗一颗按就行 —— 不用先学会读谱。 */
        dig.textContent = A.midiName(midiOf(n));
      } else {
        /* 按**发声**的音高与调算记号:移调/适配音域之后,谱面上的 1' 与键上的 1' 才是同一个音 */
        var d = IO.digits(midiOf(n), songKey2(), songBase2());
        var up = Math.min(3, d.up), low = Math.min(3, d.low);
        if (up) main.appendChild(octDots('up', up));
        dig.textContent = d.digit;
        if (low) main.appendChild(octDots('dn', low));
      }
      main.appendChild(dig);
      var lines = b <= 0.3 ? 2 : (b < 1 ? 1 : 0);
      for (var k = 0; k < lines; k++) main.appendChild(el('span', 'und u' + (k + 1)));
      if (b > 1 && b < 2) main.appendChild(el('span', 'dot'));
    } else {
      main.appendChild(el('span', 'dig', '0'));
    }
    return main;
  }
  function octDots(dir, n) {
    var w = el('span', 'oct ' + dir);
    for (var i = 0; i < n; i++) w.appendChild(el('i'));
    return w;
  }
  function holdEl(i, txt) {
    var h = el('span', 'n hold');
    h.setAttribute('data-i', i);
    h.textContent = txt;
    return h;
  }

  function renderScore() {
    var box = $('score'); clear(box);
    if (!state.song) {
      box.appendChild(el('div', 'empty', '谱面会在这里一节一节排开,弹到哪一处会自己亮。'));
      return;
    }
    var notes = state.song.notes, bars = {}, cur = null, i;
    var ends = phraseEnds(notes, state.song.bars);
    for (i = 0; i < state.song.bars.length; i++) bars[state.song.bars[i]] = 1;
    /* 一句一行:句读处换行(简谱本来的样子)。演奏的那份句读就是这一份 ——
       谱面上断在哪儿,耳朵里就断在哪儿,两边不会各说各话。 */
    var line = el('div', 'scoreLine'), bar = el('div', 'bar');
    for (i = 0; i < notes.length; i++) {
      if (i > 0 && (bars[i] || ends[i - 1])) { line.appendChild(bar); bar = el('div', 'bar'); }
      if (i > 0 && ends[i - 1]) { box.appendChild(line); line = el('div', 'scoreLine'); }
      var n = notes[i];
      var b = Math.max(0.05, n.beats || 1);
      bar.appendChild(scoreNote(n, i));
      /* 增时线「—」的条数 = 拍数 − 1。**必须夹一下**:beats 要是坏的(0 / NaN / Infinity),
         这个 for 会把主线程焊死 —— 解析器本来就限到 8 拍,这里只是不让坏数据有卡死的机会。 */
      var w = Math.floor(b);
      if (!(w > 1 && w < 16)) w = 1;
      for (var k = 1; k < w; k++) bar.appendChild(holdEl(i, '—'));
    }
    line.appendChild(bar);
    box.appendChild(line);
    box.onclick = function (ev) {
      var t = ev.target.closest ? ev.target.closest('.n[data-i]') : null;
      if (!t) return;
      var i2 = parseInt(t.getAttribute('data-i'), 10);
      if (!(i2 >= 0)) return;
      state.idx = i2;
      lightNote(i2);
      var nn = notes[i2];
      if (nn && !nn.rest) { A.unlock(); A.noteOn(inst(), midiOf(nn), 0.9, 0, nn.beats * beatSec()); showNow(midiOf(nn), ''); }
    };
    lightNote(state.idx);
  }

  /** 这个音现在该弹成什么:原谱 + 移调 + 适配音域(整八度地挪) */
  function midiOf(n) { return n.midi + state.transpose + fitShift(); }

  function instRange() {
    var I = inst();
    if (I.ui === 'zither') return [I.strings[0], I.strings[I.strings.length - 1]];
    if (I.ui === 'fret') return [I.strings[I.strings.length - 1], I.strings[0] + (I.frets || 12)];
    if (I.ui === 'bow') return [I.strings[I.strings.length - 1], I.strings[0] + (I.span || 24)];
    if (I.ui === 'keys') return [I.keysLo, I.keysHi];
    if (I.ui === 'bells') {
      var l = scaleList(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9]);
      return [l[0], l[l.length - 1]];
    }
    if (I.ui === 'pads') {
      var l2 = scaleList(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9, 11]);
      return [l2[0], l2[l2.length - 1]];
    }
    return null;
  }
  /** 这件乐器的"离散音位"集合(立弦/音孔/编钟那一类);指板、键盘、无品按弦是半音俱全的 → null */
  function spotSet(I) {
    var out = [], i;
    if (I.ui === 'zither') { for (i = 0; i < I.strings.length; i++) out.push(I.strings[i]); }
    else if (I.ui === 'pads' || I.ui === 'bells') {
      var l = scaleList(I.padsLo, I.padsCount, I.padsScale || [0, 2, 4, 5, 7, 9, 11]);
      for (i = 0; i < l.length; i++) out.push(l[i]);
    } else return null;
    var set = {};
    for (i = 0; i < out.length; i++) set[out[i]] = 1;
    return set;
  }
  /**
   * **定弦类乐器上,这首曲子该弹在哪个调上。**
   * 简谱是首调谱:同一张谱在 D 调筝上就弹成 D 调、在 D 调箫上就吹成 D 调 ——
   * 这是民乐的常识,不是"改了谱"。不这么做的话,C 调写法的《茉莉花》里有 C4/G4/C5,
   * 而筝上根本没有这几根弦:**用户跟弹时那几颗音永远圈不出目标**。
   * (这一条是曲库门禁逼出来的:93 首里当时有 5 首对不上自己的推荐乐器。)
   */
  function keyFit(I) {
    var set = spotSet(I);
    if (!set || !state.song) return 0;
    var notes = state.song.notes, best = 0, bestMiss = Infinity, t, i, miss;
    for (t = 0; t < 12; t++) {
      miss = 0;
      for (i = 0; i < notes.length; i++) if (!notes[i].rest && !set[notes[i].midi + t]) miss++;
      if (miss < bestMiss) { bestMiss = miss; best = t; }
    }
    return best;
  }
  /** 一次算清:调上的挪法 k(半音)、八度上的挪法 o、用户自己按的移调 t */
  function fitParts() {
    var t = state.transpose || 0, k = 0, o = 0;
    if (!state.fit || !state.song) return { k: 0, o: 0, t: t };
    var r = instRange(), notes = state.song.notes, i;
    k = keyFit(inst());
    if (!r) return { k: k, o: 0, t: t };
    var lo = 999, hi = -999;
    for (i = 0; i < notes.length; i++) {
      if (notes[i].rest) continue;
      if (notes[i].midi < lo) lo = notes[i].midi;
      if (notes[i].midi > hi) hi = notes[i].midi;
    }
    if (lo > hi) return { k: k, o: 0, t: t };
    var sh = t + k, guard = 0;
    while (hi + sh > r[1] && guard++ < 8) { sh -= 12; o -= 12; }
    guard = 0;
    while (lo + sh < r[0] && guard++ < 8) { sh += 12; o += 12; }
    return { k: k, o: o, t: t };
  }
  /** 适配音域挪了多少(不含用户自己按的移调 —— 那个由 midiOf 另外加) */
  function fitShift() { var f = fitParts(); return f.k + f.o; }

  function lightNote(i) {
    var box = $('score'), kids = box.querySelectorAll('.n'), k;
    for (k = 0; k < kids.length; k++) kids[k].classList.remove('cur');
    if (!state.song || i < 0 || i >= state.song.notes.length) return;
    var got = box.querySelectorAll('.n[data-i="' + i + '"]');
    if (!got.length) return;
    for (k = 0; k < got.length; k++) got[k].classList.add('cur');
    var top = got[0].offsetTop, h = got[0].offsetHeight, bh = box.clientHeight;
    if (top < box.scrollTop || top + h > box.scrollTop + bh) box.scrollTop = Math.max(0, top - bh / 2 + h / 2);
    /* 跟弹的时候,谱面亮到哪一个音,**乐器上就把那根弦/那只键圈出来** ——
       不然用户知道"该弹这个音",却还要自己在 21 根弦里找它 */
    if (state.follow && state.playing && state.song) {
      var nn = state.song.notes[i];
      markTarget(nn && !nn.rest ? midiOf(nn) : null);
    } else markTarget(null);
  }

  /* ============================================================
     谱面的"句读":演奏与谱面**共用**的一份判断
     ------------------------------------------------------------
     简谱原文里句读是靠换行与歌词表示的,我们没有歌词,只能从三件事上推:
       ① 后面跟着休止符            → 明摆着的句尾(休止本身就把停顿写出来了);
       ② 这个音写到**两拍及以上**  → 民歌的句尾常是一个拖长的音;
       ③ 占满一拍半、下一个音又正好换小节 → 一句唱满几小节收住。
     推得准不准,谱面上一眼能看见(换行位置就是句读位置)。拿曲库对过:
       茉莉花 4 句、小星星 6 句、欢乐颂 2 句 —— 与该唱的句数一致。
     ============================================================ */
  function phraseEnds(notes, bars) {
    var set = {}, i, n = notes.length, out = [];
    for (i = 0; i < bars.length; i++) set[bars[i]] = 1;
    for (i = 0; i < n; i++) {
      var b = notes[i].rest ? 0 : (notes[i].beats || 1), why = '';
      if (i === n - 1) why = 'last';
      else if (!notes[i].rest) {
        if (notes[i + 1] && notes[i + 1].rest) why = 'rest';
        else if (b >= 2) why = 'long';
        else if (b >= 1.5 && set[i + 1]) why = 'bar';
      }
      out.push(why);
    }
    return out;
  }

  /**
   * 每一族的"断开方式"。**这三件事的时间尺度不一样,所以都不是"拍数的百分比"**:
   *   换弓是手上的事(几十毫秒)、换气是身体的事(几百毫秒)、弦的余韵是物理的事(几秒)。
   *   · 弹拨:同句里**一下都不掐** —— 弦还在响就是这件乐器本来的声音;句尾才收住,留一段白;
   *   · 拉弦/吹管:每个音之间留一点领音(换弓/舌堵),句尾留一次真的换气;
   *   · 击弦(扬琴/编钟/钢片琴):轻一点地放开,句尾留白。
   */
  function articOf(I) {
    var k = (I.synth && I.synth.kind) || 'add';
    /* 两个数是我替用户定的,依据写在这儿(不用他去查乐理):
       · 句尾停多久 = **半拍的留白** —— 音乐上"停一下"是按拍子算的,所以快歌停得短、慢歌停得长;
         但它同时被身体卡住:换气/换弓再长也就 0.45 秒,再长听着就是在干等,下限 0.16 秒(不然听不出断)。
         各族的比例:弹拨 0.6、击弦 0.72、拉弦与吹管 1.0(吹管真要吸气,所以它最长)。
       · 同句之内的领音**不吃拍子**:换弓、舌堵是手上的事,几十毫秒,与快慢无关。 */
    var ph = clamp(beatSec() * 0.5, 0.16, 0.45);
    if (k === 'ks') return { inner: 0.01, phrase: ph * 0.6, holdEnd: 0.92, ring: true };
    if (k === 'strike') return { inner: 0.05, phrase: ph * 0.72, holdEnd: 0.94, ring: true };
    if (k === 'drum') return { inner: 0, phrase: 0, holdEnd: 1, ring: true };
    return { inner: 0.07, phrase: ph, holdEnd: 0.86, ring: false };
  }

  /**
   * 把谱面排成一张"时间表" —— 演奏、谱面高亮、时长显示都读它这一份。
   * 三条自己定的规矩:
   *   ① **句尾留白是真的多花时间**,不是从前一个音里抠出来的 —— 换气、换弓本身要时间;
   *      (反过来做就是把句尾那个音掐短去凑总时长,那正是"连着弹"的味道)
   *   ② 同句内弹拨不掐(余韵),拉弦与吹管留领音(不然两个音会黏成一个长音);
   *   ③ 力度跟着句子走:句首 0.92 / 句中 0.86 / 句尾 0.78 ——
   *      一串音一样响,听着就像打字机,而不是"在唱"。
   */
  function planSong(notes, bars, I) {
    var ends = phraseEnds(notes, bars), art = articOf(I), beat = beatSec();
    var steps = [], t = 0, i, n = notes.length;
    for (i = 0; i < n; i++) {
      var nn = notes[i], base = Math.max(0.05, nn.beats || 1) * beat;
      var why = ends[i], isEnd = !!why;
      /* 句尾留白:休止符自己已经把停顿写出来了,那种情况不再加 */
      var tail = (isEnd && why !== 'rest') ? art.phrase : 0;
      var hold = null;
      if (isEnd) hold = base * art.holdEnd;
      else if (!art.ring) hold = Math.max(0.05, base - art.inner);
      if (i === n - 1) tail = (why === 'rest' ? 0 : art.phrase) + 0.5;   /* 曲终:多留半秒 */
      steps.push({ at: t, rest: !!nn.rest, hold: hold,
        vel: isEnd ? 0.78 : (i === 0 || ends[i - 1] ? 0.92 : 0.86) });
      t += base + tail;
    }
    return { steps: steps, total: t };
  }

  /* ---------- 自动演奏 ---------- */
  function startPlay() {
    if (!state.song) { say('先在「曲库」里挑一首谱子'); return; }
    if (state.playing) { stopPlay(); return; }
    if (state.rec) finishRec(true);
    A.unlock();
    kickWarm();                 /* 还没算完的话,趁这一下继续算(不挡开演) */
    state.playing = true;
    state.idx = 0;
    setPlayBtn();
    if (state.follow) {
      say('跟弹:弹对了才往下走');
      advanceFollow();
      return;
    }
    schedule();
  }

  /* ---------- 自动演奏:前瞻式调度 ----------
     从前一开演就把整首几十上百颗音一口气排进音频钟 —— 手机上每颗音都要现算
     (拨弦一颗要合几万格采样),主线程一慢,开头那句的"起止窗口"在排到它的
     时候已经整个滑进了过去:那颗音就永远不会响。"很多时候开头第一句根本不响"
     的根就在这里。
     只排未来 0.75 秒,每 90ms 补一班。主线程卡顿时,过期的音与节拍跳过,
     未过期的音只弹剩余时值。 */
  var HORIZON = 0.75, REFILL = 90;

  function schedule(from) {
    var I = inst(), notes = state.song.notes, i;
    state.pl = planSong(notes, state.song.bars, I);
    from = clamp(from || 0, 0, Math.max(0, notes.length - 1));
    state.idx = from;
    state.t0 = A.now() + 0.12 - state.pl.steps[from].at;
    state.schedIdx = from;
    state.clickI = Math.ceil(state.pl.steps[from].at / beatSec());
    state.clickT = state.clickI * beatSec();
    state.voices = []; state.times = []; state.clicks = [];
    for (i = 0; i < state.pl.steps.length; i++) state.times.push(state.t0 + state.pl.steps[i].at);
    state.endAt = state.t0 + state.pl.total;
    /* 真有音落在这件乐器的音域外会被引擎丢掉 —— 不许丢得无声无息 */
    var out = 0;
    for (i = 0; i < notes.length; i++) {
      if (notes[i].rest) continue;
      var m = midiOf(notes[i]);
      if (m == null || m < 21 || m > 108) out++;
    }
    if (out) say('有 ' + out + ' 个音超出' + I.name + '的音域,跳过去了');
    refill();
    if (state.refillT) clearInterval(state.refillT);
    state.refillT = setInterval(refill, REFILL);
    tick();
  }

  /* 把"接下来 HORIZON 秒内该响的音与打拍"排进音频钟,排一颗走一颗 */
  function refill() {
    if (!state.playing || !state.song || !state.pl) return;
    var notes = state.song.notes, I = inst(), pl = state.pl, beat = beatSec();
    var lim = A.now() + HORIZON;
    for (;;) {
      var i = state.schedIdx;
      var noteT = i < pl.steps.length ? state.t0 + pl.steps[i].at : Infinity;
      var clickT = (state.click && A.tick && state.t0 + state.clickT < state.endAt - 1e-6) ? state.t0 + state.clickT : Infinity;
      if (noteT > lim && clickT > lim) break;
      if (clickT < noteT) {
        var c = clickT >= A.now() - 0.03 ? A.tick(state.clickI % 4 === 0, Math.max(clickT, A.now() + 0.01)) : null;
        if (c) state.clicks.push(c);
        state.clickI++; state.clickT += beat;
        continue;
      }
      if (i >= pl.steps.length) break;
      var st = pl.steps[i];
      state.schedIdx++;
      if (st.rest) continue;
      /* 已经过完的音与拍子直接跳过,避免恢复时把历史音挤在同一瞬间。 */
      var now = A.now(), delay = Math.max(0, now + 0.02 - noteT);
      var w = Math.max(noteT, now + 0.02);
      var hold = st.hold;
      if (delay > 0.04) {
        var duration = hold == null ? Math.max(0.05, notes[i].beats || 1) * beat : hold;
        if (duration <= delay + 0.02) continue;
        hold = duration - delay;
      }
      var v = A.noteOn(I, midiOf(notes[i]), st.vel, w, hold);
      if (v) state.voices.push(v);
    }
  }

  function tick() {
    if (state.raf) cancelAnimationFrame(state.raf);
    var step = function () {
      if (!state.playing) return;
      var now = A.now(), i = state.idx;
      while (i + 1 < state.times.length && state.times[i + 1] <= now) i++;
      if (i !== state.idx) {
        state.idx = i;
        lightNote(i);
        var n = state.song.notes[i];
        if (n && !n.rest) { var m = midiOf(n); showNow(m, ''); lightSurface(m); }
      }
      if (now >= state.endAt) {
        if (state.loop) { stopPlay(true); state.playing = true; schedule(); setPlayBtn(); return; }
        stopPlay();
        ping();
        if (jh() && JH.vibrate) JH.vibrate(14);
        say('弹完了');
        return;
      }
      state.raf = requestAnimationFrame(step);
    };
    state.raf = requestAnimationFrame(step);
  }

  function stopPlay(silent) {
    state.playing = false;
    if (state.refillT) { clearInterval(state.refillT); state.refillT = 0; }
    if (state.tremRaf) { cancelAnimationFrame(state.tremRaf); state.tremRaf = 0; }
    markTarget(null);
    if (state.raf) { cancelAnimationFrame(state.raf); state.raf = 0; }
    var i;
    for (i = 0; i < state.voices.length; i++) { try { state.voices[i].stop(); } catch (e) { } }
    state.voices = [];
    for (i = 0; i < state.clicks.length; i++) { try { state.clicks[i].stop(); } catch (e) { } }
    state.clicks = [];
    if (!silent) A.stopAll();
    setPlayBtn();
  }

  function restartPlay() {
    if (!state.playing || state.follow) return;
    var from = state.idx;
    stopPlay(true);
    state.playing = true;
    schedule(from); lightNote(from); setPlayBtn();
  }

  function setPlayBtn() {
    var b = $('btnPlay');
    b.textContent = state.playing ? (state.follow ? '结束跟弹' : '停下来') : (state.follow ? '开始跟弹' : '自动演奏');
    b.className = (state.playing ? '' : 'primary ') + 'seg44';
    $('btnFollow').className = 'seg44' + (state.follow ? ' on' : '');
    syncClick();
  }

  /* ---------- 打拍 ----------
     自动演奏时那一路是排进音频图的(准);没在演奏 / 跟弹时走这一路的 rAF ——
     一个人练的时候"打拍"才是最有用的,不能只在能自动演奏的时候才给。 */
  function clickWanted() { return state.click && !state.rec && !document.hidden && (!state.playing || state.follow); }
  function syncClick() {
    if (clickWanted() && !state.clickRaf) {
      state.clickNext = Date.now();
      state.clickRaf = requestAnimationFrame(clickStep);
    } else if (!clickWanted() && state.clickRaf) {
      cancelAnimationFrame(state.clickRaf);
      state.clickRaf = 0;
    }
  }
  function clickStep() {
    state.clickRaf = 0;
    if (!clickWanted()) return;
    var now = Date.now(), beat = beatSec() * 1000;
    if (now >= state.clickNext) {
      A.tick(state.clickBeat % 4 === 0);
      state.clickBeat++;
      state.clickNext += beat;
      /* 掉帧掉了一拍以上就别补一串了(手机切后台再回来会这样) */
      if (state.clickNext < now) state.clickNext = now + beat;
    }
    state.clickRaf = requestAnimationFrame(clickStep);
  }

  /** 自动演奏时把对应的弦/键点亮,让人看得见"该动哪儿" */
  function lightSurface(midi) {
    var I = inst(), i;
    if (I.ui === 'zither') {
      for (i = 0; i < I.strings.length; i++) if (I.strings[i] === midi) { flash(refs.strs[i]); centerX(i * refs.w + refs.w / 2); }
    } else if (I.ui === 'fret') {
      for (i = 0; i < I.strings.length; i++) {
        var f = midi - I.strings[i];
        if (f >= 0 && f <= I.frets) {
          var c = refs.cells[i * (I.frets + 1) + f];
          if (c) { flash(c.el); centerX((c.x0 + c.x1) / 2); }
          break;
        }
      }
    } else if (I.ui === 'keys') {
      for (i = 0; i < refs.whites.length; i++) if (refs.whites[i].midi === midi) { flash(refs.whites[i].el); centerX(i * refs.ww + refs.ww / 2); }
      for (i = 0; i < refs.blacks.length; i++) if (refs.blacks[i].midi === midi) { flash(refs.blacks[i].el); centerX(refs.blacks[i].left + refs.blacks[i].w / 2); }
    } else if (I.ui === 'pads') {
      for (i = 0; i < refs.pads.length; i++) if (refs.pads[i].midi === midi) flash(refs.pads[i].el);
    } else if (I.ui === 'bells') {
      for (i = 0; i < refs.pads.length; i++) if (refs.pads[i].midi === midi) flash(refs.pads[i].el);
    } else if (I.ui === 'bow') {
      for (i = 0; i < refs.bands.length; i++) {
        var s = midi - refs.bands[i].open;
        if (s >= 0 && s <= refs.span) moveSled(refs.bands[i], s / refs.span);
      }
    }
  }
  function centerX(x) {
    if (state.touchN) return;
    var wrap = refs.wrap;
    if (!wrap || wrap.scrollWidth <= wrap.clientWidth) return;
    var want = x - wrap.clientWidth / 2;
    if (want < 0) want = 0;
    wrap.scrollLeft = want;
    updateBrowse();
  }

  /* ---------- 跟弹:弹对了才往下走 ---------- */
  /** 这颗音在这件乐器上到底按不按得出来(跟弹判定与"帮你跳过"都用它) */
  function playableOn(I, m) {
    if (m == null || m < 21 || m > 108) return false;
    if (I.ui === 'drum') return true;                 /* 打击:什么音都落到某一面鼓上 */
    var r = instRange(); if (!r) return true;
    if (m < r[0] || m > r[1]) return false;
    var set = spotSet(I);
    if (set && !set[m]) return false;                 /* 定弦/音孔/编钟:没有这个位置 */
    return true;
  }
  function checkFollow(midi, padIdx) {
    if (!state.follow || !state.playing || !state.song) return;
    var n = state.song.notes[state.idx];
    if (!n) return;
    var I = inst(), hitOk;
    if (n.rest) hitOk = true;
    else if (I.ui === 'drum' && padIdx != null) {
      var pd = (I.pads || []).length || 1;
      hitOk = ((((midiOf(n) - 36) % pd) + pd) % pd) === padIdx;
    } else hitOk = midi === midiOf(n);
    if (hitOk) { state.idx++; advanceFollow(); }
  }
  /* 推进到下一颗"这件乐器上真按得出来"的音;按不出来的帮你跳过去,到尾就收工 */
  function advanceFollow() {
    var notes = state.song.notes, I = inst(), skipped = 0;
    while (state.idx < notes.length) {
      var nn = notes[state.idx];
      if (!nn || nn.rest) { state.idx++; continue; }
      if (playableOn(I, midiOf(nn))) break;
      state.idx++; skipped++;
    }
    if (state.idx >= notes.length) {
      stopPlay(true);
      ping();
      if (jh() && JH.vibrate) JH.vibrate(20);
      say('整首都弹下来了');
      state.idx = 0;
      lightNote(0);
      return;
    }
    if (skipped) say('有 ' + skipped + ' 个音' + I.name + '上按不出来,帮你跳过去了');
    lightNote(state.idx);
    var cur = notes[state.idx];
    if (cur && !cur.rest) showNow(midiOf(cur), '该你弹这一下');
  }

  /* ---------- 录制 ---------- */
  function toggleRec() {
    if (!state.rec) startRec(); else finishRec();
  }
  function startRec() {
    stopPlay(true);
    releaseHands();
    A.unlock();
    state.rec = true;
    state.recList = []; state.recHold = {};
    $('btnRec').className = 'seg44 on';
    $('btnRec').textContent = '停止录制';
    /* 四拍预备:不数拍子直接录,弹出来的东西永远差半拍 */
    var beat = beatSec() * 1000;
    state.recT0 = Date.now() + beat * 4;
    state.recNext = Date.now();
    state.recBeat = 0;
    syncClick();
    closeSheets();
    say('听四下打拍,第四下之后开始');
    recClickLoop();
  }
  function recClickLoop() {
    state.recRaf = 0;
    if (!state.rec) return;
    var now = Date.now();
    if (now >= state.recNext) {
      A.tick(state.recBeat % 4 === 0);
      state.recBeat++;
      state.recNext += beatSec() * 1000;
      if (state.recNext < now) state.recNext = now + beatSec() * 1000;
    }
    state.recRaf = requestAnimationFrame(recClickLoop);
  }
  function recOn(midi) {
    if (!state.rec || midi == null) return;
    midi = Math.round(midi);
    var t = Date.now() - state.recT0;
    if (t < 0) return;                                  /* 还在预备拍里 */
    if (state.recHold[midi]) { state.recHold[midi].count++; return; }
    state.recHold[midi] = { midi: midi, t0: t, t1: null, count: 1 };
    state.recList.push(state.recHold[midi]);
  }
  function recOff(midi, force) {
    if (midi == null) return;
    midi = Math.round(midi);
    var h = state.recHold[midi];
    if (!h) return;
    if (!force && h.count > 1) { h.count--; return; }
    h.t1 = Date.now() - state.recT0;
    delete state.recHold[midi];
  }
  function finishRec(auto) {
    state.rec = false;
    $('btnRec').className = 'seg44';
    $('btnRec').textContent = '录制';
    for (var k in state.recHold) if (state.recHold.hasOwnProperty(k)) recOff(+k, true);
    if (state.recRaf) cancelAnimationFrame(state.recRaf);
    state.recRaf = 0;
    syncClick();
    if (!state.recList.length) { say('一个音都没录到'); return; }
    var name = auto ? '我的演奏 ' + new Date().toLocaleTimeString() : window.prompt('给这段起个名字', '我的演奏');
    if (name === null) { say('没存'); return; }
    name = (name || '').trim() || '我的演奏';

    var bpm = Math.round(songBpm() * state.speed);
    var beatMs = 60000 / bpm, q = beatMs / 2;            /* 按八分音符的格子对齐 */
    var evs = state.recList.slice().sort(function (a, b) { return a.t0 - b.t0; });
    var out = [], bars = [], cur = 0, i, spb = 4;         /* 谱面按 4/4 打小节线 */
    function resta(gap) {
      var n = Math.round(gap / q);
      if (n >= 1) out.push({ midi: -1, beats: Math.max(0.25, n * 0.5), rest: true });
    }
    for (i = 0; i < evs.length; i++) {
      var e = evs[i];
      var st = Math.max(0, Math.round(e.t0 / q) * q);
      var en = Math.max(st + q, Math.round((e.t1 == null ? e.t0 + q : e.t1) / q) * q);
      if (st > cur + q / 2) resta(st - cur);
      out.push({ midi: e.midi, beats: Math.round((en - st) / beatMs * 100) / 100, rest: false });
      cur = Math.max(cur, en);
      if (out.length > 1200) { say('录得太长了,先收一半'); break; }
    }
    if (!out.length) { say('一个音都没录到'); return; }
    /* 每四拍一条小节线 —— 谱面才好读 */
    var acc = 0;
    for (i = 0; i < out.length; i++) {
      var prev = Math.floor(acc / spb), nowb = Math.floor((acc + out[i].beats) / spb);
      if (nowb > prev) bars.push(i + 1);
      acc += out[i].beats;
    }
    var text = IO.notesToText(out, bars, 'C', 4);
    var song = {
      id: 'u' + Date.now(), title: name, origin: '自己弹的', license: 'user',
      key: 'C', base: 4, bpm: bpm, notes: text
    };
    var chk = IO.checkLibrarySize(state.userSongs, [song]);
    if (!chk.ok) { say(chk.message); return; }
    state.userSongs.unshift(song);
    saveSongs().then(function (ok) { if (ok) { ping(); say('存下了,叫「' + name + '」'); } });
    state.libTab = 'mine';
    loadSong(song);
  }

  /* ============================================================
     四、曲库 / 导入 / 导出
     ============================================================ */
  function renderLib() {
    var seg = $('libSeg'); clear(seg);
    [['builtin', '内置曲库'], ['mine', '我的谱子']].forEach(function (t) {
      var b = el('button', state.libTab === t[0] ? 'on seg44' : 'seg44', t[1]
        + (t[0] === 'mine' && state.userSongs.length ? '(' + state.userSongs.length + ')' : ''));
      b.onclick = function () { state.libTab = t[0]; renderLib(); };
      seg.appendChild(b);
    });
    var box = $('libList'); clear(box);
    var flt = $('libFilter'); clear(flt);
    var list = state.libTab === 'builtin' ? BUILTIN : state.userSongs;
    if (state.libTab === 'builtin') {
      /* 121 首了。一条一条往下翻是翻不完的,所以给一排筛子:**难度四档 + "适合手上这件"**,
         并且每个筛子后面直接写它会筛出几首 —— 先看见数目,再决定点不点。
         默认停在「全部」:筛子是帮忙的,不是替用户做主的。 */
      var mine = 0;
      list.forEach(function (s) { if (s.inst === state.instId) mine++; });
      [['all', '全部 ' + list.length], ['fit', '适合' + inst().name + ' ' + mine],
       ['basic', '入门'], ['advanced', '进阶'], ['expert', '专家']].forEach(function (t) {
        var b = el('button', state.libLv === t[0] ? 'chip on' : 'chip', t[1]);
        b.onclick = function () { state.libLv = t[0]; renderLib(); };
        flt.appendChild(b);
      });
      flt.hidden = false;
      if (state.libLv === 'fit') {
        list = list.filter(function (s) { return s.inst === state.instId; });
      } else if (state.libLv !== 'all') {
        list = list.filter(function (s) { return (s.level || 'basic') === state.libLv; });
      }
    } else {
      flt.hidden = true;
    }
    if (state.libTab === 'builtin' && list.length) {
      /* 得让用户先看见"手上这件乐器的那几首":适合的排前面,再按难度排 */
      var cur = state.instId, ord = { basic: 0, advanced: 1, expert: 2 };
      var idx = {};
      list.forEach(function (s, i) { idx[s.id] = i; });
      list = list.slice().sort(function (a, b) {
        var fa = a.inst === cur ? 0 : 1, fb = b.inst === cur ? 0 : 1;
        if (fa !== fb) return fa - fb;
        var la = ord[a.level || 'basic'], lb = ord[b.level || 'basic'];
        if (la !== lb) return la - lb;
        return idx[a.id] - idx[b.id];
      });
    }
    if (!list.length) {
      box.appendChild(el('div', 'empty', state.libTab === 'builtin'
        ? (state.libLv === 'all' ? '内置曲库是空的。'
           : '这个筛子底下暂时没有 —— 点上面的「全部 ' + BUILTIN.length + '」回去。')
        : '还没有自己的谱子 —— 下面那个框里粘一段简谱,或者现场弹一段点「录制」。'));
      return;
    }
    list.forEach(function (s) {
      var row = el('div', 'row');
      var g = el('div', 'grow');
      var t1 = el('div', 't1', s.title || '未命名');
      /* 「正在练」是这一行的标记,不是它的副标题 —— 上一版把它写成了 .t2,
         于是列表里读到的"第二行"是这四个字,出处那一句反倒被挤掉了 */
      if (s.id === state.songId) t1.appendChild(el('span', 'flag', '正在练'));
      g.appendChild(t1);
      var meta = [];
      var lv = { basic: '入门', advanced: '进阶', expert: '专家' }[s.level];
      if (s.id === state.songId) meta.push('在练');
      if (state.libTab === 'builtin' && lv) meta.push(lv);
      if (state.libTab === 'builtin' && s.inst && s.inst === state.instId) meta.push('适合' + inst().name);
      if (s.bpm) meta.push(s.bpm + ' BPM');
      if (s.origin) meta.push(s.origin);
      g.appendChild(el('div', 't2', meta.join(' · ')));
      var acts = el('div', 'acts');
      var bOpen = el('button', null, s.id === state.songId ? '重开' : '打开');
      bOpen.onclick = function () { loadSong(s); closeSheets(); say('打开了「' + (s.title || '未命名') + '」'); };
      acts.appendChild(bOpen);
      if (state.libTab === 'builtin') {
        var bSave = el('button', null, '存我的');
        bSave.onclick = function () { addUser(s); };
        acts.appendChild(bSave);
      } else {
        var bOut = el('button', null, '导出');
        bOut.onclick = function () { exportSong(s, 'file'); };
        var bShare = el('button', null, '分享');
        bShare.onclick = function () { exportSong(s, 'share'); };
        var bDel = el('button', 'danger', '删');
        bDel.onclick = function () {
          if (!window.confirm('删掉「' + (s.title || '未命名') + '」?')) return;
          var previous = state.userSongs.slice(), i = state.userSongs.indexOf(s);
          if (i >= 0) state.userSongs.splice(i, 1);
          saveSongs().then(function (ok) { if (!ok) { state.userSongs = previous; renderLib(); } }); renderLib();
        };
        acts.appendChild(bOut); acts.appendChild(bShare); acts.appendChild(bDel);
      }
      row.appendChild(g); row.appendChild(acts);
      box.appendChild(row);
    });
  }

  function addUser(s) {
    var copy = {
      id: 'u' + Date.now(), title: s.title, origin: s.origin, license: 'user',
      key: s.key, base: s.base, bpm: s.bpm, notes: s.notes
    };
    var chk = IO.checkLibrarySize(state.userSongs, [copy]);
    if (!chk.ok) { say(chk.message); return; }
    state.userSongs.unshift(copy);
    saveSongs().then(function (ok) { if (ok) { ping(); say('存进「我的谱子」了'); } });
    state.libTab = 'mine';
    renderLib();
  }

  function exportSong(s, how) {
    if (!IO) return;
    var text = IO.formatSong(s);
    var name = (s.title || '乐谱') + '.txt';
    if (how === 'share') {
      if (!jh() || !JH.share) { say('这个版本不支持分享'); return; }
      JH.share.text(text).catch(fail);
      return;
    }
    if (!jh() || !JH.saveFile) { say('这个版本不支持存文件'); return; }
    JH.saveFile(name, 'text/plain', text).then(function (ok) {
      if (ok) { ping(); say('存成 ' + name + ' 了'); }
    }).catch(fail);
  }

  function importText(text, from, quiet) {
    $('impErr').textContent = '';
    if (!IO) { say('谱面解析那一份没加载起来'); return false; }
    var r = IO.parseText(text || '');
    if (!r.ok) {
      var e = r.error || {};
      $('impErr').textContent = (e.message || '这段简谱读不出来') + (e.hint ? '(' + e.hint + ')' : '');
      if (quiet) say(e.message || '这段简谱读不出来');
      return false;
    }
    var got = r.songs || [];
    if (!got.length) { $('impErr').textContent = '里面一首谱子都没有'; return false; }
    var chk = IO.checkLibrarySize(state.userSongs, got);
    if (!chk.ok) { $('impErr').textContent = chk.message; return false; }
    for (var i = 0; i < got.length; i++) {
      var s = got[i];
      s.id = 'u' + Date.now() + i;
      s.license = 'user';
      if (!s.origin) s.origin = from || '自己导入';
      state.userSongs.unshift(s);
    }
    saveSongs().then(function (ok) { if (ok) { ping(); say(got.length > 1 ? ('收下 ' + got.length + ' 首') : ('收下「' + (got[0].title || '未命名') + '」')); } });
    state.libTab = 'mine';
    renderLib();
    loadSong(got[0]);
    return true;
  }

  function pickFile() {
    if (!jh() || !JH.pickText) { say('这个版本不支持选文件'); return; }
    JH.pickText('text/*').then(function (f) {
      if (!f) return;
      $('impText').value = (f.text || '').slice(0, 4000);
      importText(f.text, '从文件导入');
    }).catch(fail);
  }

  /* ============================================================
     五、浮层与设置
     ============================================================ */
  var TILE_SVG = {
    '弹拨': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="11" y="6" width="26" height="36" rx="9" fill="rgba(255,255,255,.16)"/>' +
      '<path d="M18 9v30M24 9v30M30 9v30" stroke="rgba(255,255,255,.95)" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M14 30l20-7" stroke="rgba(255,255,255,.75)" stroke-width="2" stroke-linecap="round"/></svg>',
    '拉弦': '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 8v32" stroke="rgba(255,255,255,.95)" stroke-width="3" stroke-linecap="round"/>' +
      '<path d="M21 10v28M27 10v28" stroke="rgba(255,255,255,.6)" stroke-width="1.2"/>' +
      '<path d="M12 34c6-10 18-14 26-16" stroke="rgba(255,255,255,.9)" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>',
    '吹管': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="20" y="6" width="8" height="36" rx="4" fill="rgba(255,255,255,.22)" stroke="rgba(255,255,255,.75)" stroke-width="1.4"/>' +
      '<circle cx="24" cy="16" r="2.2" fill="#fff"/><circle cx="24" cy="24" r="2.2" fill="#fff"/>' +
      '<circle cx="24" cy="32" r="2.2" fill="#fff"/></svg>',
    '键盘': '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="7" y="14" width="34" height="20" rx="3" fill="#fff"/>' +
      '<rect x="15" y="14" width="5" height="12" rx="1.4" fill="#26262C"/><rect x="25" y="14" width="5" height="12" rx="1.4" fill="#26262C"/>' +
      '<rect x="35" y="14" width="5" height="12" rx="1.4" fill="#26262C"/></svg>',
    '打击': '<svg viewBox="0 0 48 48" aria-hidden="true"><ellipse cx="24" cy="22" rx="15" ry="13" fill="#fff"/>' +
      '<ellipse cx="24" cy="22" rx="15" ry="13" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.4"/>' +
      '<path d="M11 30c8 5 18 5 26 0" stroke="rgba(0,0,0,.28)" stroke-width="2" fill="none"/>' +
      '<path d="M30 8l9-5" stroke="rgba(255,255,255,.9)" stroke-width="2.2" stroke-linecap="round"/></svg>'
  };

  function renderPicker() {
    var seg = $('famSeg'); clear(seg);
    var fams = A.families;
    /* 第一次打开「换乐器」时停在**正在用的那一族**上 —— 打开就看见自己在用的那件,
       不然二胡用户每次都要先摸到「拉弦」 */
    if (!state.fam) state.fam = inst().fam || fams[0];
    fams.forEach(function (f) {
      var b = el('button', state.fam === f ? 'on seg44' : 'seg44', f);
      b.onclick = function () { state.fam = f; renderPicker(); };
      seg.appendChild(b);
    });
    var rec = $('recentRow'); clear(rec);
    var seen = {}, shown = 0;
    state.recent.forEach(function (id) {
      if (shown >= 8) return;                      /* 四列两行,多了不往下堆 */
      var R = null, i2;
      for (i2 = 0; i2 < A.instruments.length; i2++) if (A.instruments[i2].id === id) R = A.instruments[i2];
      if (!R || seen[id]) return;
      seen[id] = 1;
      shown++;
      var t = el('button', 'tile');
      var ico = el('div', 'ico i-' + (R.tint || 'wood') + (id === state.instId ? ' on' : ''));
      ico.innerHTML = TILE_SVG[R.fam] || TILE_SVG['弹拨'];
      t.appendChild(ico);
      t.appendChild(el('div', 'nm' + (id === state.instId ? ' on' : ''), R.name));
      t.setAttribute('aria-label', '换成' + R.name);
      t.onclick = function () { setInst(id); };
      rec.appendChild(t);
    });
    rec.hidden = shown === 0;
    var grid = $('instGrid'); clear(grid);
    A.instruments.forEach(function (I) {
      if (I.fam !== state.fam) return;
      var on = I.id === state.instId;
      var t = el('button', 'tile');
      var ico = el('div', 'ico i-' + (I.tint || 'wood') + (on ? ' on' : ''));
      ico.innerHTML = TILE_SVG[I.fam] || TILE_SVG['弹拨'];
      t.appendChild(ico);
      t.appendChild(el('div', 'nm' + (on ? ' on' : ''), I.name));
      t.setAttribute('aria-label', I.name + (on ? ',正在用' : ''));
      t.onclick = function () { setInst(I.id); };
      grid.appendChild(t);
    });
  }

  function touchRecent(id) {
    var a = state.recent.filter(function (x) { return x !== id; });
    a.unshift(id);
    state.recent = a.slice(0, 6);
  }
  function setInst(id) {
    if (state.rec) finishRec(true);
    state.instId = id;
    var I = inst();
    touchRecent(id);
    savePrefs();
    renderSurface();
    pushWidget();
    kickWarm();                 /* 换了乐器 = 要用的缓冲换了一批,重算 */
    if ($('sheetPick').className.indexOf('on') >= 0) renderPicker();
    closeSheets();
    if (state.playing && !state.follow) {
      /* 正演着就换乐器 = 想听这首在新乐器上的样子:用新乐器从头再排一遍。
         不能接着演 —— 句读表是照旧乐器排的:拨弦的"余韵不收尾"拿到二胡上,
         就是一颗 30 秒不停的长音,整首当场糊掉。 */
      stopPlay(true);
      state.playing = true; state.idx = 0;
      schedule(); lightNote(0); setPlayBtn();
    } else if (state.playing && state.follow) {
      lightNote(state.idx);   /* 跟弹:换完乐器,该弹的那颗重新圈一遍 */
    }
    say('换成' + I.name + '了');
  }

  /** 第一次打开时告诉他怎么玩 —— 他是小白,不是不会玩这个工具的人 */
  function renderHow() {
    var box = $('howList'); clear(box);
    [['演奏与浏览', '乐器上点按立即发声、横划刮奏;下方「静音浏览」只移动音域,不发声。'],
     ['自动演奏与跟弹', '自动示范；逐音跟弹'],
     ['简谱与曲库', '切音名；导入简谱。']
    ].forEach(function (r) {
      var row = el('div', 'row'), g = el('div', 'grow');
      g.appendChild(el('div', 't1', r[0]));
      g.appendChild(el('div', 't2', r[1]));
      row.appendChild(g);
      box.appendChild(row);
    });
  }

  function renderTech() {
    var I = inst(), L = techList(I), box = $('techList');
    clear(box);
    $('techTitle').textContent = I.name + ' · 技法';
    L.forEach(function (t) {
      var row = el('div', 'row'), g = el('div', 'grow');
      g.appendChild(el('div', 't1', t.name || t.g));
      g.appendChild(el('div', 't2', t.tip));
      row.appendChild(g);
      if (t.k) {
        var on = !!state.tech[t.k];
        var b = el('button', on ? 'on' : '', on ? '开' : '关');
        b.setAttribute('aria-label', t.name + (on ? ',已开' : ',已关'));
        b.onclick = function () {
          state.tech[t.k] = !state.tech[t.k];
          if (!state.tech.trem && state.tremRaf) { cancelAnimationFrame(state.tremRaf); state.tremRaf = 0; }
          savePrefs();
          renderTech();
          say(t.name + (state.tech[t.k] ? '开了' : '关了'));
        };
        row.appendChild(b);
      }
      box.appendChild(row);
    });
  }

  function openSheet(id, title) {
    releaseHands();
    closeSheets();                       /* 抽屉是互相排斥的:开一个先把别的收掉,别叠在一起 */
    $('mask').className = 'mask on';
    $(id).className = 'sheet on';
    if (jh() && JH.setTitle) JH.setTitle(title);
  }
  function closeSheets() {
    $('mask').className = 'mask';
    $('sheetPick').className = 'sheet';
    $('sheetLib').className = 'sheet';
    $('sheetTone').className = 'sheet';
    $('sheetTech').className = 'sheet';
    $('sheetHow').className = 'sheet';
    $('sheetSettings').className = 'sheet';
    if (jh() && JH.setTitle) JH.setTitle('乐器盒');
  }
  function sheetOpen() { return $('mask').className.indexOf('on') >= 0; }

  /**
   * 「自动演奏」以下那一堆(循环/打拍/录制/适配音域/速度)**收进「高级」**。
   * 这是用户自己提的办法,而且比我上一版那颗「收起」聪明:收起会把谱面一起藏掉,
   * 而谱面是"要看着弹"的那一块,必须一直在。收的应该是"一首曲子设一次"的那些开关。
   */
  function applyAdv() {
    $('advBody').hidden = false;
    $('btnAdv').textContent = '设置';
    $('btnAdv').setAttribute('aria-label', '演奏设置');
  }

  function pushWidget() {
    if (!jh() || !JH.widget) return;
    var s = state.song ? state.song.song.title : '还没选曲子';
    JH.widget.set({
      title: '乐器盒 · ' + inst().name,
      lines: [{ t: '在练', d: String(s || '').slice(0, 20) }, { t: '曲库', d: BUILTIN.length + ' 首内置' }],
      accent: '#C72E26',
      tap: 'plugin:instrument_box'
    }).catch(function () { });
  }

  /* ============================================================
     六、启动
     ============================================================ */
  function bind() {
    var openPicker = function () { renderPicker(); openSheet('sheetPick', '换乐器'); };
    $('btnPick').onclick = openPicker;
    $('instBadge').onclick = openPicker;
    $('pickClose').onclick = closeSheets;
    $('btnLib').onclick = function () { renderLib(); openSheet('sheetLib', '曲库'); };
    $('btnAdv').onclick = function () {
      openSheet('sheetSettings', '演奏设置');
    };
    $('settingsClose').onclick = closeSheets;
    $('browseLow').onclick = function () { browseBy(-1); };
    $('browseHigh').onclick = function () { browseBy(1); };
    $('browseRange').oninput = function () { releaseHands(); if (refs.wrap) refs.wrap.scrollLeft = +this.value; updateBrowse(); };
    $('libClose').onclick = closeSheets;
    $('btnTone').onclick = function () { openSheet('sheetTone', '音色'); };
    $('toneClose').onclick = closeSheets;
    $('sbB').onclick = function () { renderTech(); openSheet('sheetTech', '技法'); };
    $('techClose').onclick = closeSheets;
    $('btnHow').onclick = function () { renderHow(); openSheet('sheetHow', '这样玩'); };
    $('howClose').onclick = function () { state.howDone = true; savePrefs(); closeSheets(); };
    $('mask').onclick = closeSheets;

    $('sbA').onclick = function () {
      var I = inst();
      if (I.ui === 'zither') { state.wide = !state.wide; say(state.wide ? '全景:一次看全,好刮奏' : '触弦:弦宽好点,下方静音浏览其他弦'); }
      else if (I.ui === 'bow') { state.snap = !state.snap; say(state.snap ? '音阶档:按半音对齐' : '滑音档:拖到哪儿滑到哪儿'); }
      else { state.label = state.label === 'jianpu' ? 'name' : 'jianpu'; }
      savePrefs();
      renderSurface();
    };

    $('btnPlay').onclick = startPlay;
    $('btnFollow').onclick = function () {
      state.follow = !state.follow;
      stopPlay(true);
      setPlayBtn();
      if (!state.follow) markTarget(null);
      say(state.follow ? '跟弹:一个音一个音地等你,弹对了才往下走' : '关掉跟弹了');
    };
    $('btnLoop').onclick = function () {
      state.loop = !state.loop;
      $('btnLoop').className = 'chip' + (state.loop ? ' on' : '');
      savePrefs();
      say(state.loop ? '弹完接着从头来' : '不循环了');
    };
    $('btnClick').onclick = function () {
      state.click = !state.click;
      state.clickBeat = 0;
      $('btnClick').className = 'chip' + (state.click ? ' on' : '');
      A.unlock();
      restartPlay();
      syncClick();
      say(state.click ? '打拍:现在这个速度,每小节第一下是重拍' : '关掉打拍了');
    };
    $('btnFit').onclick = function () {
      state.fit = !state.fit;
      $('btnFit').className = 'chip' + (state.fit ? ' on' : '');
      savePrefs();
      renderScore();
      updateFitNote();
      restartPlay();
      say(state.fit ? '会自动把谱子挪进这件乐器的音域' : '不再挪了,原样弹');
    };
    $('btnRec').onclick = toggleRec;

    $('bpm').oninput = function () {
      paintRange(this);
      state.speed = parseInt(this.value, 10) / 100;
      $('bpmTxt').textContent = Math.round(songBpm() * state.speed) + ' BPM';
      if (state.song) renderSongHead();
    };
    $('bpm').onchange = function () { restartPlay(); savePrefs(); };

    $('trDown').onclick = function () { state.transpose = Math.max(-12, state.transpose - 1); applyTr(); };
    $('trUp').onclick = function () { state.transpose = Math.min(12, state.transpose + 1); applyTr(); };
    $('trZero').onclick = function () { state.transpose = 0; applyTr(); };

    $('labJp').onclick = function () { state.label = 'jianpu'; applyLabel(); };
    $('labNm').onclick = function () { state.label = 'name'; applyLabel(); };

    $('vol').oninput = function () {
      paintRange(this);
      state.vol = parseInt(this.value, 10) / 100;
      A.setVolume(state.vol);
      $('volTxt').textContent = Math.round(state.vol * 100) + '%';
    };
    $('vol').onchange = savePrefs;
    $('wet').oninput = function () {
      paintRange(this);
      state.wet = parseInt(this.value, 10) / 100;
      A.setWet(state.wet);
      $('wetTxt').textContent = state.wet < 0.08 ? '关' : state.wet < 0.22 ? '少' : state.wet < 0.4 ? '中' : '多';
    };
    $('wet').onchange = savePrefs;

    $('btnFile').onclick = pickFile;
    $('btnPaste').onclick = function () { importText($('impText').value, '粘贴导入'); };

    if (jh() && JH.onBack) {
      JH.onBack(function () {
        if (sheetOpen()) { closeSheets(); return true; }
        if (state.playing) { stopPlay(); return true; }
        if (state.rec) { finishRec(); return true; }
        if (state.touchN) { releaseHands(); return true; }
        return false;
      });
    }
  }

  var KEYS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  function applyTr() {
    var t = state.transpose;
    var txt = t === 0 ? '原调' : (t > 0 ? '+' : '') + t;
    if (t !== 0) {
      var key = songKey(), idx = KEYS.indexOf(key);
      if (idx >= 0) txt += '(' + KEYS[((idx + t) % 12 + 12) % 12] + ')';
    }
    $('trTxt').textContent = txt;
    $('trZero').setAttribute('aria-label', t === 0 ? '原调' : '回原调(现在移了' + t + '个半音)');
    renderScore();
    updateFitNote();
    var I = inst();
    if (I.ui === 'pads' || I.ui === 'bells' || I.ui === 'keys') renderSurface();
    restartPlay();
  }
  function applyLabel() {
    $('labTxt').textContent = state.label === 'jianpu' ? '简谱' : '音名';
    $('labJp').className = 'seg44' + (state.label === 'jianpu' ? ' on' : '');
    $('labNm').className = 'seg44' + (state.label === 'name' ? ' on' : '');
    savePrefs();
    var I = inst();
    if (I.ui === 'pads' || I.ui === 'bells' || I.ui === 'keys') renderSurface();
    if (state.song) { renderScore(); lightNote(state.idx); }   /* 谱面也跟着换字 */
    updateStageBtn();
  }

  function boot() {
    if (!A) { say('声音引擎没加载起来'); return; }
    bind();
    bindSurface();
    A.setVolume(state.vol);
    A.setWet(state.wet);

    sget(KEY_PREF).then(function (raw) {
      if (raw) {
        try {
          var p = JSON.parse(raw);
          if (p && typeof p.instId === 'string') state.instId = p.instId;
          if (p && typeof p.wide === 'boolean') state.wide = p.wide;
          if (p && typeof p.snap === 'boolean') state.snap = p.snap;
          if (p && (p.label === 'jianpu' || p.label === 'name')) state.label = p.label;
          if (p && typeof p.speed === 'number' && isFinite(p.speed)) state.speed = clamp(p.speed, 0.4, 1.6);
          if (p && typeof p.vol === 'number' && isFinite(p.vol)) state.vol = clamp(p.vol, 0, 1);
          if (p && typeof p.wet === 'number' && isFinite(p.wet)) state.wet = clamp(p.wet, 0, 0.6);
          if (p && typeof p.loop === 'boolean') state.loop = p.loop;
          if (p && typeof p.fit === 'boolean') state.fit = p.fit;
          if (p && typeof p.songId === 'string') state.songId = p.songId;
          if (p && p.tech && typeof p.tech === 'object') {
            state.tech.trem = !!p.tech.trem;
            state.tech.harm = !!p.tech.harm;
            state.tech.mute = !!p.tech.mute;
          }
          if (p && Array.isArray(p.recent)) state.recent = p.recent.filter(function (id) { return typeof id === 'string'; }).slice(0, 6);
          if (p && p.howDone) state.howDone = true;
          if (p && typeof p.adv === 'boolean') state.adv = p.adv;
        } catch (e) { }
      }
      /* 这件乐器还在不在 —— 存档里的 id 可能是老版本留下的 */
      var found = false, list = A.instruments, i;
      for (i = 0; i < list.length; i++) if (list[i].id === state.instId) found = true;
      if (!found) state.instId = 'guzheng';

      $('bpm').value = Math.round(state.speed * 100);
      $('vol').value = Math.round(state.vol * 100);
      $('volTxt').textContent = Math.round(state.vol * 100) + '%';
      $('wet').value = Math.round(state.wet * 100);
      $('wetTxt').textContent = state.wet < 0.08 ? '关' : state.wet < 0.22 ? '少' : state.wet < 0.4 ? '中' : '多';
      $('btnLoop').className = 'chip' + (state.loop ? ' on' : '');
      $('btnFit').className = 'chip' + (state.fit ? ' on' : '');
      paintRanges();
      applyAdv();
      A.setVolume(state.vol); A.setWet(state.wet);
      applyLabel();
      renderSurface();
      return sget(KEY_SONGS);
    }).then(function (raw2) {
      if (raw2) {
        try {
          var arr = IO ? IO.sanitizeStored(raw2) : JSON.parse(raw2);
          if (arr && arr.length) state.userSongs = arr;
        } catch (e) { }
      }
      /* 上次在练哪一首 —— 每次打开都从第一首重来,是"不像给自己做的"的那一类事 */
      var pick = null, i;
      for (i = 0; i < BUILTIN.length; i++) if (BUILTIN[i].id === state.songId) pick = BUILTIN[i];
      for (i = 0; i < state.userSongs.length; i++) if (state.userSongs[i].id === state.songId) pick = state.userSongs[i];
      if (!pick && BUILTIN.length) pick = BUILTIN[0];
      if (pick) { loadSong(pick, true); state.idx = 0; }
      $('bpmTxt').textContent = Math.round(songBpm() * state.speed) + ' BPM';
      setPlayBtn();
      applyTr();
      /* 键盘那一族的字要等乐器画完才准(简谱是相对主音的) */
      if (state.song) renderScore();
      pushWidget();
      renderHow();
      /* 乐器先露出来,说明由用户主动打开。 */
      if (!jh() || !JH.launchParams) return;
      return JH.launchParams().then(function (lp) {
        if (!lp) return;
        if (lp.text) {
          $('impText').value = lp.text.slice(0, 4000);
          importText(lp.text, '工作台送来的', true);
          renderLib();
          openSheet('sheetLib', '曲库');
        } else if (lp.uri) {
          /* 插件读不到"随便一个路径"(§1.3),只能请用户再指一次 —— 别假装读到了 */
          openSheet('sheetLib', '曲库');
          say('锦盒没法直接读这个文件,请点「选文件」再选它一次');
        }
      });
    }).catch(function (e) { say('打开时出了一点岔子:' + ((e && e.message) || e)); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
