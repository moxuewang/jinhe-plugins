(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TableStore=api;}(typeof globalThis==='object'?globalThis:this,function(){'use strict';
function Store(storage,key,validate){this.storage=storage;this.key=key;this.validate=validate;this.loaded=false;this.busy=false;this.base=undefined;this.raw=undefined;this.epoch=0;this.closed=false;}
Store.prototype.close=function(){this.closed=true;this.epoch++;};
Store.prototype.guard=function(e){if(this.closed||e!==this.epoch)throw new Error('页面已离开；下次进入会重新读取实际保存版本。');};
Store.prototype.load=async function(){if(this.busy||this.closed)throw new Error('请等待当前操作完成。');this.busy=true;this.loaded=false;var e=++this.epoch;try{var raw=await this.storage.get(this.key);this.guard(e);this.raw=raw;if(raw!==undefined&&typeof raw!=='string')throw new Error('已保存项目的返回类型不正确。');var parsed=null;if(raw!==undefined){try{parsed=JSON.parse(raw);}catch(ignore){throw new Error('保存项目不是完整 JSON；原文已保留，可先另存再重试。');}}var project=raw===undefined?null:this.validate(parsed);this.base=raw;this.loaded=true;return project;}finally{this.busy=false;}};
Store.prototype.commit=async function(project){if(!this.loaded||this.busy||this.closed)throw new Error('先成功读取保存版本，再保存；当前输入仍可另存。');this.validate(project);var candidate=JSON.stringify(project);if(new TextEncoder().encode(candidate).length>800000)throw new Error('项目超过 800000 UTF-8 字节，不能存为草稿；请另存完整项目 JSON。');this.busy=true;var e=this.epoch;
  try{var actual=await this.storage.get(this.key);this.guard(e);if(actual===candidate){this.base=candidate;this.raw=candidate;return {already:true};}if(actual!==this.base){this.loaded=false;throw new Error('其他窗口改过保存版本。当前输入仍在，请先另存，再重新读取。');}
    var r=await this.storage.set(this.key,candidate);this.guard(e);if(!r||r.ok!==true)throw new Error('保存没有得到确认；当前输入仍可另存，重试会先核对磁盘。');var check=await this.storage.get(this.key);this.guard(e);if(check!==candidate){this.loaded=false;throw new Error('保存后核对不一致。当前输入仍在，请先另存再重新读取。');}this.base=candidate;this.raw=candidate;return {already:false};
  }finally{this.busy=false;}
};
return {Store:Store};
}));
