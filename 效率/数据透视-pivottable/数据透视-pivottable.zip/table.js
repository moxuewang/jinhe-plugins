(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TableModel=api;}(typeof globalThis==='object'?globalThis:this,function(){'use strict';
var LIMIT={bytes:8388608,rows:50000,cols:200,cells:500000,groups:500,pivotCols:50,pivotCells:10000};
function fail(s){throw new Error(s);}
function bytes(s){return new TextEncoder().encode(s);}
function cleanText(s){if(typeof s!=='string')fail('需要完整的文本内容。');if(/\u0000|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(s))fail('文本含无效字符，请先修复编码。');if(s.length>LIMIT.bytes||bytes(s).length>LIMIT.bytes)fail('文本超过 8 MiB，请先分成几份；没有读取截断内容。');return s;}
function parse(raw,delimiter,header){
  cleanText(raw);if(delimiter!==','&&delimiter!=='\t')fail('请选择逗号或制表符。');
  var s=raw.charAt(0)==='\uFEFF'?raw.slice(1):raw;if(!s.length)fail('还没有表格内容。');
  var rows=[],lines=[],row=[],field='',state=0,line=1,start=1,ended=false,cells=0;
  function pushField(){row.push(field);field='';if(row.length>LIMIT.cols)fail('第 '+start+' 行超过 200 列。');if(++cells>LIMIT.cells+LIMIT.cols)fail('表格超过 50 万个单元格。');}
  function pushRow(){pushField();rows.push(row);lines.push(start);row=[];if(rows.length>LIMIT.rows+1)fail('表格超过 5 万条记录。');}
  for(var i=0;i<s.length;i++){
    var c=s[i];ended=false;
    if(state===1){if(c==='"'){if(s[i+1]==='"'){field+='"';i++;}else state=2;}else{field+=c;if(c==='\n')line++;else if(c==='\r'&&s[i+1]!=='\n')line++;}continue;}
    if(state===2&&c!==delimiter&&c!=='\r'&&c!=='\n')fail('第 '+line+' 行：引号结束后只能接分隔符或换行。');
    if(c===delimiter){pushField();state=0;continue;}
    if(c==='\r'||c==='\n'){pushRow();if(c==='\r'&&s[i+1]==='\n')i++;line++;start=line;state=0;ended=true;continue;}
    if(c==='"'){if(field.length)fail('第 '+line+' 行：字段中间的引号需要成对转义。');state=1;}else field+=c;
  }
  if(state===1)fail('第 '+start+' 行开始的引号没有闭合。');if(!ended)pushRow();
  var width=rows[0].length;rows.forEach(function(r,j){if(r.length!==width)fail('第 '+lines[j]+' 行有 '+r.length+' 列，首行有 '+width+' 列；请检查分隔符。');});
  var h=header!==false?rows.shift():Array.from({length:width},function(_,j){return '列'+(j+1);});if(header!==false)lines.shift();
  if(rows.length>LIMIT.rows||rows.length*width>LIMIT.cells)fail('超过 5 万条记录或 50 万单元格，请分表处理。');
  return {headers:h,rows:rows,lines:lines,delimiter:delimiter,header:header!==false};
}
function column(table,index){if(!Number.isInteger(index)||index<0||index>=table.headers.length)fail('列已不存在，请重新选列。');return index;}
// 固定小数精确计量，不将大整数或十进制金额送进二进制浮点求和。
function decimal(s){if(typeof BigInt!=='function')fail('当前 WebView 不支持精确十进制计算，请更新后使用；原输入仍可另存。');if(typeof s!=='string')return null;var t=s.trim();if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(t))return null;var neg=t[0]==='-';t=t.replace(/^[+-]/,'');var p=t.split('.'),f=p[1]||'';if(f.length>12||p[0].replace(/^0+/,'').length>30)return null;var n=BigInt((p[0]||'0')+f);return {n:neg?-n:n,scale:f.length};}
function pow(n){var r=BigInt('1');for(var i=0;i<n;i++)r*=BigInt('10');return r;}
function cmp(a,b){var z=Math.max(a.scale,b.scale),x=a.n*pow(z-a.scale),y=b.n*pow(z-b.scale);return x===y?0:x<y?-1:1;}
function format(n,scale){var neg=n<BigInt('0');if(neg)n=-n;var s=String(n);if(scale){s=s.padStart(scale+1,'0');s=s.slice(0,-scale)+'.'+s.slice(-scale);s=s.replace(/0+$/,'').replace(/\.$/,'');}return (neg&&n!==BigInt('0')?'-':'')+s;}
function plain(o){return o!==null&&typeof o==='object'&&!Array.isArray(o)&&Object.getPrototypeOf(o)===Object.prototype;}
function exactKeys(o,allowed){if(!plain(o)||Object.keys(o).some(function(k){return allowed.indexOf(k)<0;}))fail('方案字段不符合当前版本。');}
function queryConfig(t,c,allowIncomplete){
  exactKeys(c,['filters','mode','columns','sorts']);if(!['all','any'].includes(c.mode)||!Array.isArray(c.filters)||c.filters.length>12||!Array.isArray(c.columns)||!c.columns.length||!Array.isArray(c.sorts)||c.sorts.length>3)fail('筛选方案不完整，最多 12 条条件、3 个排序列。');
  var seen=new Set();c.columns.forEach(function(j){column(t,j);if(seen.has(j))fail('输出列不能重复。');seen.add(j);});
  c.filters.forEach(function(f){exactKeys(f,['column','type','op','value']);column(t,f.column);if(!['text','number'].includes(f.type)||!['contains','eq','neq','gt','gte','lt','lte','empty','notempty'].includes(f.op)||typeof f.value!=='string'||f.value.length>1000)fail('筛选条件不完整。');if(f.op==='contains'&&f.type!=='text')fail('包含文字只适用于文本比较。');if(f.type==='number'&&!['empty','notempty'].includes(f.op)&&decimal(f.value)===null&&!(allowIncomplete&&f.value===''))fail('比较值须为最多 30 位整数、12 位小数的普通十进制数。');});
  seen.clear();c.sorts.forEach(function(s){exactKeys(s,['column','type','direction']);column(t,s.column);if(seen.has(s.column))fail('排序列不能重复。');seen.add(s.column);if(!['text','number'].includes(s.type)||!['asc','desc'].includes(s.direction))fail('排序设置不完整。');});return c;
}
function query(t,c){
  queryConfig(t,c);var invalid=new Set();
  var selected=t.rows.map(function(r,i){return {r:r,i:i};}).filter(function(x){
    if(!c.filters.length)return true;var flags=c.filters.map(function(f){var v=x.r[f.column],n=0;if(f.op==='empty')return v==='';if(f.op==='notempty')return v!=='';if(f.op==='contains')return v.includes(f.value);if(f.type==='number'){var a=decimal(v),b=decimal(f.value);if(!a){if(v!=='')invalid.add(x.i);return false;}n=cmp(a,b);}else n=v===f.value?0:v<f.value?-1:1;return f.op==='eq'?n===0:f.op==='neq'?n!==0:f.op==='gt'?n>0:f.op==='gte'?n>=0:f.op==='lt'?n<0:n<=0;});return c.mode==='all'?flags.every(Boolean):flags.some(Boolean);
  });
  selected.sort(function(a,b){for(var si=0;si<c.sorts.length;si++){var s=c.sorts[si];var av=a.r[s.column],bv=b.r[s.column],an=s.type==='number'?decimal(av):null,bn=s.type==='number'?decimal(bv):null,am=av===''||(s.type==='number'&&!an),bm=bv===''||(s.type==='number'&&!bn);if(am!==bm)return am?1:-1;if(am)continue;var d=s.type==='number'?cmp(an,bn):av===bv?0:av<bv?-1:1;if(d)return s.direction==='desc'?-d:d;}return a.i-b.i;});
  return {headers:c.columns.map(function(j){return t.headers[j];}),rows:selected.map(function(x){return c.columns.map(function(j){return x.r[j];});}),sourceRows:selected.map(function(x){return x.i;}),numeric:[],invalidRows:invalid.size};
}
function pivotConfig(t,c){
  exactKeys(c,['row','column','measure','agg','precision']);column(t,c.row);if(c.column!==null){column(t,c.column);if(c.column===c.row)fail('行维度和列维度请选择不同列。');}if(!['count','nonempty','sum','mean','min','max'].includes(c.agg))fail('请选择有效的汇总方式。');if(c.agg!=='count')column(t,c.measure);else if(c.measure!==null)fail('记录数不需要数值列。');if(!Number.isInteger(c.precision)||c.precision<0||c.precision>12)fail('平均值小数位应为 0 至 12。');return c;
}
function pivot(t,c){
  pivotConfig(t,c);if(typeof BigInt!=='function')fail('当前 WebView 不支持精确汇总，请更新后使用；原输入仍可另存。');var rkeys=[],ckeys=[],rm=new Map(),cm=new Map(),buckets=new Map(),bad=[],empty=0;
  function bucket(key){if(!buckets.has(key))buckets.set(key,{indices:[],n:0,total:BigInt('0'),scale:0,min:null,max:null});return buckets.get(key);}
  function accumulate(b,x,i){b.indices.push(i);if(c.agg==='count'){b.n++;return;}var raw=x[c.measure];if(raw==='')return;if(c.agg==='nonempty'){b.n++;return;}var d=decimal(raw);if(!d)return;b.n++;var z=Math.max(b.scale,d.scale);b.total=b.total*pow(z-b.scale)+d.n*pow(z-d.scale);b.scale=z;if(!b.min||cmp(d,b.min)<0)b.min=d;if(!b.max||cmp(d,b.max)>0)b.max=d;}
  t.rows.forEach(function(r,i){var rk=r[c.row],ck=c.column===null?'':r[c.column];if(!rm.has(rk)){rm.set(rk,rkeys.length);rkeys.push(rk);}if(!cm.has(ck)){cm.set(ck,ckeys.length);ckeys.push(ck);}if(rkeys.length>LIMIT.groups||ckeys.length>LIMIT.pivotCols||rkeys.length*ckeys.length>LIMIT.pivotCells)fail('分组超过 500 行、50 列或 1 万个交叉格，请先筛选数据。');
    if(c.agg!=='count'&&c.agg!=='nonempty'){if(r[c.measure]==='')empty++;else if(!decimal(r[c.measure]))bad.push(i);}var ri=rm.get(rk),ci=cm.get(ck);[[ri,ci],[ri,'total'],['total',ci],['total','total']].forEach(function(k){accumulate(bucket(JSON.stringify(k)),r,i);});
  });
  if(bad.length)fail('数值列有 '+bad.length+' 条非十进制或超精度记录，例如原记录 '+bad.slice(0,5).map(function(i){return i+1;}).join('、')+'；没有忽略这些记录求和。');
  function value(b){if(!b)return c.agg==='count'||c.agg==='nonempty'?'0':'';if(c.agg==='count'||c.agg==='nonempty')return String(b.n);if(!b.n)return '';if(c.agg==='sum')return format(b.total,b.scale);if(c.agg==='min')return format(b.min.n,b.min.scale);if(c.agg==='max')return format(b.max.n,b.max.scale);
    var a=b.total*pow(c.precision),den=BigInt(b.n)*pow(b.scale),q=a/den,rem=a%den,abs=rem<BigInt('0')?-rem:rem;if(abs*BigInt('2')>den||(abs*BigInt('2')===den&&(q<BigInt('0')?-q:q)%BigInt('2')===BigInt('1')))q+=a<BigInt('0')?-BigInt('1'):BigInt('1');return format(q,c.precision);
  }
  var headers=[t.headers[c.row]].concat(ckeys.map(function(k){return c.column===null?'汇总':k;})).concat(['合计']);
  var rows=rkeys.map(function(k,ri){return [k].concat(ckeys.map(function(_,ci){return value(buckets.get(JSON.stringify([ri,ci])));})).concat([value(buckets.get(JSON.stringify([ri,'total'])))]);});
  rows.push(['总计'].concat(ckeys.map(function(_,ci){return value(buckets.get(JSON.stringify(['total',ci])));})).concat([value(buckets.get(JSON.stringify(['total','total'])))]));
  var drill=[];for(var ri=0;ri<=rkeys.length;ri++){var line=[];for(var ci=0;ci<=ckeys.length;ci++){var b=buckets.get(JSON.stringify([ri===rkeys.length?'total':ri,ci===ckeys.length?'total':ci]));line.push(b?b.indices:[]);}drill.push(line);}
  if(c.column===null&&ckeys.length){headers.pop();rows.forEach(function(r){r.pop();});drill.forEach(function(r){r.pop();});}
  return {headers:headers,rows:rows,numeric:headers.map(function(_,i){return i;}).slice(1),sourceRows:[],drill:drill,emptyValues:empty,groups:rkeys.length,crossColumns:ckeys.length};
}
// Count before escaping or joining: repeated references must never allocate an unbounded CSV.
function csvBudget(n,limit){if(n>limit)fail('完整 CSV 超过 8 MiB，请缩小结果后重试；没有生成或截断输出，原输入仍保留。');return n;}
function csvRowBytes(row,numeric,delimiter,limit){delimiter=delimiter||',';if(delimiter!==','&&delimiter!=='\t')fail('请选择逗号或制表符。');limit=limit===undefined?LIMIT.bytes:limit;var nums=new Set(numeric||[]),total=Math.max(0,row.length-1);
  row.forEach(function(value,column){var s=String(value),number=nums.has(column)&&decimal(s)!==null,protect=!number&&/^[\s\u0000-\u0020]*[=+\-@]/.test(s),quoted=/["\r\n\t,]/.test(s)||(protect?/\s$/.test(s):s!==s.trim()),n=protect?1:0;if(quoted)n+=2;
    for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)n++;else if(c<2048)n+=2;else if(c>=55296&&c<=56319){var d=s.charCodeAt(++i);if(!(d>=56320&&d<=57343))fail('输出含无效 Unicode，原输入仍保留。');n+=4;}else if(c>=56320&&c<=57343)fail('输出含无效 Unicode，原输入仍保留。');else n+=3;if(quoted&&c===34)n++;csvBudget(total+n,limit);}total+=n;csvBudget(total,limit);
  });return csvBudget(total,limit);
}
function csvByteSize(headers,rows,numeric,delimiter,limit){limit=limit===undefined?LIMIT.bytes:limit;var n=csvBudget(5+csvRowBytes(headers,[],delimiter,limit),limit);rows.forEach(function(r){if(r.length!==headers.length)fail('输出行列数不一致。');n=csvBudget(n+2+csvRowBytes(r,numeric,delimiter,limit-n-2),limit);});return n;}
function csv(headers,rows,numeric,delimiter){delimiter=delimiter||',';csvByteSize(headers,rows,numeric,delimiter);var nums=new Set(numeric||[]),protectedCount=0;function quote(s,number){s=String(s);if(!number&&/^[\s\u0000-\u0020]*[=+\-@]/.test(s)){s="'"+s;protectedCount++;}return /["\r\n\t,]/.test(s)||s!==s.trim()?'"'+s.replace(/"/g,'""')+'"':s;}
  var out=[headers.map(function(s){return quote(s,false);}).join(delimiter)];rows.forEach(function(r){if(r.length!==headers.length)fail('输出行列数不一致。');out.push(r.map(function(s,i){return quote(s,nums.has(i)&&decimal(String(s))!==null);}).join(delimiter));});return {text:'\uFEFF'+out.join('\r\n')+'\r\n',protectedCount:protectedCount};
}
function defaults(t,tool){return tool==='csvquery'?{mode:'all',filters:[],columns:t.headers.map(function(_,i){return i;}),sorts:[]}:{row:0,column:t.headers.length>1?1:null,measure:null,agg:'count',precision:6};}
function validateProject(o,tool){exactKeys(o,['format','version','tool','name','raw','delimiter','header','config']);if(o.format!=='jinhe-table-project'||o.version!==1||o.tool!==tool||typeof o.name!=='string'||o.name.length>120||typeof o.header!=='boolean')fail('这不是当前工具支持的项目。');var t=parse(o.raw,o.delimiter,o.header);if(tool==='csvquery')queryConfig(t,o.config,true);else pivotConfig(t,o.config);return {project:JSON.parse(JSON.stringify(o)),table:t};}
return {LIMIT:LIMIT,bytes:bytes,parse:parse,decimal:decimal,compareDecimal:cmp,query:query,pivot:pivot,csv:csv,csvRowBytes:csvRowBytes,csvByteSize:csvByteSize,defaults:defaults,validateProject:validateProject};
}));
