(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TableTransport=api;}(typeof globalThis==='object'?globalThis:this,function(){'use strict';
var MAX=8388608;
function live(token){if(token&&token.cancelled)throw new Error('已停止；原来的表格仍保留。');}
function sizeOK(n,max){max=max||MAX;if(!Number.isSafeInteger(n)||n<0||n>max)throw new Error('文件超过 '+Math.floor(max/1048576)+' MiB 或大小未知；只读取完整文件，原件没有改变。');}
async function readPath(jh,path,token,progress,max){
  if(typeof path!=='string'||!path)throw new Error('没有可读取的文件位置。');var before=await jh.file.info(path);live(token);sizeOK(before.size,max);var decoder=new TextDecoder('utf-8',{fatal:true}),parts=[],offset=0;
  while(offset<before.size){live(token);var n=Math.min(65536,before.size-offset),r=await jh.file.readChunk(path,offset,n);live(token);if(!r||typeof r.base64!=='string')throw new Error('文件块没有内容。');var b=atob(r.base64),u=new Uint8Array(b.length);if(!u.length||u.length>n)throw new Error('文件没有读完整，请重新选择。');for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);parts.push(decoder.decode(u,{stream:true}));offset+=u.length;if(progress)progress(offset,before.size);}
  parts.push(decoder.decode());var after=await jh.file.info(path);live(token);if(after.size!==before.size)throw new Error('读取期间文件大小变化，请重新选择。');return parts.join('');
}
async function material(jh,id,token,progress,max){var m=await jh.workbench.take(id);live(token);if(!m)throw new Error('这份材料已不可用。');if(m.type==='text'){if(typeof m.text!=='string')throw new Error('材料没有完整文本。');sizeOK(new TextEncoder().encode(m.text).length,max);return {text:m.text,name:m.name||'工作台文本'};}if(m.type!=='file')throw new Error('请选择文本或 CSV/TSV 文件。');return {text:await readPath(jh,m.path,token,progress,max),name:m.name||'工作台文件'};}
async function save(jh,name,mime,text){return jh.saveFile(name,mime,new TextEncoder().encode(text));}
async function put(jh,name,text,token){live(token);var r=await jh.workbench.put({type:'text',name:name,text:text});live(token);if(!r||typeof r.id!=='string'||!r.id)throw new Error('工作台没有确认收下材料，请查看工作台后再试。');return r;}
async function putFile(jh,name,text){var u=new TextEncoder().encode(text),path='exports/'+Date.now()+'-'+Math.random().toString(36).slice(2)+'.csv',handed=false;try{for(var o=0;o<u.length;o+=65536){var part=u.subarray(o,o+65536),r=await jh.file.writeChunk(path,o,part);if(!r||r.ok!==true||r.written!==part.length)throw new Error('结果文件没有写完整。');}var info=await jh.file.info(path);if(info.size!==u.length)throw new Error('结果文件长度核对失败。');handed=true;var result=await jh.workbench.put({type:'file',path:path,name:name});if(!result||typeof result.id!=='string'||!result.id)throw new Error('工作台尚未确认，请先查看工作台；原结果仍可另存。');return result;}catch(e){if(!handed){try{var removed=await jh.file.delete(path);if(!removed||removed.ok!==true)throw new Error('未清理');}catch(cleanup){e.message+=' 临时副本未能清理。';}}throw e;}}
return {readPath:readPath,material:material,save:save,put:put,putFile:putFile};
}));
