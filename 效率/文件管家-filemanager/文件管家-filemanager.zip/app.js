(function () {
  'use strict';
  var PAGE = 40, MAX_BATCH = 2000;
  var S = { folder:null, directories:[], sortedDirectories:[], files:[], sortedCache:null, selected:new Set(), page:0, mode:'sequence', preview:[], previewPage:0, resultRows:[], resultPage:0, recovery:null, recoveryBlocked:false, busy:false, job:null, timer:0, undoId:'', undoFolder:'', epoch:0, suspended:false };
  var $ = function (id) { return document.getElementById(id); };
  function text(node, words) { node.textContent = String(words == null ? '' : words); }
  function show(id, on) { $(id).hidden = !on; }
  function message(words, error) { text($('message'), words); $('message').classList.toggle('error', !!error); }
  function errorText(e) { return e && (e.error || e.message) || '暂时完成不了，请重试。'; }
  function bridge() { return window.JH && window.JH.folder; }
  function bytes(n) { if (n == null || n < 0) return '大小未知'; if (n < 1024) return n + ' B'; var units=['KB','MB','GB','TB'], i=-1; do { n/=1024; i++; } while(n>=1024 && i<units.length-1); return (n < 10 ? n.toFixed(1) : Math.round(n)) + ' ' + units[i]; }
  function kind(file) { var mime=file.mime||'', ext=(file.name.split('.').pop()||'').toLowerCase(); if(/^image\//.test(mime))return 'image';if(/^audio\//.test(mime))return 'audio';if(/^video\//.test(mime))return 'video';if(/^(text\/|application\/(pdf|json|xml|msword|vnd\.))/i.test(mime)||/^(txt|md|pdf|epub|docx?|xlsx?|pptx?|csv|json|xml|html?)$/.test(ext))return 'document';return 'other'; }
  var compareNames = typeof Intl !== 'undefined' ? new Intl.Collator('zh-CN',{numeric:true,sensitivity:'base'}).compare : function(a,b){return a.localeCompare(b);};
  function sortedFiles() { var mode=$('sort').value;if(S.sortedCache&&S.sortedCache.mode===mode)return S.sortedCache.files;var files=S.files.slice().sort(function(a,b){var d=mode==='modified'?(b.modified||0)-(a.modified||0):mode==='size'?(b.size||0)-(a.size||0):0;return d||compareNames(a.name,b.name)||String(a.id).localeCompare(String(b.id));});S.sortedCache={mode:mode,files:files};return files; }
  function filtered() { var needle=$('search').value.toLocaleLowerCase(), filter=$('filter').value;return sortedFiles().filter(function(f){return (!needle||f._searchName.includes(needle))&&(filter==='all'||f._kind===filter);}); }
  function selectedFiles() { return sortedFiles().filter(function(f){return S.selected.has(f.id);}); }
  function button(words, action, cls) { var b=document.createElement('button');text(b,words);if(cls)b.className=cls;b.onclick=action;return b; }
  function refreshLocks() {
    ['choose','up','refresh','search','filter','sort','selectAll','clearSelection','previewButton'].forEach(function(id){$(id).disabled=S.busy;});
    var pending=!!S.recovery||S.recoveryBlocked;
    $('selectAll').disabled=S.busy||pending;
    $('previewButton').disabled=S.busy||pending||S.selected.size===0||S.selected.size>MAX_BATCH;
    $('apply').disabled=S.busy||pending||!S.preview.some(function(p){return p.changed;})||S.preview.some(function(p){return !!p.error;});
    $('backToRules').disabled=S.busy;
    document.querySelectorAll('#rules input,#rules select,#rules [data-mode]').forEach(function(el){el.disabled=S.busy;});
    var canUndo=!S.busy&&!pending&&!!S.undoId&&S.folder&&S.undoFolder===S.folder.id;
    show('undo',canUndo);show('undoNote',canUndo);
    $('recover').disabled=S.busy||!S.recovery||!S.recovery.id;
    $('saveReport').disabled=S.busy;
  }
  function invalidatePreview() { S.preview=[];show('preview',false);refreshLocks(); }
  function renderDirectories(directories) {
    var node=$('directories');node.replaceChildren();
    directories.forEach(function(d){
      var b=button('',function(){if(!S.busy)load(d.id);},'directory');b.setAttribute('aria-label','打开文件夹 '+d.name);
      var icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('aria-hidden','true');
      var path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d','M3 6h7l2 2h9v12H3z M3 6V4h7l2 2');path.setAttribute('fill','none');path.setAttribute('stroke','currentColor');path.setAttribute('stroke-width','1.8');path.setAttribute('stroke-linejoin','round');icon.appendChild(path);b.appendChild(icon);
      var name=document.createElement('span');name.className='filename';text(name,d.name);b.appendChild(name);var caption=document.createElement('small');text(caption,'文件夹');b.appendChild(caption);b.disabled=S.busy;node.appendChild(b);
    });
  }
  function renderFiles() {
    var files=filtered(), needle=$('search').value.toLocaleLowerCase();
    var directories=S.sortedDirectories.filter(function(d){return !needle||d._searchName.includes(needle);});
    var all=directories.map(function(d){return{directory:d};}).concat(files.map(function(f){return{file:f};}));
    var pages=Math.max(1,Math.ceil(all.length/PAGE));S.page=Math.max(0,Math.min(S.page,pages-1));
    var visible=all.slice(S.page*PAGE,(S.page+1)*PAGE);renderDirectories(visible.filter(function(r){return r.directory;}).map(function(r){return r.directory;}));
    var node=$('files');node.replaceChildren();
    if(!all.length){var empty=document.createElement('p');empty.className='empty';text(empty,S.files.length||S.directories.length?'没有符合条件的内容。':'这个文件夹没有内容。');node.appendChild(empty);}
    visible.filter(function(r){return r.file;}).map(function(r){return r.file;}).forEach(function(f){
      var row=document.createElement('div');row.className='file-row';
      var label=document.createElement('label');label.className='select-file';var cb=document.createElement('input');cb.type='checkbox';cb.checked=S.selected.has(f.id);cb.disabled=S.busy||!f.canRename||!!S.recovery||S.recoveryBlocked;cb.setAttribute('aria-label','选择 '+f.name);cb.onchange=function(){if(cb.checked&&S.selected.size>=MAX_BATCH){cb.checked=false;message('一次最多改名 '+MAX_BATCH+' 个文件，请减少选择。',true);return;}if(cb.checked)S.selected.add(f.id);else S.selected.delete(f.id);invalidatePreview();renderFiles();};label.appendChild(cb);row.appendChild(label);
      var copy=document.createElement('div');copy.className='file-copy';var name=document.createElement('div');name.className='filename';text(name,f.name);var info=document.createElement('div');info.className='detail';text(info,bytes(f.size)+(f.canRename?'':' · 只读'));copy.append(name,info);row.appendChild(copy);
      var open=button('打开',function(){if(!S.busy)bridge().open(f.id).catch(function(e){message(errorText(e),true);});},'file-open');open.disabled=S.busy;open.setAttribute('aria-label','打开 '+f.name);row.appendChild(open);node.appendChild(row);
    });
    text($('count'),files.length+' 个文件结果 · '+directories.length+' 个文件夹 · 已选 '+S.selected.size+' 个');
    text($('pageLabel'),(S.page+1)+' / '+pages);$('previous').disabled=S.busy||S.page===0;$('next').disabled=S.busy||S.page+1>=pages;show('filePager',pages>1);refreshLocks();
  }
  function renderFolder(data) {
    S.folder=data.folder;S.files=data.files||[];S.directories=data.folders||[];S.selected.clear();S.page=0;
    S.sortedCache=null;S.files.forEach(function(f){f._searchName=f.name.toLocaleLowerCase();f._kind=kind(f);});S.directories.forEach(function(d){d._searchName=d.name.toLocaleLowerCase();});S.sortedDirectories=S.directories.slice().sort(function(a,b){return compareNames(a.name,b.name);});
    text($('folderName'),S.folder.name);show('browser',true);show('rules',true);show('refresh',true);show('up',!!S.folder.parentId);invalidatePreview();renderFiles();
    message(S.files.length+' 个文件 · '+S.directories.length+' 个文件夹');
  }
  function setBusy(on) { S.busy=on;refreshLocks();if(S.folder)renderFiles(); }
  async function start(kindName, request) {
    if(S.busy)return;
    setBusy(true);show('job',true);show('pollError',false);show('retryStatus',false);$('cancel').disabled=false;show('cancel',true);
    text($('jobTitle'),kindName==='list'?'正在读取文件夹':kindName==='undo'||kindName==='recover'?'正在恢复原名':'正在改名');text($('jobDetail'),'准备中…');$('progress').removeAttribute('value');
    var epoch=++S.epoch;
    try { var r=await request();if(epoch!==S.epoch)return;if(!r||!r.jobId)throw {error:'任务没有启动，请重试。'};S.job={id:r.jobId,kind:kindName,epoch:epoch,folderId:S.folder&&S.folder.id};poll(); }
    catch(e){if(epoch!==S.epoch)return;S.job=null;setBusy(false);show('job',false);message(errorText(e),true);}
  }
  async function poll() {
    clearTimeout(S.timer);if(!S.job||S.suspended)return;
    var job=S.job;
    try {
      var r=await bridge().status(job.id);if(S.job!==job||job.epoch!==S.epoch)return;
      show('pollError',false);show('retryStatus',false);
      if(r.state==='running') {
        var phaseTitle={stage:'正在准备改名',rename:'正在改名',restore:'正在恢复原名'};
        if(phaseTitle[r.phase])text($('jobTitle'),phaseTitle[r.phase]);
        var total=r.phaseTotal||r.total,done=r.phaseTotal?r.phaseDone:r.done;
        text($('jobDetail'),total>0?(done||0)+' / '+total:'正在读取…');
        if(total>0){$('progress').max=total;$('progress').value=done||0;}else $('progress').removeAttribute('value');
        S.timer=setTimeout(poll,350);return;
      }
      S.job=null;show('job',false);setBusy(false);
      if(job.kind==='list') {
        if(r.state==='done'&&r.data)renderFolder(r.data);else message(r.error||(r.state==='cancelled'?'已停止读取。':'文件夹暂时读不了，请重新选择。'),r.state!=='cancelled');return;
      }
      show('preview',false);S.preview=[];
      if(r.recoveryCleared){S.recovery=null;S.recoveryBlocked=false;show('recovery',false);}else if(r.recovery)updateRecovery(r);
      if(r.state==='done'){S.undoId=r.undoId||'';S.undoFolder=job.folderId||'';}
      else {S.undoId='';S.undoFolder='';}
      renderResult(r,job.kind);refreshLocks();
      if(S.folder)load(S.folder.id);
    }catch(e){
      if(S.job!==job)return;show('pollError',true);show('retryStatus',true);text($('pollError'),errorText(e)+' 当前任务未重新启动。');
      S.timer=setTimeout(poll,1800);
    }
  }
  function load(id) { if(!S.busy)start('list',function(){return bridge().list(id);}); }
  function currentRule() {
    var start=$('start').value.trim();
    return {mode:S.mode,keepExtension:$('keepExtension').checked,prefix:S.mode==='sequence'?$('sequencePrefix').value:$('prefix').value,suffix:S.mode==='prefix'?$('suffix').value:'',oldText:$('oldText').value,newText:$('newText').value,replaceAll:true,start:/^\d+$/.test(start)?Number(start):NaN,digits:Number($('digits').value)};
  }
  function renderPreview() {
    var pages=Math.max(1,Math.ceil(S.preview.length/PAGE));S.previewPage=Math.min(S.previewPage,pages-1);
    var node=$('previewList');node.replaceChildren();
    S.preview.slice(S.previewPage*PAGE,(S.previewPage+1)*PAGE).forEach(function(p){var row=document.createElement('div');row.className='preview-row';var before=document.createElement('div');before.className='before';text(before,p.before);var after=document.createElement('div');after.className='after';text(after,p.after);row.append(before,after);if(p.error||!p.changed){var note=document.createElement('div');note.className=p.error?'detail error':'detail';text(note,p.error||'名字不变');row.appendChild(note);}node.appendChild(row);});
    var changed=S.preview.filter(function(p){return p.changed;}).length, errors=S.preview.filter(function(p){return !!p.error;}).length;
    text($('previewSummary'),changed+' 个将改名'+(errors?' · '+errors+' 个需要调整':''));text($('previewPageLabel'),(S.previewPage+1)+' / '+pages);$('previewPrevious').disabled=S.previewPage===0;$('previewNext').disabled=S.previewPage+1>=pages;show('previewPager',pages>1);refreshLocks();
  }
  function preview() {
    if(S.busy)return;var selected=selectedFiles();if(!selected.length)return;
    if(selected.length>MAX_BATCH){message('一次最多改名 '+MAX_BATCH+' 个文件，请减少选择。',true);return;}
    var occupied=S.files.filter(function(f){return !S.selected.has(f.id);}).concat(S.directories).map(function(f){return f.name;});
    S.preview=window.FileNaming.buildPreview(selected,currentRule(),occupied);S.previewPage=0;renderPreview();show('preview',true);$('preview').scrollIntoView({block:'start',behavior:'auto'});
  }
  function renderResult(r,kindName) {
    show('result',true);var results=r.results||[], partial=!!r.partial;
    text($('resultTitle'),r.state==='done'?(kindName==='undo'||kindName==='recover'?'原名已恢复':'改名完成'):partial?'部分文件需要处理':r.state==='cancelled'?'已停止':'未完成改名');
    text($('resultDetail'),r.error||(r.state==='done'?results.filter(function(p){return p.state==='renamed';}).length+' 个文件':partial?'请核对下面的实际文件名。':'已核对文件状态。'));
    S.resultRows=results;S.resultPage=0;renderResultPage();show('saveReport',results.length>0&&window.JH&&typeof window.JH.saveFile==='function');
  }
  function renderResultPage(){var rows=S.resultRows.filter(function(p){return p.state==='partial'||p.state==='missing'||!!p.error;}),pages=Math.max(1,Math.ceil(rows.length/PAGE));S.resultPage=Math.max(0,Math.min(S.resultPage,pages-1));var node=$('resultList');node.replaceChildren();rows.slice(S.resultPage*PAGE,(S.resultPage+1)*PAGE).forEach(function(p){var row=document.createElement('div');row.className='result-row';var before=document.createElement('div');before.className='before';text(before,p.originalName);var after=document.createElement('div');after.className='after';text(after,p.name==null?'目前无法确认文件名':p.name);var note=document.createElement('div');note.className='detail error';text(note,p.error||'请在文件夹中核对');row.append(before,after,note);node.appendChild(row);});text($('resultPageLabel'),(S.resultPage+1)+' / '+pages);$('resultPrevious').disabled=S.resultPage===0;$('resultNext').disabled=S.resultPage+1>=pages;show('resultPager',pages>1);}
  function updateRecovery(data){S.recovery=data.recovery||null;S.recoveryBlocked=!!data.recoveryBlocked;show('recovery',!!S.recovery||S.recoveryBlocked);text($('recoveryDetail'),S.recovery?(S.recovery.message||'有未完成的改名。请先恢复原名。'):(data.recoveryMessage||'请重新选择上次改名的文件夹。'));refreshLocks();}
  $('choose').onclick=async function(){if(S.busy)return;setBusy(true);try{var folder=await bridge().pick();setBusy(false);if(!folder)return;S.undoId='';S.undoFolder='';updateRecovery(folder);show('result',false);$('search').value='';load(folder.id);}catch(e){setBusy(false);message(errorText(e),true);}};
  $('up').onclick=function(){if(S.folder&&S.folder.parentId)load(S.folder.parentId);};$('refresh').onclick=function(){if(S.folder)load(S.folder.id);};
  ['search','filter','sort'].forEach(function(id){$(id).addEventListener(id==='search'?'input':'change',function(){S.page=0;invalidatePreview();renderFiles();});});
  $('selectAll').onclick=function(){var matches=filtered().filter(function(f){return f.canRename;}),ids=new Set(S.selected);matches.forEach(function(f){ids.add(f.id);});if(ids.size>MAX_BATCH){message('一次最多改名 '+MAX_BATCH+' 个文件，请先筛选。',true);return;}S.selected=ids;invalidatePreview();renderFiles();};
  $('clearSelection').onclick=function(){S.selected.clear();invalidatePreview();renderFiles();};$('previous').onclick=function(){S.page--;renderFiles();};$('next').onclick=function(){S.page++;renderFiles();};
  document.querySelectorAll('[data-mode]').forEach(function(b){b.onclick=function(){S.mode=b.dataset.mode;document.querySelectorAll('[data-mode]').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));});show('sequenceFields',S.mode==='sequence');show('replaceFields',S.mode==='replace');show('prefixFields',S.mode==='prefix');invalidatePreview();};});
  document.querySelectorAll('#rules input,#rules select').forEach(function(e){e.addEventListener('input',invalidatePreview);e.addEventListener('change',invalidatePreview);});
  $('previewButton').onclick=preview;$('backToRules').onclick=function(){show('preview',false);$('rules').scrollIntoView({block:'start'});};
  $('previewPrevious').onclick=function(){S.previewPage--;renderPreview();};$('previewNext').onclick=function(){S.previewPage++;renderPreview();};
  $('apply').onclick=function(){if(S.busy||S.preview.some(function(p){return p.error;}))return;var entries=S.preview.filter(function(p){return p.changed;}).map(function(p){return{id:p.id,name:p.after,expectedName:p.before};});if(!entries.length)return;show('result',false);start('rename',function(){return bridge().rename(S.folder.id,entries);});};
  $('cancel').onclick=async function(){var job=S.job;if(!job)return;$('cancel').disabled=true;try{await bridge().cancel(job.id);if(S.job===job)text($('jobDetail'),job.kind==='list'?'正在停止读取…':'正在停止，核对原名…');}catch(e){if(S.job===job){message(errorText(e),true);$('cancel').disabled=false;}}};
  $('retryStatus').onclick=poll;$('undo').onclick=function(){if(S.undoId&&!S.busy){show('result',false);start('undo',function(){return bridge().undo(S.undoId);});}};
  $('recover').onclick=function(){if(S.recovery&&S.recovery.id&&!S.busy)start('recover',function(){return bridge().recover(S.recovery.id);});};
  $('resultPrevious').onclick=function(){S.resultPage--;renderResultPage();};$('resultNext').onclick=function(){S.resultPage++;renderResultPage();};
  $('saveReport').onclick=async function(){var quote=function(v){return '"'+String(v==null?'':v).replace(/"/g,'""')+'"';},rows=[['原名','实际名称','目标名','状态']].concat(S.resultRows.map(function(r){return[r.originalName,r.name==null?'未确认':r.name,r.targetName,r.state];})),csv='\uFEFF'+rows.map(function(r){return r.map(quote).join(',');}).join('\r\n');try{var saved=await window.JH.saveFile('改名记录.csv','text/csv',csv);if(saved)message('改名记录已保存。');}catch(e){message(errorText(e),true);}};
  $('upgrade').onclick=function(){if(window.JH&&window.JH.openTool)window.JH.openTool('settings').catch(function(e){message(errorText(e),true);});};
  document.addEventListener('visibilitychange',function(){S.suspended=document.hidden;clearTimeout(S.timer);if(!S.suspended&&S.job)poll();});
  if(window.JH&&window.JH.onBack)window.JH.onBack(function(){
    if(S.busy){message('正在处理，可点“停止”或等待完成。');return true;}
    if(!$('preview').hidden){show('preview',false);$('rules').scrollIntoView({block:'start'});return true;}
    if($('search').value||$('filter').value!=='all'){$('search').value='';$('filter').value='all';S.page=0;invalidatePreview();renderFiles();return true;}
    if(S.selected.size){S.selected.clear();invalidatePreview();renderFiles();return true;}
    if(S.folder&&S.folder.parentId){load(S.folder.parentId);return true;}
    return false;
  });
  if(!bridge()){ $('choose').disabled=true;show('upgrade',true);message('请更新锦盒后再使用文件夹功能。'); } else refreshLocks();
}());
